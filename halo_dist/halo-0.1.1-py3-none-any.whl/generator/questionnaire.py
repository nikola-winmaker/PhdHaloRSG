"""Interactive questionnaire for creating HALO generators."""
from __future__ import annotations

import importlib.util
import re
import sys
from pathlib import Path
from typing import Dict, Any, Optional

if sys.version_info >= (3, 10):
    from importlib.metadata import entry_points
else:
    from importlib_metadata import entry_points


class GeneratorQuestionnaire:
    """Interactive questionnaire for gathering generator creation parameters."""
    
    @staticmethod
    def ask_question(prompt: str, default: Optional[str] = None, validator=None) -> str:
        """Ask a question and optionally validate the response.
        
        Args:
            prompt: Question to ask
            default: Default value if user presses Enter
            validator: Optional function to validate input
        
        Returns:
            User's response
        """
        if default:
            full_prompt = f"{prompt} [{default}]: "
        else:
            full_prompt = f"{prompt}: "
        
        while True:
            response = input(full_prompt).strip()
            
            if not response and default:
                response = default
            
            if not response:
                print("  Error: This field is required.")
                continue
            
            if validator:
                is_valid, error_msg = validator(response)
                if not is_valid:
                    print(f"  Error: {error_msg}")
                    continue
            
            return response
    
    @staticmethod
    def ask_yes_no(prompt: str, default: bool = False) -> bool:
        """Ask a yes/no question.
        
        Args:
            prompt: Question to ask
            default: Default value
        
        Returns:
            True for yes, False for no
        """
        default_str = "Y/n" if default else "y/N"
        full_prompt = f"{prompt} [{default_str}]: "
        
        while True:
            response = input(full_prompt).strip().lower()
            
            if not response:
                return default
            
            if response in ('y', 'yes'):
                return True
            elif response in ('n', 'no'):
                return False
            else:
                print("  Error: Please answer 'y' or 'n'.")
    
    @staticmethod
    def ask_choice(prompt: str, choices: list, default: Optional[str] = None) -> str:
        """Ask user to choose from a list of options.
        
        Args:
            prompt: Question to ask
            choices: List of valid choices
            default: Default choice
        
        Returns:
            Selected choice
        """
        print(f"\n{prompt}")
        for i, choice in enumerate(choices, 1):
            marker = "*" if choice == default else " "
            print(f"  {marker} {i}. {choice}")
        
        while True:
            if default:
                response = input(f"\nEnter choice (1-{len(choices)}) [{choices.index(default) + 1}]: ").strip()
            else:
                response = input(f"\nEnter choice (1-{len(choices)}): ").strip()
            
            if not response and default:
                return default
            
            try:
                choice_idx = int(response) - 1
                if 0 <= choice_idx < len(choices):
                    return choices[choice_idx]
                else:
                    print(f"  Error: Please enter a number between 1 and {len(choices)}.")
            except ValueError:
                print(f"  Error: Please enter a valid number.")
    
    @staticmethod
    def validate_identifier(name: str) -> tuple[bool, str]:
        """Validate that a string is a valid Python identifier.
        
        Args:
            name: String to validate
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not name:
            return False, "Name cannot be empty."
        
        if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name):
            return False, "Name must start with a letter or underscore and contain only letters, numbers, and underscores."
        
        if name in ('if', 'else', 'for', 'while', 'class', 'def', 'return', 'import'):
            return False, "Name cannot be a Python keyword."
        
        return True, ""
    
    @staticmethod
    def validate_email(email: str) -> tuple[bool, str]:
        """Validate email format.
        
        Args:
            email: Email to validate
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not email:
            return False, "Email cannot be empty."
        
        if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
            return False, "Invalid email format."
        
        return True, ""

    @staticmethod
    def parse_supported_platforms(
        value: str,
        available_platforms: list[str] | set[str] | tuple[str, ...] | None = None,
    ) -> tuple[bool, str, list[str]]:
        platforms = [item.strip().lower() for item in value.split(',') if item.strip()]
        if not platforms:
            return False, "Enter at least one platform.", []

        invalid = [item for item in platforms if not re.match(r'^[a-zA-Z0-9_-]+$', item)]
        if invalid:
            return False, f"Invalid platform names: {', '.join(invalid)}", []

        unique_platforms: list[str] = []
        seen: set[str] = set()
        for item in platforms:
            if item not in seen:
                unique_platforms.append(item)
                seen.add(item)

        if available_platforms is not None:
            available_platform_set = {item.strip().lower() for item in available_platforms if str(item).strip()}
            unsupported = [item for item in unique_platforms if item not in available_platform_set]
            if unsupported:
                available_list = ", ".join(sorted(available_platform_set))
                return False, f"Unsupported platforms: {', '.join(unsupported)}. Available platforms: {available_list}", []

        return True, "", unique_platforms

    @staticmethod
    def get_available_platforms() -> list[str]:
        available_platforms: set[str] = set()

        # Prefer installed platform generators, then fall back to local repo plugins.
        try:
            if sys.version_info >= (3, 10):
                platform_entry_points = entry_points(group="halo.generators")
            else:
                platform_entry_points = entry_points().get("halo.generators", [])

            for entry_point in platform_entry_points:
                try:
                    generator_factory = entry_point.load()
                    generator_config = generator_factory() if callable(generator_factory) else generator_factory
                    platform_name = str(generator_config.get("name", entry_point.name)).strip().lower()
                    if platform_name:
                        available_platforms.add(platform_name)
                except Exception:
                    continue
        except Exception:
            pass

        platform_generators_root = Path(__file__).resolve().parents[1] / "platform_generators"
        if platform_generators_root.exists():
            for config_path in platform_generators_root.glob("*/src/*/config.py"):
                try:
                    spec = importlib.util.spec_from_file_location(
                        f"halo_platform_config_{config_path.parent.name}",
                        config_path,
                    )
                    if spec is None or spec.loader is None:
                        continue

                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)

                    get_config = getattr(module, "get_generator_config", None)
                    if not callable(get_config):
                        continue

                    generator_config = get_config()
                    platform_name = str(generator_config.get("name", "")).strip().lower()
                    if platform_name:
                        available_platforms.add(platform_name)
                except Exception:
                    continue

        return sorted(available_platforms)

    def ask_supported_platforms(self, prompt: str) -> list[str]:
        available_platforms = self.get_available_platforms()
        if not available_platforms:
            raise ValueError("No available platforms were discovered. Install or register at least one platform generator before creating a protocol generator.")

        if available_platforms:
            print(f"  Currently available platforms: {', '.join(available_platforms)}")

        while True:
            response = input(f"{prompt}: ").strip()
            if not response:
                print("  Error: This field is required.")
                continue

            is_valid, error_msg, platforms = self.parse_supported_platforms(response, available_platforms)
            if not is_valid:
                print(f"  Error: {error_msg}")
                continue

            return platforms
    
    def run(self) -> Dict[str, Any]:
        """Run the interactive questionnaire.
        
        Returns:
            Dictionary containing all user responses
        """
        print("\n" + "=" * 70)
        print("  HALO Generator Creation Wizard")
        print("=" * 70)
        print("\nThis wizard will help you create a new HALO generator package.")
        print("Press Ctrl+C at any time to cancel.\n")
        
        try:
            generator_type = self.ask_choice(
                "Choose generator type:",
                choices=["platform", "protocol"],
                default="platform"
            )

            # Generator name
            name = self.ask_question(
                "Generator name (e.g., 'my_platform', 'stm32', 'esp32')" if generator_type == "platform" else "Protocol name (e.g., 'uart', 'i2c', 'can', 'sharedmemory')",
                validator=self.validate_identifier
            )
            
            # Description
            description = self.ask_question(
                "Brief description",
                default=f"HALO {generator_type} generator for {name}"
            )
            
            # Author info
            author = self.ask_question(
                "Author name",
                default="Your Name"
            )
            
            email = self.ask_question(
                "Author email",
                default="your.email@example.com",
                validator=self.validate_email
            )
            
            target_platform = name

            supported_platforms: list[str] = []
            if generator_type == "protocol":
                supported_platforms = self.ask_supported_platforms(
                    "Supported target platforms (comma-separated, e.g. linux,freertos,baremetal,zephyr)"
                )
            
            # OS/RTOS support
            has_os = False
            if generator_type == "platform":
                has_os = self.ask_yes_no(
                    "Does the target platform use an OS/RTOS?",
                    default=False
                )
            
            # Template engine
            template_engine = self.ask_choice(
                "Choose template engine:",
                choices=["jinja2", "mako", "none"],
                default="jinja2"
            )
            
            print("\n" + "=" * 70)
            print("  Summary")
            print("=" * 70)
            print(f"  Generator name:    {name}")
            print(f"  Description:       {description}")
            print(f"  Author:            {author} <{email}>")
            print(f"  Generator type:    {generator_type}")
            print(f"  {'Target platform' if generator_type == 'platform' else 'Protocol name'}:   {target_platform} (same as generator name)")
            if generator_type == "platform":
                print(f"  OS/RTOS support:   {'Yes' if has_os else 'No'}")
            else:
                print(f"  Supported targets: {', '.join(supported_platforms)}")
            print(f"  Template engine:   {template_engine}")
            print("=" * 70)
            
            confirm = self.ask_yes_no("\nCreate generator with these settings?", default=True)
            
            if not confirm:
                print("\nCancelled by user.")
                return {}
            
            return {
                "name": name,
                "description": description,
                "author": author,
                "email": email,
                "target_platform": target_platform,
                "supported_platforms": supported_platforms,
                "has_os": has_os,
                "template_engine": template_engine,
                "generator_type": generator_type,
            }
        
        except KeyboardInterrupt:
            print("\n\nCancelled by user.")
            return {}
