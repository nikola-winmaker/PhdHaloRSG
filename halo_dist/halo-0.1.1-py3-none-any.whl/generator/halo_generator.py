"""Public Python API for HALO Generator.

This module exposes stable, user-facing generator entry points.
"""

from __future__ import annotations

from .executor import generate_from_model as _generate_from_model


def generate_from_model(
    composer_output_dir: str,
    output_dir: str | None = None,
    *,
    platforms: list[str] | None = None,
    pkl_path: str | None = None,
    log_level: str | int = "INFO",
    user_gen_entry: str | None = None,
) -> int:
    """Public API wrapper for model-driven generation."""
    return int(
        _generate_from_model(
            composer_output_dir=composer_output_dir,
            output_dir=output_dir,
            platforms=platforms,
            pkl_path=pkl_path,
            log_level=log_level,
            user_gen_entry=user_gen_entry,
        )
    )


__all__ = ["generate_from_model"]
