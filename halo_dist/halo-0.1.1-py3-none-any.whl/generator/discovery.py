"""Generator discovery mechanism for HALO.

This module provides discovery for generators through Python entry points.
All generators (platform and custom) register via the 'halo.generators' entry point group.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional

if sys.version_info >= (3, 10):
    from importlib.metadata import entry_points
else:
    from importlib_metadata import entry_points


class GeneratorRegistry:
    """Registry for discovering and managing HALO generators."""
    
    ENTRY_POINT_GROUP = "halo.generators"
    
    def __init__(self):
        self._discovered_generators: Dict[str, Dict[str, Any]] = {}
        self._loaded = False
    
    def discover_installed_generators(self) -> None:
        """Discover generators installed as Python packages via entry points."""
        if sys.version_info >= (3, 10):
            eps = entry_points(group=self.ENTRY_POINT_GROUP)
        else:
            eps = entry_points().get(self.ENTRY_POINT_GROUP, [])
        
        for ep in eps:
            try:
                # Load the entry point
                generator_factory = ep.load()
                
                # Get generator configuration
                if callable(generator_factory):
                    gen_config = generator_factory()
                else:
                    gen_config = generator_factory
                
                # Validate required fields
                if not isinstance(gen_config, dict):
                    print(f"[WARN] Generator '{ep.name}' did not return a dict configuration")
                    continue
                
                if "name" not in gen_config:
                    gen_config["name"] = ep.name
                
                # Store discovered generator
                gen_name = gen_config["name"].lower()
                self._discovered_generators[gen_name] = gen_config
                print(f"[INFO] Discovered generator: {gen_name}")
                
            except Exception as e:
                print(f"[WARN] Failed to load generator '{ep.name}': {e}")
    
    def load_user_config(self, user_config_path: str) -> None:
        """Load user-provided generator configuration from JSON file."""
        config_path = Path(user_config_path).expanduser().resolve()
        if not config_path.exists():
            raise FileNotFoundError(f"User generator config not found: {config_path}")
        
        with config_path.open("r", encoding="utf-8") as f:
            user_config = json.load(f)
            for gen in user_config.get("generators", []):
                gen_name = gen["name"].lower()
                self._discovered_generators[gen_name] = gen
    
    def get_all_generators(self) -> Dict[str, Dict[str, Any]]:
        """Get all available generators.
        
        Returns a dictionary mapping generator name to its configuration.
        Discovery order (later overrides earlier):
        1. Entry point registered generators (platform and custom)
        2. User config file (if provided via --gen_cfg)
        """
        if not self._loaded:
            self.discover_installed_generators()
            self._loaded = True
        
        return dict(self._discovered_generators)
    
    def get_generator(self, name: str) -> Optional[Dict[str, Any]]:
        """Get a specific generator by name."""
        all_gens = self.get_all_generators()
        return all_gens.get(name.lower())
    
    def list_generators(self) -> List[str]:
        """List all available generator names."""
        return list(self.get_all_generators().keys())


# Global registry instance
_registry: Optional[GeneratorRegistry] = None


def get_registry() -> GeneratorRegistry:
    """Get the global generator registry instance."""
    global _registry
    if _registry is None:
        _registry = GeneratorRegistry()
    return _registry
