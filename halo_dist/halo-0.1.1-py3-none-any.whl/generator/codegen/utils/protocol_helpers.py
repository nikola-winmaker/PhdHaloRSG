"""Helper functions for protocol generators.

These utilities simplify model parsing for protocol generator writers.
Instead of manually navigating the model structure, protocol generators
can use these convenience functions.
"""
import logging
import re
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def get_connections_by_protocol(model: Dict[str, Any], protocol_type: str) -> List[Dict[str, Any]]:
    """Get all connections that use a specific protocol type.
    
    Args:
        model: HALO unified model
        protocol_type: Protocol type to filter by (e.g., "sharedmemory", "dma")
        
    Returns:
        List of connection dictionaries with matching protocol type
        
    Example:
        >>> shmem_connections = get_connections_by_protocol(model, "sharedmemory")
        >>> for conn in shmem_connections:
        ...     print(conn["name"])
    """
    connections = model.get("connections", [])
    profiles = model.get("profiles", {}) or {}
    
    matching_connections = []
    protocol_type_lower = protocol_type.lower().strip()
    
    for conn in connections:
        prof_name = conn.get("profile")
        if not prof_name:
            continue
            
        profile = profiles.get(prof_name, {})
        if not profile:
            continue
            
        # Check profile type
        prof_type = str(profile.get("type", "")).strip().lower()
        if prof_type == protocol_type_lower:
            matching_connections.append(conn)
    
    return matching_connections


def get_profile_for_connection(model: Dict[str, Any], connection: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Get the profile definition for a connection.
    
    Args:
        model: HALO unified model
        connection: Connection dictionary
        
    Returns:
        Profile dictionary or None if not found
        
    Example:
        >>> profile = get_profile_for_connection(model, connection)
        >>> base_addr = profile.get("baseAddress")
    """
    prof_name = connection.get("profile")
    if not prof_name:
        return None
    
    profiles = model.get("profiles", {}) or {}
    return profiles.get(prof_name)


def get_interface_for_connection(model: Dict[str, Any], connection: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Get the interface definition for a connection.
    
    Args:
        model: HALO unified model
        connection: Connection dictionary
        
    Returns:
        Interface dictionary or None if not found
        
    Example:
        >>> interface = get_interface_for_connection(model, connection)
        >>> reads = interface.get("access", {}).get("reads", [])
    """
    iface_name = connection.get("interface")
    if not iface_name:
        return None
    
    interfaces = model.get("interfaces", {})
    return interfaces.get(iface_name)


def get_structs_for_connection(model: Dict[str, Any], connection: Dict[str, Any]) -> List[str]:
    """Get list of struct names used by a connection.
    
    Combines all structs from the connection's interface (reads + writes).
    
    Args:
        model: HALO unified model
        connection: Connection dictionary
        
    Returns:
        List of struct names (deduplicated)
        
    Example:
        >>> struct_names = get_structs_for_connection(model, connection)
        >>> for name in struct_names:
        ...     struct_def = get_struct_definition(model, name)
    """
    interface = get_interface_for_connection(model, connection)
    if not interface:
        return []
    
    access = interface.get("access", {})
    reads = access.get("reads", [])
    writes = access.get("writes", [])
    
    # Combine and deduplicate
    return list(set(reads + writes))


def get_struct_definition(model: Dict[str, Any], struct_name: str) -> Optional[Dict[str, Any]]:
    """Get the definition of a struct by name.
    
    Args:
        model: HALO unified model
        struct_name: Name of the struct
        
    Returns:
        Struct definition dictionary or None if not found
        
    Example:
        >>> struct_def = get_struct_definition(model, "SensorData")
        >>> fields = struct_def.get("fields", [])
        >>> size = calculate_struct_size(fields)
    """
    data_types = model.get("dataTypes", {})
    structs = data_types.get("structs", {})
    return structs.get(struct_name)


def calculate_struct_size(fields: List[Dict[str, Any]]) -> int:
    """Calculate total size of a struct based on its fields.
    
    Args:
        fields: List of field dictionaries with 'type' and optionally 'arraySize'
        
    Returns:
        Total size in bytes
        
    Example:
        >>> fields = [
        ...     {"type": "u32", "name": "timestamp"},
        ...     {"type": "u8", "name": "data", "arraySize": 16}
        ... ]
        >>> size = calculate_struct_size(fields)  # 4 + 16 = 20
    """
    type_sizes = {
        'u8': 1, 'i8': 1, 'uint8': 1, 'int8': 1, 'char': 1,
        'u16': 2, 'i16': 2, 'uint16': 2, 'int16': 2, 'short': 2,
        'u32': 4, 'i32': 4, 'uint32': 4, 'int32': 4, 'int': 4, 'float': 4,
        'u64': 8, 'i64': 8, 'uint64': 8, 'int64': 8, 'long': 8, 'double': 8,
    }
    
    total_size = 0
    for field in fields:
        field_type = str(field.get("type", "")).lower()
        array_size = field.get("arraySize", 1)
        
        type_size = type_sizes.get(field_type, 4)  # Default to 4 bytes
        total_size += type_size * array_size
    
    return total_size


def parse_size_string(size_str: str) -> int:
    """Convert size string to bytes (e.g., '1KB' -> 1024).
    
    Supports units: B, KB, MB, GB, TB
    
    Args:
        size_str: Size string with optional unit
        
    Returns:
        Size in bytes
        
    Example:
        >>> parse_size_string("4KB")
        4096
        >>> parse_size_string("1MB")
        1048576
        >>> parse_size_string("512")
        512
    """
    if not size_str:
        return 0
    
    size_str = str(size_str).strip().upper()
    
    # Extract number and unit
    match = re.match(r'(\d+)\s*([KMGT]?B?)', size_str)
    if not match:
        # Try as plain number
        try:
            return int(size_str)
        except ValueError:
            logger.warning(f"Could not parse size string: {size_str}")
            return 0
    
    value = int(match.group(1))
    unit = match.group(2)
    
    multipliers = {
        '': 1,
        'B': 1,
        'KB': 1024,
        'K': 1024,
        'MB': 1024 * 1024,
        'M': 1024 * 1024,
        'GB': 1024 * 1024 * 1024,
        'G': 1024 * 1024 * 1024,
        'TB': 1024 * 1024 * 1024 * 1024,
        'T': 1024 * 1024 * 1024 * 1024,
    }
    
    return value * multipliers.get(unit, 1)


def get_profile_config(profile: Dict[str, Any], key: str, default: Any = None) -> Any:
    """Safely get a configuration value from a profile.
    
    Args:
        profile: Profile dictionary
        key: Configuration key
        default: Default value if key not found
        
    Returns:
        Configuration value or default
        
    Example:
        >>> profile = get_profile_for_connection(model, connection)
        >>> base_addr = get_profile_config(profile, "baseAddress", "0x00000000")
        >>> cacheable = get_profile_config(profile, "cacheable", False)
    """
    if not profile:
        return default
    return profile.get(key, default)


def get_connection_integrity_config(model: Dict[str, Any], connection: Dict[str, Any]) -> str:
    """Get the integrity/CRC configuration for a connection.
    
    Automatically detects CRC requirements from the connection's profile and interface.
    Checks profile first, then interface definition, falling back to NONE if not specified.
    
    This helper abstracts away the complexity of navigating profile hierarchy and
    integrity entry structures, providing a clean API for protocol generators.
    
    Args:
        model: HALO unified model
        connection: Connection dictionary
        
    Returns:
        Integrity type string: "SHAREDMEMORY_INTEGRITY_NONE", "SHAREDMEMORY_INTEGRITY_CRC16", 
        or "SHAREDMEMORY_INTEGRITY_CRC32"
        
    Example:
        >>> integrity = get_connection_integrity_config(model, connection)
        >>> print(f"Channel {connection['name']} uses {integrity}")
    """
    def _extract_crc_type(integrity: Any) -> Optional[str]:
        if not isinstance(integrity, dict):
            return None

        entries = integrity.get("entries")
        if not isinstance(entries, list) or not entries:
            return None

        first_entry = entries[0]
        if not isinstance(first_entry, dict):
            return None

        crc_type = str(first_entry.get("type", "")).lower()
        if crc_type == "crc16":
            return "SHAREDMEMORY_INTEGRITY_CRC16"
        if crc_type == "crc32":
            return "SHAREDMEMORY_INTEGRITY_CRC32"
        return None

    # Get integrity type from profile
    profile = get_profile_for_connection(model, connection)
    if profile:
        crc_type = _extract_crc_type(profile.get("integrity"))
        if crc_type is not None:
            return crc_type
    
    # Fallback to interface integrity definition
    interface = get_interface_for_connection(model, connection)
    if interface:
        crc_type = _extract_crc_type(interface.get("integrity"))
        if crc_type is not None:
            return crc_type
    
    # Default to no integrity checking
    return "SHAREDMEMORY_INTEGRITY_NONE"


def calculate_unified_struct_size(struct_def: Dict[str, Any]) -> int:
    """Calculate struct size from unified model struct definition.
    
    Handles the unified model's field structure with "array": {"size": N} format.
    
    Args:
        struct_def: Struct definition from unified model with 'fields' key
        
    Returns:
        Total size in bytes
        
    Example:
        >>> struct_def = get_struct_definition(model, "SensorData")
        >>> size = calculate_unified_struct_size(struct_def)  # 1032 bytes
    """
    type_sizes = {
        'integer': 4, 'int': 4, 'i32': 4,
        'byte': 1, 'u8': 1, 'i8': 1,
        'short': 2, 'i16': 2, 'u16': 2,
        'long': 8, 'i64': 8, 'u64': 8,
    }
    
    total_size = 0
    for field in struct_def.get("fields", []):
        field_type = str(field.get("type", "")).lower()
        base_size = type_sizes.get(field_type, 4)  # Default to 4 bytes
        
        # Check if it's an array
        array_info = field.get("array")
        if array_info and isinstance(array_info, dict):
            array_size = array_info.get("size", 1)
            total_size += base_size * array_size
        else:
            total_size += base_size
    
    return total_size


def get_max_payload_for_connection(model: Dict[str, Any], connection: Dict[str, Any]) -> int:
    """Get max payload size for what's actually being SENT on this connection.
    
    Instead of finding all structs in an interface, this finds only the struct(s)
    that are being written to on this connection (i.e., what the sender transmits),
    then returns the largest one.
    
    This is necessary because interfaces can contain multiple struct definitions,
    but each connection may only use a subset (typically one struct for each direction).
    
    Args:
        model: HALO unified model
        connection: Connection dictionary
        
    Returns:
        Maximum struct size being sent on this connection in bytes
        
    Example:
        >>> max_payload = get_max_payload_for_connection(model, connection)
        >>> buffer_size = 40 + max_payload  # Add overhead
    """
    interface_name = connection.get("interface", "")
    if not interface_name:
        return 256  # Default fallback
    
    # Get interface definition
    interfaces = model.get("interfaces", {})
    interface = interfaces.get(interface_name, {})
    if not isinstance(interface, dict):
        logger.debug(f"Interface '{interface_name}' is not a dict, returning default 256")
        return 256
    
    # Get what this connection writes (sends)
    access = interface.get("access", {})
    if not isinstance(access, dict):
        logger.debug(f"Interface '{interface_name}' access section is not a dict, returning default 256")
        return 256
    writes = access.get("writes", [])
    if not isinstance(writes, list):
        logger.debug(f"Interface '{interface_name}' writes section is not a list, returning default 256")
        return 256
    
    logger.debug(f"Connection '{connection.get('name')}' writes structs: {writes}")
    
    if not writes:
        logger.debug(f"No write structs for connection, returning default 256")
        return 256  # Default if no writes specified
    
    # Get dataStructures
    data_types = model.get("dataTypes", {})
    structs = data_types.get("structs", {})
    
    # Find the largest struct in the writes list
    max_size = 256  # Minimum fallback
    for struct_name in writes:
        struct_def = structs.get(struct_name, {})
        if struct_def:
            struct_size = calculate_unified_struct_size(struct_def)
            logger.debug(f"  Write struct '{struct_name}': {struct_size} bytes")
            max_size = max(max_size, struct_size)
        else:
            logger.debug(f"  Write struct '{struct_name}': NOT FOUND")
    
    logger.debug(f"Maximum payload for connection '{connection.get('name')}': {max_size} bytes")
    return max_size


def get_max_payload_for_interface(model: Dict[str, Any], interface_name: str) -> int:
    """Get max payload size by finding the largest struct in an interface.
    
    Useful for protocol generators that need to allocate buffers based on
    interface data structures (e.g., shared memory ring buffers).
    
    Args:
        model: HALO unified model
        interface_name: Name of the interface
        
    Returns:
        Maximum struct size in bytes (minimum 256 if no struct found)
        
    Example:
        >>> max_payload = get_max_payload_for_interface(model, "SensorInterface")
        >>> buffer_size = 64 + max_payload  # Add fixed overhead
    """
    if not interface_name:
        logger.debug("Interface name is empty, returning default 256")
        return 256  # Default fallback
    
    # Get interface definition
    interfaces = model.get("interfaces", {})
    interface = interfaces.get(interface_name, {})
    
    # Get struct refs from interface
    struct_refs = interface.get("data", {}).get("structRefs", [])
    logger.debug(f"Interface '{interface_name}' has struct refs: {struct_refs}")
    
    if not struct_refs:
        logger.debug(f"No struct refs found for interface '{interface_name}', returning default 256")
        return 256  # Default fallback
    
    # Get dataStructures
    data_types = model.get("dataTypes", {})
    structs = data_types.get("structs", {})
    
    # Find the largest struct
    max_size = 256  # Minimum fallback
    for struct_name in struct_refs:
        struct_def = structs.get(struct_name, {})
        if struct_def:
            struct_size = calculate_unified_struct_size(struct_def)
            logger.debug(f"  Struct '{struct_name}': {struct_size} bytes")
            max_size = max(max_size, struct_size)
        else:
            logger.debug(f"  Struct '{struct_name}': NOT FOUND in dataTypes.structs")
    
    logger.debug(f"Maximum payload for interface '{interface_name}': {max_size} bytes")
    return max_size


def get_profiles(model: Dict[str, Any]) -> Dict[str, Any]:
    """Get all profiles from the model.
    
    Extracts the profiles dictionary from the unified model for use in templates.
    
    Args:
        model: HALO unified model
        
    Returns:
        Dictionary of all profiles (profile_name -> profile_config)
        
    Example:
        >>> profiles = get_profiles(model)
        >>> event_channel_config = profiles.get("EventChannel", {})
        >>> queue_size = event_channel_config.get("eventQueueSize")
    """
    return model.get("profiles", {})


def to_c_value(python_value: Any) -> str:
    """Convert a Python value to C-compatible syntax.
    
    Supports automatic conversion of:
    - bool (True/False) → "true"/"false" (C99 stdbool)
    - str (quoted or unquoted) → "value" (normalized to double quotes)
    - int/float → numeric values as-is
    - Other types → string representation
    
    This allows protocol generators to accept any primitive type from profiles
    without needing protocol-specific conversion logic.
    
    Args:
        python_value: Python value from profile data
        
    Returns:
        C-compatible string representation suitable for code generation
        
    Example:
        >>> to_c_value(True)
        'true'
        >>> to_c_value(256)
        '256'
        >>> to_c_value("signal")
        '"signal"'
        >>> to_c_value('"already quoted"')
        '"already quoted"'
    """
    if isinstance(python_value, bool):
        # Python bool to C bool (requires stdbool.h)
        return "true" if python_value else "false"
    elif isinstance(python_value, str):
        # Handle string values
        val_str = python_value.strip()
        
        # Check if it's a boolean string representation
        if val_str.lower() in ("true", "false"):
            return val_str.lower()
        
        # Check if already quoted (single or double)
        if (val_str.startswith('"') and val_str.endswith('"')) or \
           (val_str.startswith("'") and val_str.endswith("'")):
            # Already quoted, normalize to double quotes
            return f'"{val_str[1:-1]}"'
        
        # Unquoted string literal, add double quotes
        return f'"{val_str}"'
    elif isinstance(python_value, int):
        # Integer values pass through as-is
        return str(python_value)
    elif isinstance(python_value, float):
        # If float is an integer value, emit as int
        if python_value.is_integer():
            return str(int(python_value))
        return str(python_value)
    else:
        # Fallback for other types
        return str(python_value)


def infer_c_type(python_value: Any) -> str:
    """Infer the appropriate C type from a Python value.
    
    Provides intelligent type mapping for code generation:
    - bool (True/False) → halo_u8_t (0/1)
    - str (any string) → const char*
    - int → halo_u32_t (unsigned 32-bit)
    - float → float (C99 float)
    
    This allows protocol generators to automatically determine struct field types
    without needing protocol-specific type mapping tables.
    
    Args:
        python_value: Python value from profile data
        
    Returns:
        C type string suitable for struct field declarations
        
    Example:
        >>> infer_c_type(True)
        'halo_u8_t'
        >>> infer_c_type(256)
        'halo_u32_t'
        >>> infer_c_type("signal")
        'halo_string_t'
        >>> infer_c_type(3.14)
        'halo_f32_t'
    """
    if isinstance(python_value, bool):
        # Boolean type (check bool before int, since bool is subclass of int)
        return "halo_u8_t"
    elif isinstance(python_value, int):
        # Integer type
        return "halo_u32_t"
    elif isinstance(python_value, float):
        # Floating point type
        return "halo_f32_t"
    elif isinstance(python_value, str):
        # String type (always as pointer to const char)
        return "halo_string_t"
    else:
        # Default fallback
        return "halo_u32_t"


def get_available_protocol_generators() -> Dict[str, str]:
    """Get list of available protocol generators.
    
    Discovers all installed protocol generators by scanning the protocol_generators
    directory structure. Returns a mapping of protocol type to generator module name.
    
    Returns:
        Dictionary mapping protocol type (e.g., "sharedmemory") to generator package name
        (e.g., "halo_proto_sharedmemory")
        
    Example:
        >>> generators = get_available_protocol_generators()
        >>> if "eventchannel" in generators:
        ...     use_eventchannel = True
    """
    import os
    from pathlib import Path
    
    generators = {}
    
    # Find protocol_generators directory (sibling of sw/generator)
    # From: .../sw/generator/codegen/utils/protocol_helpers.py
    # Go up to: .../sw/
    codegen_utils_path = Path(__file__).parent  # .../generator/codegen/utils
    sw_path = codegen_utils_path.parent.parent.parent  # Go to .../sw/
    generator_path = sw_path / "protocol_generators"
    
    if not generator_path.exists():
        logger.warning(f"Protocol generators directory not found: {generator_path}")
        return generators
    
    # Scan for generator packages matching pattern: halo_proto_* or halo-proto-*
    try:
        for entry in generator_path.iterdir():
            if entry.is_dir():
                # Extract protocol type from package name
                # halo_proto_sharedmemory → sharedmemory
                # halo-proto-sharedmemory → sharedmemory
                # halo_proto_event-channel → event-channel
                if entry.name.startswith("halo_proto_"):
                    protocol_type = entry.name[len("halo_proto_"):]
                    generators[protocol_type] = entry.name
                elif entry.name.startswith("halo-proto-"):
                    protocol_type = entry.name[len("halo-proto-"):]
                    generators[protocol_type] = entry.name
    except Exception as e:
        logger.warning(f"Error scanning protocol generators: {e}")
    
    return generators


def is_protocol_generator_available(protocol_type: str) -> bool:
    """Check if a protocol generator is available.
    
    Determines if the HALO framework has a generator installed for the given
    protocol type. Useful in templates to conditionally include files.
    
    Args:
        protocol_type: Protocol type name (e.g., "eventchannel", "sharedmemory")
        
    Returns:
        True if generator is available, False otherwise
        
    Example:
        >>> if is_protocol_generator_available("eventchannel"):
        ...     include("eventchannel_common.h")
    """
    generators = get_available_protocol_generators()
    return protocol_type.lower() in generators

