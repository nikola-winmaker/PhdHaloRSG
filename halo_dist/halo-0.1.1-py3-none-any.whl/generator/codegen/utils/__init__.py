"""Utility modules for HALO code generation."""

from .protocol_helpers import (
    get_connections_by_protocol,
    get_profile_for_connection,
    get_interface_for_connection,
    get_structs_for_connection,
    get_struct_definition,
    calculate_struct_size,
    calculate_unified_struct_size,
    parse_size_string,
    get_profile_config,
    get_connection_integrity_config,
    get_max_payload_for_interface,
    get_max_payload_for_connection,
    get_profiles,
    to_c_value,
    infer_c_type,
    get_available_protocol_generators,
    is_protocol_generator_available,
)

__all__ = [
    "get_connections_by_protocol",
    "get_profile_for_connection",
    "get_interface_for_connection",
    "get_structs_for_connection",
    "get_struct_definition",
    "calculate_struct_size",
    "calculate_unified_struct_size",
    "parse_size_string",
    "get_profile_config",
    "get_connection_integrity_config",
    "get_max_payload_for_interface",
    "get_max_payload_for_connection",
    "get_profiles",
    "to_c_value",
    "infer_c_type",
    "get_available_protocol_generators",
    "is_protocol_generator_available",

]
