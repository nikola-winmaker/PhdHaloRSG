"""Protocol rendering orchestrator.

This module handles the discovery and invocation of protocol generators.
Protocol generators are independent plugins that generate protocol-specific
code (shmem, dma, mmio) for various platforms.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Dict, Any

logger = logging.getLogger(__name__)


def render_protocols(model: Dict[str, Any], analysis: Dict[str, Any],
                     environment: str, output_dir: Path) -> None:
    """Discover and call protocol generators for protocols used in the model.
    
    This function orchestrates protocol generation independently from platform generation.
    Protocol generators are discovered via entry points and called based on protocols
    found in the model's connections.
    
    Args:
        model: Filtered platform model
        analysis: Analysis results
        environment: Target platform name (e.g., "linux", "baremetal")
        output_dir: Output directory for all generated files (platform + protocols)
    """
    try:
        # Import protocol discovery from the same generator package
        protocol_discovery_path = Path(__file__).parent.parent.parent
        if str(protocol_discovery_path) not in sys.path:
            sys.path.insert(0, str(protocol_discovery_path))
        
        from protocol_discovery import get_protocol_registry
        
        # Get protocol registry (discovers via entry points)
        protocol_registry = get_protocol_registry()
        
        # Extract protocols used in the model
        protocols_used = _extract_protocols_from_model(model)
        
        if not protocols_used:
            logger.debug(f"No protocols found in model for {environment}")
            return
        
        # Generate protocol-specific files in platform output directory (src/)
        protocol_output_dir = output_dir / "src"
        protocol_output_dir.mkdir(parents=True, exist_ok=True)
        
        # Call each protocol generator
        for protocol_name in protocols_used:
            protocol = protocol_registry.get_protocol(protocol_name)
            if protocol:
                platform_lower = environment.lower()
                render_func = protocol.get_render_function(platform_lower)
                if render_func:
                    logger.info(f"Generating {protocol_name} protocol for {environment}")
                    render_func(model, analysis, environment, protocol_output_dir)
                else:
                    logger.warning(f"Protocol '{protocol_name}' does not support platform '{environment}'")
            else:
                logger.warning(f"Unsupported protocol generator '{protocol_name}' for platform '{environment}'. Skipping generation for this protocol.")
    
    except ImportError as e:
        logger.debug(f"Protocol discovery not available: {e}")
        logger.debug("Skipping protocol-specific code generation")
    except Exception as e:
        logger.error(f"Error during protocol generation: {e}")


def _extract_protocols_from_model(model: Dict[str, Any]) -> set:
    """Extract the set of protocol types used in the model's connections.
    
    Resolves each connection's profile reference to get the protocol type
    from the profiles section of the model.
    
    Args:
        model: HALO model with connections and profiles
        
    Returns:
        Set of lowercased protocol names (e.g., {'sharedmemory', 'dma', 'mmio'})
    """
    protocols = set()
    profiles = model.get("profiles", {})
    connections = model.get("connections", [])
    for conn in connections:
        profile_name = conn.get("profile", "")
        if profile_name and profile_name in profiles:
            profile_type = profiles[profile_name].get("type", "")
            if profile_type:
                protocols.add(profile_type.lower())
    return protocols
