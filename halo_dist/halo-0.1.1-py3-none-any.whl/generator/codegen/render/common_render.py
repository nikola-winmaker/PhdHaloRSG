"""Common HALO code rendering for all platforms."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict
from jinja2 import Environment, FileSystemLoader, StrictUndefined

try:
    from . import render_utils as _utils
    from ..utils import to_c_value, infer_c_type
except ImportError:
    from generator.codegen.render import render_utils as _utils
    from generator.codegen.utils import to_c_value, infer_c_type


def render_common(
    *,
    model: Dict[str, Any],
    analysis: Dict[str, Any],
    environment: str,
    output_dir: Path,
) -> None:
    """Render common HALO templates for a platform.
    
    This generates the core HALO API files that are common across all platforms:
    - Headers: halo_api.h, halo_channels.h, halo_structs.h, etc.
    - Sources: halo_api.c, halo_channels.c, halo_structs.c, etc.
    
    Platform-specific files are generated separately by platform generators.
    
    Args:
        model: Platform-filtered model with components, interfaces, profiles
        analysis: Analysis report from analyzer
        environment: Platform name (e.g., "linux", "baremetal")
        output_dir: Output directory for generated files
    """
    # Get templates directory from HALO installation
    try:
        from .. import __file__ as codegen_init
        codegen_dir = Path(codegen_init).parent
    except ImportError:
        from generator.codegen import __file__ as codegen_init
        codegen_dir = Path(codegen_init).parent
    
    templates_dir = [
        str(codegen_dir / "templates" / "common"),
        str(codegen_dir / "templates" / "portable"),
    ]
    
    j2env = Environment(
        loader=FileSystemLoader(templates_dir),
        autoescape=False,
        undefined=StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
    )

    # Register Jinja2 filters and globals
    j2env.filters["c_ident"] = _utils._c_ident
    j2env.filters["crc_ret_type"] = _utils._crc_ret_type
    j2env.filters["size_bytes"] = _utils._size_bytes
    j2env.filters["c_uint"] = _utils._c_uint
    j2env.filters["c_str"] = _utils._c_str
    j2env.filters["str_lower"] = _utils._str_lower
    j2env.filters["to_c_value"] = to_c_value
    j2env.globals["maybe_size_bytes"] = _utils._maybe_size_bytes
    j2env.globals["looks_like_hex"] = _utils._looks_like_hex
    j2env.globals["looks_like_uint"] = _utils._looks_like_uint
    j2env.globals["infer_enum_domain"] = _utils._infer_enum_domain
    j2env.globals["_is_protocol_generator_available"] = _utils._is_protocol_generator_available

    ctx = {
        "model": model,
        "analysis": analysis,
        "environment": environment,
        "type_map": _utils._default_type_map(),
    }

    platform_include_dir = output_dir / "include"
    platform_src_dir = output_dir / "src"
    platform_include_dir.mkdir(parents=True, exist_ok=True)
    platform_src_dir.mkdir(parents=True, exist_ok=True)

    # Render common HALO headers
    _utils._render_to_file(j2env, "halo_types.h.j2", ctx, platform_include_dir / "halo_types.h")
    _utils._render_to_file(j2env, "halo_lib.h.j2", ctx, platform_include_dir / "halo_lib.h")
    _utils._render_to_file(j2env, "halo_cfg.h.j2", ctx, platform_include_dir / "halo_cfg.h")
    _utils._render_to_file(j2env, "halo_interfaces.h.j2", ctx, platform_include_dir / "halo_interfaces.h")
    _utils._render_to_file(j2env, "halo_channels.h.j2", ctx, platform_include_dir / "halo_channels.h")
    _utils._render_to_file(j2env, "halo_api.h.j2", ctx, platform_include_dir / "halo_api.h")
    _utils._render_to_file(j2env, "halo_profiles.h.j2", ctx, platform_include_dir / "halo_profiles.h")
    _utils._render_to_file(j2env, "halo_structs.h.j2", ctx, platform_include_dir / "halo_structs.h")

    # Render common HALO sources
    _utils._render_to_file(j2env, "halo_structs.c.j2", ctx, platform_src_dir / "halo_structs.c")
    _utils._render_to_file(j2env, "halo_api.c.j2", ctx, platform_src_dir / "halo_api.c")
    _utils._render_to_file(j2env, "halo_channels.c.j2", ctx, platform_src_dir / "halo_channels.c")
    _utils._render_to_file(j2env, "halo_services.c.j2", ctx, platform_src_dir / "halo_services.c")
    _utils._render_to_file(j2env, "halo_bindings.c.j2", ctx, platform_src_dir / "halo_bindings.c")
