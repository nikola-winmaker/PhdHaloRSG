from pathlib import Path
import sys


SW_DIR = Path(__file__).resolve().parents[3]
REPO_ROOT = Path(__file__).resolve().parents[4]
if str(SW_DIR) not in sys.path:
    sys.path.insert(0, str(SW_DIR))

from generator.codegen.render.render_utils import preserve_user_code_blocks, write_generated_file


def test_preserve_user_code_blocks_reuses_existing_named_sections():
    rendered = """\
alpha
/* HALO USER CODE BEGIN: demo.block */
new body
/* HALO USER CODE END: demo.block */
omega
"""
    existing = """\
alpha
/* HALO USER CODE BEGIN: demo.block */
old body
with two lines
/* HALO USER CODE END: demo.block */
omega
"""

    merged = preserve_user_code_blocks(rendered, existing)

    assert "old body\nwith two lines\n" in merged
    assert "new body" not in merged


def test_write_generated_file_preserves_user_code_between_writes(tmp_path):
    out_file = tmp_path / "generated.c"
    initial = """\
/* HALO USER CODE BEGIN: keep.me */
generated placeholder
/* HALO USER CODE END: keep.me */
"""
    write_generated_file(out_file, initial)

    out_file.write_text(
        """\
/* HALO USER CODE BEGIN: keep.me */
user custom code
/* HALO USER CODE END: keep.me */
""",
        encoding="utf-8",
    )

    write_generated_file(out_file, initial.replace("generated placeholder", "fresh placeholder"))
    merged = out_file.read_text(encoding="utf-8")

    assert "user custom code" in merged
    assert "fresh placeholder" not in merged


def test_scaffold_templates_include_user_code_markers():
    platform_template = REPO_ROOT / "sw/generator/scaffold/templates/platform/code_templates/platform_init.c.j2"
    protocol_template = REPO_ROOT / "sw/generator/scaffold/templates/protocol/templates/protocol_impl.c.j2"

    assert "HALO USER CODE BEGIN" in platform_template.read_text(encoding="utf-8")
    assert "HALO USER CODE BEGIN" in protocol_template.read_text(encoding="utf-8")
