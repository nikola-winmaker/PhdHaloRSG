import logging
import sys
from pathlib import Path


SW_DIR = Path(__file__).resolve().parents[3]
if str(SW_DIR) not in sys.path:
    sys.path.insert(0, str(SW_DIR))

import generator.halo_generator as public_api


def test_generate_from_model_forwards_arguments(monkeypatch):
    captured: dict = {}

    def fake_generate_from_model(**kwargs):
        captured.update(kwargs)
        return 17

    monkeypatch.setattr(public_api, "_generate_from_model", fake_generate_from_model)

    rc = public_api.generate_from_model(
        composer_output_dir="./composer_out",
        output_dir="./gen_out",
        platforms=["linux", "freertos"],
        pkl_path="./composer_out/halo_unified_model.pkl",
        log_level="WARNING",
        user_gen_entry="./user_generators.json",
    )

    assert rc == 17
    assert captured == {
        "composer_output_dir": "./composer_out",
        "output_dir": "./gen_out",
        "platforms": ["linux", "freertos"],
        "pkl_path": "./composer_out/halo_unified_model.pkl",
        "log_level": "WARNING",
        "user_gen_entry": "./user_generators.json",
    }


def test_generate_from_model_accepts_numeric_log_level(monkeypatch):
    captured: dict = {}

    def fake_generate_from_model(**kwargs):
        captured.update(kwargs)
        return 0

    monkeypatch.setattr(public_api, "_generate_from_model", fake_generate_from_model)

    rc = public_api.generate_from_model(
        composer_output_dir="./composer_out",
        log_level=logging.ERROR,
    )

    assert rc == 0
    assert captured["log_level"] == logging.ERROR
