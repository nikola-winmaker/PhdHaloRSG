import sys
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, StrictUndefined


SW_DIR = Path(__file__).resolve().parents[3]
if str(SW_DIR) not in sys.path:
    sys.path.insert(0, str(SW_DIR))

from generator.codegen.render import render_utils as _utils  # type: ignore


def test_halo_structs_template_emits_fixed_size_char_array_for_string_fields():
    model = {
        "dataTypes": {
            "structs": {
                "PrimitiveData": {
                    "fields": [
                        {
                            "name": "label",
                            "type": "string",
                            "init": {"value": "halo"},
                        },
                        {
                            "name": "payload",
                            "type": "byte",
                            "array": {"size": 8},
                            "init": {"value": 0},
                        },
                    ]
                }
            }
        },
    }

    templates_dir = SW_DIR / "generator" / "codegen" / "templates" / "common"
    env = Environment(
        loader=FileSystemLoader(str(templates_dir)),
        autoescape=False,
        undefined=StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
    )
    template = env.get_template("halo_structs.h.j2")

    rendered = template.render(
        model=model,
        type_map=_utils._default_type_map(),
    )

    assert "halo_char_t label[5];" in rendered
    assert "halo_u8_t payload[8];" in rendered
    assert "halo_string_t label;" not in rendered
