from pathlib import Path
import sys


SW_DIR = Path(__file__).resolve().parents[3]
if str(SW_DIR) not in sys.path:
    sys.path.insert(0, str(SW_DIR))

from generator.executor import HALOExecutor


def test_select_platforms_returns_all_when_no_filter_is_given():
    selected = HALOExecutor._select_platforms(
        available_platforms={"linux", "freertos"},
        requested_platforms=None,
    )

    assert selected == ["freertos", "linux"]


def test_select_platforms_returns_only_requested_platforms():
    selected = HALOExecutor._select_platforms(
        available_platforms={"Linux", "freertos", "baremetal"},
        requested_platforms=["linux"],
    )

    assert selected == ["Linux"]


def test_select_platforms_rejects_unknown_platforms():
    try:
        HALOExecutor._select_platforms(
            available_platforms={"linux", "freertos"},
            requested_platforms=["stm32"],
        )
    except ValueError as exc:
        message = str(exc)
    else:
        raise AssertionError("Expected ValueError for an unknown platform")

    assert "stm32" in message
    assert "linux" in message
    assert "freertos" in message
