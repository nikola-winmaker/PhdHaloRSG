import sys
from pathlib import Path


SW_DIR = Path(__file__).resolve().parents[3]
if str(SW_DIR) not in sys.path:
    sys.path.insert(0, str(SW_DIR))

from generator.codegen.utils.protocol_helpers import (  # type: ignore
    get_connection_integrity_config,
    get_max_payload_for_connection,
)


def test_get_connection_integrity_config_tolerates_none_integrity():
    model = {
        "profiles": {
            "p1": {
                "type": "sharedmemory",
                "integrity": None,
            }
        },
        "interfaces": {
            "i1": {
                "integrity": None,
            }
        },
    }
    connection = {"profile": "p1", "interface": "i1"}

    assert get_connection_integrity_config(model, connection) == "SHAREDMEMORY_INTEGRITY_NONE"


def test_get_max_payload_for_connection_tolerates_none_access():
    model = {
        "interfaces": {
            "i1": {
                "access": None,
            }
        },
        "dataTypes": {
            "structs": {}
        },
    }
    connection = {"name": "c1", "interface": "i1"}

    assert get_max_payload_for_connection(model, connection) == 256
