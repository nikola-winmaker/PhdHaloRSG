import sys
from pathlib import Path


SW_DIR = Path(__file__).resolve().parents[3]
if str(SW_DIR) not in sys.path:
    sys.path.insert(0, str(SW_DIR))

from generator.codegen.utils.protocol_helpers import (  # type: ignore
    calculate_unified_struct_size,
    get_connection_integrity_config,
    get_max_payload_for_connection,
)


def test_get_connection_integrity_config_tolerates_none_integrity():
    model = {
        "profiles": {
            "p1": {
                "type": "sharedmemory",
                "integrity": None,
            }
        },
        "interfaces": {
            "i1": {
                "integrity": None,
            }
        },
    }
    connection = {"profile": "p1", "interface": "i1"}

    assert get_connection_integrity_config(model, connection) == "SHAREDMEMORY_INTEGRITY_NONE"


def test_get_max_payload_for_connection_tolerates_none_access():
    model = {
        "interfaces": {
            "i1": {
                "access": None,
            }
        },
        "dataTypes": {
            "structs": {}
        },
    }
    connection = {"name": "c1", "interface": "i1"}

    assert get_max_payload_for_connection(model, connection) == 256


def test_calculate_unified_struct_size_handles_common_compact_types():
    struct_def = {
        "fields": [
            {"name": "battery_voltage_mv", "type": "unsignedint"},
            {"name": "charge_current_ma", "type": "int"},
            {"name": "battery_temp_c", "type": "float"},
            {"name": "breaker_closed", "type": "bool"},
            {"name": "fault_flags", "type": "unsignedint"},
        ]
    }

    assert calculate_unified_struct_size(struct_def) == 20


def test_calculate_unified_struct_size_counts_string_storage_from_initializer():
    struct_def = {
        "fields": [
            {"name": "flag", "type": "bool"},
            {"name": "label", "type": "string", "init": {"value": "halo"}},
            {"name": "value", "type": "unsignedint"},
        ]
    }

    assert calculate_unified_struct_size(struct_def) == 16


def test_get_max_payload_for_connection_returns_actual_small_struct_size():
    model = {
        "interfaces": {
            "SensorFrameIf": {
                "access": {
                    "writes": ["SensorFrame"],
                }
            }
        },
        "dataTypes": {
            "structs": {
                "SensorFrame": {
                    "fields": [
                        {"name": "battery_voltage_mv", "type": "unsignedint"},
                        {"name": "charge_current_ma", "type": "int"},
                        {"name": "battery_temp_c", "type": "float"},
                        {"name": "breaker_closed", "type": "bool"},
                        {"name": "fault_flags", "type": "unsignedint"},
                    ]
                }
            }
        },
    }
    connection = {"name": "sensor_conn", "interface": "SensorFrameIf"}

    assert get_max_payload_for_connection(model, connection) == 20


def test_get_max_payload_for_connection_counts_fixed_string_storage():
    model = {
        "interfaces": {
            "NamedFrameIf": {
                "access": {
                    "writes": ["NamedFrame"],
                }
            }
        },
        "dataTypes": {
            "structs": {
                "NamedFrame": {
                    "fields": [
                        {"name": "flag", "type": "bool"},
                        {"name": "label", "type": "string", "init": {"value": "halo"}},
                        {"name": "value", "type": "unsignedint"},
                    ]
                }
            }
        },
    }
    connection = {"name": "named_conn", "interface": "NamedFrameIf"}

    assert get_max_payload_for_connection(model, connection) == 16
