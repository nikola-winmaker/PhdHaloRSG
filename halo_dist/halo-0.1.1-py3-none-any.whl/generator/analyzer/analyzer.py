from __future__ import annotations

import datetime as _dt
from typing import Any, Dict, List


def analyze_unified_model(unified_model: Dict[str, Any]) -> Dict[str, Any]:
    """Analyze a HALO unified model dict.

    This is a minimal analyzer that validates basic referential integrity:
    - connection endpoints refer to existing components
    - connection interface names exist in unified_model.interfaces
    - (warning) connection profile names exist in unified_model.profiles
    - (warning) interface structRefs exist in dataTypes.structs

    The report schema includes placeholders for future analysis outputs.
    """

    errors: List[str] = []
    warnings: List[str] = []

    components = unified_model.get("components", [])
    connections = unified_model.get("connections", [])
    interfaces = unified_model.get("interfaces", {})
    profiles = unified_model.get("profiles", {})
    data_types = unified_model.get("dataTypes", {})

    if not isinstance(components, list):
        errors.append("unified_model.components must be a list")
        components = []
    if not isinstance(connections, list):
        errors.append("unified_model.connections must be a list")
        connections = []
    if not isinstance(interfaces, dict):
        errors.append("unified_model.interfaces must be a dict")
        interfaces = {}
    if not isinstance(profiles, dict):
        errors.append("unified_model.profiles must be a dict")
        profiles = {}

    component_names = {c.get("name") for c in components if isinstance(c, dict)}
    component_names.discard(None)

    for conn in connections:
        if not isinstance(conn, dict):
            errors.append("connection entry must be an object")
            continue

        name = conn.get("name")
        src = conn.get("from_component")
        dst = conn.get("to_component")
        iface = conn.get("interface")
        prof = conn.get("profile")

        if not name:
            errors.append("connection has no name")
        if src and src not in component_names:
            errors.append(f"connection '{name}': from_component '{src}' does not exist")
        if dst and dst not in component_names:
            errors.append(f"connection '{name}': to_component '{dst}' does not exist")
        if iface and iface not in interfaces:
            errors.append(f"connection '{name}': interface '{iface}' not found in unified_model.interfaces")
        if prof and prof not in profiles:
            warnings.append(f"connection '{name}': profile '{prof}' not found in unified_model.profiles")

    structs = {}
    if isinstance(data_types, dict):
        candidate = data_types.get("structs")
        if isinstance(candidate, dict):
            structs = candidate

    for iface_name, iface_obj in interfaces.items():
        if not isinstance(iface_obj, dict):
            errors.append(f"interface '{iface_name}' must be an object")
            continue

        refs = _get_struct_refs(iface_obj)
        for ref in refs:
            if ref not in structs:
                warnings.append(f"interface '{iface_name}': structRef '{ref}' not found in dataTypes.structs")

    # Extract environments from the 'Platform' field in components
    environments = set()
    for c in components:
        if isinstance(c, dict):
            env = c.get("Platform")
            if isinstance(env, str) and env.strip():
                environments.add(env)
    env_summary = {env: {"warnings": 0, "errors": 0} for env in environments}
    ok = len(errors) == 0

    return {
        "ok": ok,
        "generated_at": _dt.datetime.now(tz=_dt.timezone.utc).isoformat(),
        "summary": {
            "components": len(components),
            "connections": len(connections),
            "interfaces": len(interfaces),
            "profiles": len(profiles),
            "structs": len(structs),
        },
        "environments": env_summary,
        "errors": errors,
        "warnings": warnings,
        "resource_consumption": {},
        "call_stack": {},
        "function_summary": {},
    }


def _get_struct_refs(iface_obj: Dict[str, Any]) -> List[str]:
    data = iface_obj.get("data")
    if not isinstance(data, dict):
        return []
    refs = data.get("structRefs")
    if not isinstance(refs, list):
        return []
    out: List[str] = []
    for r in refs:
        if isinstance(r, str) and r.strip():
            out.append(r)
    return out
