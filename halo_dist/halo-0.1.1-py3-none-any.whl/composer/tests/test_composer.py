import difflib
import json
import logging
import os
import re
import sys
from pathlib import Path
from typing import Any

import pytest


def _normalize_scalar_literal(value: Any) -> Any:
	"""Normalize scalar literals so semantically equivalent values compare equal."""
	if not isinstance(value, str):
		return value

	s = value.strip()
	if not s:
		return value

	ls = s.lower()
	if ls == "true":
		return True
	if ls == "false":
		return False
	if re.fullmatch(r"[-+]?\d+", s):
		try:
			return int(s)
		except ValueError:
			return value
	if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)", s):
		try:
			return float(s)
		except ValueError:
			return value

	return value


def _import_halo_composer_module():
	"""Import the halo_composer module.

	Works both when running from source tree and when installed as a package.
	"""
	# Prefer the in-repo implementation (HALO/sw) over any installed package.
	sw_dir = Path(__file__).resolve().parents[2]
	if str(sw_dir) not in sys.path:
		sys.path.insert(0, str(sw_dir))
	# If an installed package was imported earlier in the session, drop it so we
	# re-import from the source tree.
	for mod in ("composer.halo_composer", "composer"):
		if mod in sys.modules:
			del sys.modules[mod]
	try:
		import composer.halo_composer as halo_composer  # type: ignore
		return halo_composer
	except ImportError:
		composer_dir = Path(__file__).resolve().parents[1]
		if str(composer_dir) not in sys.path:
			sys.path.insert(0, str(composer_dir))
		import halo_composer  # type: ignore
		return halo_composer


def _canonicalize(obj: Any) -> Any:
	"""Recursively normalize the unified model for stable comparisons."""
	if isinstance(obj, dict):
		out = {k: _canonicalize(v) for k, v in obj.items()}

		# Normalize initializer scalar text produced by some XMI fixtures, so
		# semantically equivalent HADL/XMI values compare equal.
		init_obj = out.get("init")
		if isinstance(init_obj, dict) and "value" in init_obj:
			init_obj["value"] = _normalize_scalar_literal(init_obj.get("value"))

		# Normalize list-typed fields where ordering shouldn't matter.
		for key in (
			"components",
			"connections",
			"incoming_connections",
			"outgoing_connections",
			"structRefs",
			"reads",
			"writes",
			"entries",
			"fields",
		):
			if key in out and isinstance(out[key], list):
				out[key] = _canonicalize(out[key])
		return out

	if isinstance(obj, list):
		items = [_canonicalize(v) for v in obj]
		if all(isinstance(v, dict) for v in items) and all("name" in v for v in items):
			return sorted(items, key=lambda d: str(d.get("name")))
		return sorted(items, key=lambda v: json.dumps(v, sort_keys=True, separators=(",", ":")))

	return obj


def _load_json(path: Path) -> Any:
	return json.loads(path.read_text(encoding="utf-8"))


def _canonical_json_str(obj: Any) -> str:
	return json.dumps(_canonicalize(obj), sort_keys=True, separators=(",", ":"))


def _first_difference_path(a: Any, b: Any, path: str = "") -> tuple[str, Any, Any] | None:
	"""Return the first differing path between two JSON-like objects.

	The path is a dotted form with list indices, e.g. "a.b[3].c".
	"""
	if type(a) is not type(b):
		return (path, type(a).__name__, type(b).__name__)

	if isinstance(a, dict):
		keys_a = set(a.keys())
		keys_b = set(b.keys())
		if keys_a != keys_b:
			only_a = sorted(keys_a - keys_b)
			only_b = sorted(keys_b - keys_a)
			return (path or "<root>", {"only_in_a": only_a}, {"only_in_b": only_b})
		for key in sorted(keys_a):
			new_path = f"{path}.{key}" if path else str(key)
			if a[key] != b[key]:
				found = _first_difference_path(a[key], b[key], new_path)
				return found or (new_path, a[key], b[key])
		return None

	if isinstance(a, list):
		if len(a) != len(b):
			return (path or "<root>", f"len={len(a)}", f"len={len(b)}")
		for i, (ai, bi) in enumerate(zip(a, b)):
			if ai != bi:
				new_path = f"{path}[{i}]" if path else f"[{i}]"
				found = _first_difference_path(ai, bi, new_path)
				return found or (new_path, ai, bi)
		return None

	if a != b:
		return (path or "<root>", a, b)

	return None


def _limit_str(value: Any, max_len: int = 240) -> str:
	s = repr(value)
	if len(s) <= max_len:
		return s
	return s[: max_len - 3] + "..."


def _unified_diff_snippet(
	a_text: str,
	b_text: str,
	*,
	from_name: str,
	to_name: str,
	context_lines: int = 3,
	max_lines: int = 120,
) -> str:
	lines = list(
		difflib.unified_diff(
			a_text.splitlines(keepends=True),
			b_text.splitlines(keepends=True),
			fromfile=from_name,
			tofile=to_name,
			n=context_lines,
		)
	)
	if len(lines) > max_lines:
		lines = lines[:max_lines] + ["\n... (diff truncated)\n"]
	return "".join(lines)


def test_halo_composer_outputs_match_between_xmi_and_hadl(capsys: pytest.CaptureFixture[str]):
	"""
	Test: Verify HALO composer output consistency across different input formats.
	This test validates that the HALO composer produces identical unified model outputs
	when processing the same architectural model from two different input sources:
	1. XMI/UML format (from xmi_model folder)
	2. HADL (HALO Architecture Description Language) format
	The test performs the following steps:
	- Composes unified models from XMI and HADL inputs
	- Generates canonicalized JSON outputs for comparison
	- Performs deep comparison of the resulting data structures
	- Provides detailed diagnostic output showing any differences found
	- Asserts that both outputs are identical
	This ensures that the composer maintains semantic consistency regardless of the
	input format used.
	"""
	halo_composer = _import_halo_composer_module()

	tests_dir = Path(__file__).resolve().parent
	composer_dir = tests_dir.parent

	xmi_model_uml = tests_dir / "xmi_model" / "halo_model.uml"
	assert xmi_model_uml.exists(), f"Missing fixture: {xmi_model_uml}"

	hadls_root = composer_dir / "dsl" / "hadls"
	assert hadls_root.exists(), f"Missing HADL fixtures folder: {hadls_root}"

	out_dir = tests_dir / "out"
	xmi_out_dir = out_dir / "xmi"
	hadl_out_dir = out_dir / "hadl"
	xmi_out_dir.mkdir(parents=True, exist_ok=True)
	hadl_out_dir.mkdir(parents=True, exist_ok=True)

	# Compose from XMI.
	assert halo_composer._compose_from_xmi(str(xmi_model_uml), str(xmi_out_dir)) == 0

	# XMI import should also export HADL files.
	hadl_dir = xmi_out_dir / "hadl"
	assert hadl_dir.exists(), f"Missing HADL output dir: {hadl_dir}"
	assert any(hadl_dir.glob("*.adl")), f"Missing .adl in {hadl_dir}"
	assert (hadl_dir / "halo_interfaces.idl").exists(), f"Missing IDL in {hadl_dir}"
	assert (hadl_dir / "halo_interface_data.iddl").exists(), f"Missing IDDL in {hadl_dir}"
	assert (hadl_dir / "halo_profiles.hml").exists(), f"Missing HML in {hadl_dir}"

	# Compose from HADL fixtures.
	assert halo_composer._compose_from_hadl(str(hadls_root), str(hadl_out_dir), logging.ERROR) == 0

	xmi_json = xmi_out_dir / "halo_unified_model.json"
	hadl_json = hadl_out_dir / "halo_unified_model.json"
	assert xmi_json.exists(), f"Missing output: {xmi_json}"
	assert hadl_json.exists(), f"Missing output: {hadl_json}"

	xmi_obj = _load_json(xmi_json)
	hadl_obj = _load_json(hadl_json)

	# Write canonicalized copies for easy diffs.
	(out_dir / "xmi_unified_model.canon.json").write_text(
		json.dumps(_canonicalize(xmi_obj), indent=2, sort_keys=True),
		encoding="utf-8",
	)
	(out_dir / "hadl_unified_model.canon.json").write_text(
		json.dumps(_canonicalize(hadl_obj), indent=2, sort_keys=True),
		encoding="utf-8",
	)

	xmi_canon = _canonicalize(xmi_obj)
	hadl_canon = _canonicalize(hadl_obj)

	# Prefer comparing canonical objects for correctness; produce a compact, actionable
	# error message on failure.
	if not (xmi_canon == hadl_canon):
		# Drop noisy composer stdout from the failure report.
		capsys.readouterr()

		xmi_pretty = json.dumps(xmi_canon, indent=2, sort_keys=True)
		hadl_pretty = json.dumps(hadl_canon, indent=2, sort_keys=True)

		canon_paths = [
			out_dir / "xmi_unified_model.canon.json",
			out_dir / "hadl_unified_model.canon.json",
		]

		pairs: list[tuple[str, Any, str, Any, str, str]] = [
			("XMI", xmi_canon, "HADL", hadl_canon, xmi_pretty, hadl_pretty),
		]

		sections: list[str] = []
		for left_name, left_obj, right_name, right_obj, left_text, right_text in pairs:
			if left_obj == right_obj:
				continue
			first = _first_difference_path(left_obj, right_obj)
			if first is None:
				first_summary = "<unknown>"
			else:
				p, lv, rv = first
				first_summary = f"{p}: {left_name}={_limit_str(lv)} vs {right_name}={_limit_str(rv)}"

			diff_snippet = _unified_diff_snippet(
				left_text,
				right_text,
				from_name=f"{left_name}.canon.json",
				to_name=f"{right_name}.canon.json",
			)
			sections.append(
				"\n".join(
					[
						f"Mismatch: {left_name} vs {right_name}",
						f"First difference: {first_summary}",
						"Diff (snippet):",
						diff_snippet or "(no diff produced)",
					]
				)
			)

		pytest.fail(
			"\n\n".join(
				[
					"HALO composer outputs are not identical between XMI and HADL inputs.",
					"Canonicalized outputs were written for full diffs:",
					"- " + "\n- ".join(str(p) for p in canon_paths),
					"\n".join(sections),
				]
			),
			pytrace=False,
		)


def test_compose_from_xmi_with_profile(capsys: pytest.CaptureFixture[str]):
	"""
	Test: Verify XMI import with separate profile file.
	This test ensures that the HALO composer can successfully import a UML model
	with a separate profile XMI file from the xmi_model directory.
	"""
	halo_composer = _import_halo_composer_module()

	tests_dir = Path(__file__).resolve().parent
	xmi_model_uml = tests_dir / "xmi_model" / "halo_model.uml"
	xmi_profile = tests_dir / "xmi_model" / "halo_profile.xmi"
	
	assert xmi_model_uml.exists(), f"Missing fixture: {xmi_model_uml}"
	assert xmi_profile.exists(), f"Missing fixture: {xmi_profile}"

	out_dir = tests_dir / "out" / "xmi_with_profile"
	out_dir.mkdir(parents=True, exist_ok=True)
	
	# Compose from XMI (the composer should handle the profile automatically)
	assert halo_composer._compose_from_xmi(str(xmi_model_uml), str(out_dir)) == 0
	
	# Verify output was generated
	unified_json = out_dir / "halo_unified_model.json"
	assert unified_json.exists(), f"Missing output: {unified_json}"
	
	# Verify HADL export occurred
	hadl_dir = out_dir / "hadl"
	assert hadl_dir.exists(), f"Missing HADL output dir: {hadl_dir}"
	assert (hadl_dir / "halo_profiles.hml").exists(), f"Missing HML in {hadl_dir}"


def test_hadl_supports_expanded_iddl_primitive_types(tmp_path: Path):
	"""HADL compose should parse expanded IDDL primitive types and initializers."""
	halo_composer = _import_halo_composer_module()

	hadls_root = tmp_path / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)

	(hadls_root / "system.adl").write_text(
		"""HALOFramework {
	components {
		Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
		Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
	}

	connections {
		connection Core1ToCore2 {
			from Core1 to Core2
			interface: PrimIf
			profile: sharedMemoryProfile1
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "profiles.hml").write_text(
		"""Profiles {
	SharedMemory sharedMemoryProfile1 {
		size: 64MB
		address: 0x80000000
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "interfaces.idl").write_text(
		"""include primitive_data.iddl

interface PrimIf {
	access {
		read {
			PrimitiveData
		}
		write {
			PrimitiveData
		}
	}

	integrity {
		crc16 {
			PrimitiveData
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "primitive_data.iddl").write_text(
		"""dataStructures {
	PrimitiveData {
		bool flag = True
		byte small = 7
		int count = 42
		integer count2 = 43
		float temp0 = 0.0
		float ratio = 3.5
		double precise0 = 0.0
		double precise = 9.25
		unsigned int uid = 99
		string label = "halo"
		byte payload[8] = 0
	}
}
""",
		encoding="utf-8",
	)

	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir), logging.ERROR)
	assert rc == 0

	obj = _load_json(out_dir / "halo_unified_model.json")
	structs = ((obj.get("dataTypes") or {}).get("structs") or {})
	prim = structs.get("PrimitiveData")
	assert isinstance(prim, dict), "Expected PrimitiveData struct in unified model"

	fields = prim.get("fields") or []
	by_name = {f.get("name"): f for f in fields if isinstance(f, dict)}

	assert by_name["flag"]["type"] == "bool"
	assert by_name["small"]["type"] == "byte"
	assert by_name["count"]["type"] == "int"
	assert by_name["count2"]["type"] == "integer"
	assert by_name["temp0"]["type"] == "float"
	assert by_name["ratio"]["type"] == "float"
	assert by_name["precise0"]["type"] == "double"
	assert by_name["precise"]["type"] == "double"
	assert by_name["uid"]["type"] == "unsignedint"
	assert by_name["label"]["type"] == "string"

	assert by_name["flag"]["init"]["value"] is True
	assert by_name["count"]["init"]["value"] == 42
	assert by_name["temp0"]["init"]["value"] == pytest.approx(0.0)
	assert by_name["ratio"]["init"]["value"] == pytest.approx(3.5)
	assert by_name["precise0"]["init"]["value"] == pytest.approx(0.0)
	assert by_name["precise"]["init"]["value"] == pytest.approx(9.25)
	assert by_name["label"]["init"]["value"] == "halo"
	assert by_name["payload"]["array"]["size"] == 8


def test_hadl_rejects_idl_includes_that_are_not_iddl(tmp_path: Path):
	"""IDL files may only include .iddl files."""
	halo_composer = _import_halo_composer_module()

	hadls_root = tmp_path / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)

	(hadls_root / "system.adl").write_text(
		"""HALOFramework {
	components {
		Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
		Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
	}

	connections {
		connection Core1ToCore2 {
			from Core1 to Core2
			interface: PrimIf
			profile: sharedMemoryProfile1
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "profiles.hml").write_text(
		"""Profiles {
	SharedMemory sharedMemoryProfile1 {
		size: 64MB
		address: 0x80000000
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "interfaces.idl").write_text(
		"""include primitive_data.idl

interface PrimIf {
	access {
		read { PrimitiveData }
		write { PrimitiveData }
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "primitive_data.idl").write_text(
		"""interface DummyIf {
	access { read {} write {} }
}
""",
		encoding="utf-8",
	)

	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir), logging.ERROR)
	assert rc == 1


def test_hadl_rejects_hml_includes_that_are_not_hmml(tmp_path: Path):
	"""HML files may only include .hmml files."""
	halo_composer = _import_halo_composer_module()

	hadls_root = tmp_path / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)

	(hadls_root / "system.adl").write_text(
		"""HALOFramework {
	components {
		Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
		Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
	}

	connections {
		connection Core1ToCore2 {
			from Core1 to Core2
			interface: PrimIf
			profile: sharedMemoryProfile1
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "interfaces.idl").write_text(
		"""include primitive_data.iddl

interface PrimIf {
	access {
		read { PrimitiveData }
		write { PrimitiveData }
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "primitive_data.iddl").write_text(
		"""dataStructures {
	PrimitiveData {
		integer cnt
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "profiles.hml").write_text(
		"""include local_profiles.hml

Profiles {
	SharedMemory sharedMemoryProfile1 {
		size: 64MB
		address: 0x80000000
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "local_profiles.hml").write_text(
		"""Profiles {
	SharedMemory otherProfile {
		size: 1MB
		address: 0x40000000
	}
}
""",
		encoding="utf-8",
	)

	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir), logging.ERROR)
	assert rc == 1


def test_hadl_allows_empty_integrity_block(tmp_path: Path):
	"""IDL should allow `integrity {}` with no entries."""
	halo_composer = _import_halo_composer_module()

	hadls_root = tmp_path / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)

	(hadls_root / "system.adl").write_text(
		"""HALOFramework {
	components {
		Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
		Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
	}

	connections {
		connection Core1ToCore2 {
			from Core1 to Core2
			interface: PrimIf
			profile: sharedMemoryProfile1
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "profiles.hml").write_text(
		"""Profiles {
	SharedMemory sharedMemoryProfile1 {
		size: 64MB
		address: 0x80000000
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "interfaces.idl").write_text(
		"""include primitive_data.iddl

interface PrimIf {
	access {
		read { PrimitiveData }
		write { PrimitiveData }
	}
	integrity {
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "primitive_data.iddl").write_text(
		"""dataStructures {
	PrimitiveData {
		integer cnt
	}
}
""",
		encoding="utf-8",
	)

	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir), logging.ERROR)
	assert rc == 0


def test_hadl_allows_braced_wildcard_integrity_targets(tmp_path: Path):
	"""IDL should allow `integrity { crc16 { * } }`."""
	halo_composer = _import_halo_composer_module()

	hadls_root = tmp_path / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)

	(hadls_root / "system.adl").write_text(
		"""HALOFramework {
	components {
		Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
		Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
	}

	connections {
		connection Core1ToCore2 {
			from Core1 to Core2
			interface: PrimIf
			profile: sharedMemoryProfile1
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "profiles.hml").write_text(
		"""Profiles {
	SharedMemory sharedMemoryProfile1 {
		size: 64MB
		address: 0x80000000
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "interfaces.idl").write_text(
		"""include primitive_data.iddl

interface PrimIf {
	access {
		read { PrimitiveData }
		write { PrimitiveData }
	}
	integrity {
		crc16 { * }
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "primitive_data.iddl").write_text(
		"""dataStructures {
	PrimitiveData {
		integer cnt
	}
}
""",
		encoding="utf-8",
	)

	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir), logging.ERROR)
	assert rc == 0


def test_hadl_allows_interface_without_integrity_block(tmp_path: Path):
	"""IDL should allow interfaces with only access and no integrity section."""
	halo_composer = _import_halo_composer_module()

	hadls_root = tmp_path / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)

	(hadls_root / "system.adl").write_text(
		"""HALOFramework {
	components {
		Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
		Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
	}

	connections {
		connection Core1ToCore2 {
			from Core1 to Core2
			interface: SensorFrameIf
			profile: sharedMemoryProfile1
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "profiles.hml").write_text(
		"""Profiles {
	SharedMemory sharedMemoryProfile1 {
		size: 64MB
		address: 0x80000000
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "interfaces.idl").write_text(
		"""include sensor_data.iddl

interface SensorFrameIf {
	access {
		read { SensorFrame }
		write { SensorFrame }
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "sensor_data.iddl").write_text(
		"""dataStructures {
	SensorFrame {
		float battery_temp_c = 0.5
	}
}
""",
		encoding="utf-8",
	)

	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir), logging.ERROR)
	assert rc == 0


def test_hadl_allows_read_only_access_block(tmp_path: Path):
	"""IDL should allow access blocks that define only read targets."""
	halo_composer = _import_halo_composer_module()

	hadls_root = tmp_path / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)

	(hadls_root / "system.adl").write_text(
		"""HALOFramework {
	components {
		Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
		Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
	}

	connections {
		connection Core1ToCore2 {
			from Core1 to Core2
			interface: SensorFrameIf
			profile: sharedMemoryProfile1
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "profiles.hml").write_text(
		"""Profiles {
	SharedMemory sharedMemoryProfile1 {
		size: 64MB
		address: 0x80000000
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "interfaces.idl").write_text(
		"""include sensor_data.iddl

interface SensorFrameIf {
	access {
		read { SensorFrame }
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "sensor_data.iddl").write_text(
		"""dataStructures {
	SensorFrame {
		float battery_temp_c = 0.5
	}
}
""",
		encoding="utf-8",
	)

	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir), logging.ERROR)
	assert rc == 0


def test_hadl_allows_write_only_access_block(tmp_path: Path):
	"""IDL should allow access blocks that define only write targets."""
	halo_composer = _import_halo_composer_module()

	hadls_root = tmp_path / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)

	(hadls_root / "system.adl").write_text(
		"""HALOFramework {
	components {
		Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
		Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
	}

	connections {
		connection Core1ToCore2 {
			from Core1 to Core2
			interface: SensorFrameIf
			profile: sharedMemoryProfile1
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "profiles.hml").write_text(
		"""Profiles {
	SharedMemory sharedMemoryProfile1 {
		size: 64MB
		address: 0x80000000
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "interfaces.idl").write_text(
		"""include sensor_data.iddl

interface SensorFrameIf {
	access {
		write { SensorFrame }
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "sensor_data.iddl").write_text(
		"""dataStructures {
	SensorFrame {
		float battery_temp_c = 0.5
	}
}
""",
		encoding="utf-8",
	)

	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir), logging.ERROR)
	assert rc == 0


def test_hadl_allows_nested_braced_wildcard_access_targets(tmp_path: Path):
	"""IDL should tolerate `read { { * } }`/`write { { * } }` in access blocks."""
	halo_composer = _import_halo_composer_module()

	hadls_root = tmp_path / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)

	(hadls_root / "system.adl").write_text(
		"""HALOFramework {
	components {
		Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
		Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
	}

	connections {
		connection Core1ToCore2 {
			from Core1 to Core2
			interface: SensorFrameIf
			profile: sharedMemoryProfile1
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "profiles.hml").write_text(
		"""Profiles {
	SharedMemory sharedMemoryProfile1 {
		size: 64MB
		address: 0x80000000
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "interfaces.idl").write_text(
		"""include sensor_data.iddl

interface SensorFrameIf {
	access {
		read { { * } }
		write { { * } }
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "sensor_data.iddl").write_text(
		"""dataStructures {
	SensorFrame {
		float battery_temp_c = 0.5
	}
}
""",
		encoding="utf-8",
	)

	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir), logging.ERROR)
	assert rc == 0


def test_hadl_allows_empty_integrity_entry_targets(tmp_path: Path):
	"""IDL should allow `integrity { crc32 { } }` with empty targets."""
	halo_composer = _import_halo_composer_module()

	hadls_root = tmp_path / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)

	(hadls_root / "system.adl").write_text(
		"""HALOFramework {
	components {
		Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
		Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
	}

	connections {
		connection Core1ToCore2 {
			from Core1 to Core2
			interface: OperatorCommandIf
			profile: sharedMemoryProfile1
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "profiles.hml").write_text(
		"""Profiles {
	SharedMemory sharedMemoryProfile1 {
		size: 64MB
		address: 0x80000000
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "interfaces.idl").write_text(
		"""include sensor_data.iddl

interface OperatorCommandIf {
	access {
		write { OperatorCommand }
	}
	integrity {
		crc32 {
		}
	}
}
""",
		encoding="utf-8",
	)

	(hadls_root / "sensor_data.iddl").write_text(
		"""dataStructures {
	OperatorCommand {
		integer command_id
	}
}
""",
		encoding="utf-8",
	)

	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir), logging.ERROR)
	assert rc == 0


def test_hadl_exporter_exports_custom_profiles_with_fallback_kind(tmp_path: Path):
	"""Custom/unknown profile kinds from XMI should still be exported to HADL.

	Today the exporter uses a heuristic for profile kind. If it can't detect a known
	kind, it falls back to SharedMemory (best-effort). This test ensures we don't
	crash and we preserve the profile instance name + attributes.
	"""
	# Import locally from the repo implementation.
	sw_dir = Path(__file__).resolve().parents[2]
	if str(sw_dir) not in sys.path:
		sys.path.insert(0, str(sw_dir))
	for mod in ("composer.hadl_exporter", "composer"):
		if mod in sys.modules:
			del sys.modules[mod]
	from composer.hadl_exporter import HADLExporter  # type: ignore

	model = {
		"components": [],
		"connections": [],
		"interfaces": {},
		"profiles": {
			"MyCustomProfile1": {
				"name": "MyCustomProfile1",
				"foo": "bar-baz",
				"enabled": True,
			},
		},
		"dataTypes": {"structs": {}},
	}

	out_dir = tmp_path / "hadl"
	HADLExporter().export(model, str(out_dir), system_name="custom_profile_test")
	hml = (out_dir / "halo_profiles.hml").read_text(encoding="utf-8")

	# Unknown kind should fall back to SharedMemory but keep the instance name.
	assert "SharedMemory MyCustomProfile1" in hml
	# Attributes should be emitted and values should be representable.
	assert "foo: \"bar-baz\"" in hml
	assert "enabled: True" in hml


def test_compose_from_xmi_prints_hadl_output_paths(capsys: pytest.CaptureFixture[str]):
	"""XMI import should print where HADL files were exported.

	This keeps the CLI UX stable (users can immediately locate generated .adl/.idl/.iddl/.hml).
	"""
	halo_composer = _import_halo_composer_module()

	tests_dir = Path(__file__).resolve().parent
	xmi_model_uml = tests_dir / "xmi_model" / "halo_model.uml"
	assert xmi_model_uml.exists(), f"Missing fixture: {xmi_model_uml}"

	out_dir = tests_dir / "out" / "xmi_out_hadl"
	import shutil
	shutil.rmtree(out_dir, ignore_errors=True)
	out_dir.mkdir(parents=True, exist_ok=True)
	assert halo_composer._compose_from_xmi(str(xmi_model_uml), str(out_dir)) == 0


def test_from_hadl_include_stdlib_profiles_merges_template_defaults():
	"""When --include-stdlib-profiles is enabled, HML instances inherit template defaults.

	This specifically verifies that profile instances defined in HML (without explicitly
	including halo_hml_profiles.hmml) get missing attributes filled from the stdlib templates.
	"""
	halo_composer = _import_halo_composer_module()

	tests_dir = Path(__file__).resolve().parent
	composer_dir = tests_dir.parent
	hadls_root = composer_dir / "dsl" / "hadls"
	assert hadls_root.exists(), f"Missing HADL fixtures folder: {hadls_root}"

	out_dir = tests_dir / "out" / "hadl_with_stdlib"
	out_dir.mkdir(parents=True, exist_ok=True)

	assert (
		halo_composer._compose_from_hadl(
			str(hadls_root),
			str(out_dir),
			logging.ERROR,
			include_stdlib_profiles=True,
		)
		== 0
	)

	obj = _load_json(out_dir / "halo_unified_model.json")
	profiles = obj.get("profiles") or {}

	# These instances come from dsl/hadls/halo_hml_profiles.hml, which does NOT include
	# halo_hml_profiles.hmml. The stdlib templates should fill in missing fields.
	mmio1 = profiles.get("MMIOProfileTest1")
	assert isinstance(mmio1, dict), "Expected MMIOProfileTest1 in unified model profiles"
	assert mmio1.get("cacheable") == False
	assert mmio1.get("priority") == "Low"
	assert mmio1.get("syncBlocking") is False


def test_public_compose_from_hadl_api_works_with_fixtures():
	"""Public Python API should compose from HADL without importing main()."""
	halo_composer = _import_halo_composer_module()

	tests_dir = Path(__file__).resolve().parent
	composer_dir = tests_dir.parent
	hadls_root = composer_dir / "dsl" / "hadls"
	assert hadls_root.exists(), f"Missing HADL fixtures folder: {hadls_root}"

	out_dir = tests_dir / "out" / "hadl_public_api"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer.compose_from_hadl(
		hadls_root=str(hadls_root),
		output_dir=str(out_dir),
		log_level="ERROR",
		include_stdlib_profiles=True,
	)
	assert rc == 0
	assert (out_dir / "halo_unified_model.json").exists()
	assert (out_dir / "halo_unified_model.pkl").exists()


def test_public_compose_from_xmi_api_works_with_fixtures():
	"""Public Python API should compose from XMI without importing main()."""
	halo_composer = _import_halo_composer_module()

	tests_dir = Path(__file__).resolve().parent
	xmi_model_uml = tests_dir / "xmi_model" / "halo_model.uml"
	assert xmi_model_uml.exists(), f"Missing fixture: {xmi_model_uml}"

	out_dir = tests_dir / "out" / "xmi_public_api"
	out_dir.mkdir(parents=True, exist_ok=True)

	rc = halo_composer.compose_from_xmi(
		xmi_path=str(xmi_model_uml),
		output_dir=str(out_dir),
	)
	assert rc == 0
	assert (out_dir / "halo_unified_model.json").exists()
	assert (out_dir / "halo_unified_model.pkl").exists()
	assert (out_dir / "hadl").exists()


def test_public_compose_from_hadl_api_raises_when_no_adl_files(tmp_path: Path):
	"""Public HADL API should raise a clear error when no .adl files exist."""
	halo_composer = _import_halo_composer_module()

	empty_hadls_root = tmp_path / "hadls_empty"
	empty_hadls_root.mkdir(parents=True, exist_ok=True)
	out_dir = tmp_path / "out"
	out_dir.mkdir(parents=True, exist_ok=True)

	with pytest.raises(ValueError, match=r"No \.adl files found"):
		halo_composer.compose_from_hadl(
			hadls_root=str(empty_hadls_root),
			output_dir=str(out_dir),
			log_level="ERROR",
		)
