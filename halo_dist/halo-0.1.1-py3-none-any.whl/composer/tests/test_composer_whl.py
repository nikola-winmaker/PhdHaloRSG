import contextlib
import importlib
import os
import shutil
import site
import sys
import sysconfig
from pathlib import Path

import pytest


@contextlib.contextmanager
def _prefer_site_packages_over_repo(repo_root: Path):
    """Temporarily adjust sys.path to prefer site-packages and avoid repo imports."""
    old = list(sys.path)
    try:
        paths = sysconfig.get_paths()
        purelib = paths.get("purelib")
        platlib = paths.get("platlib")
        site_dirs = [p for p in [purelib, platlib] if p]

        # Keep unique order
        seen = set()
        site_dirs_unique = []
        for p in site_dirs:
            if p not in seen:
                seen.add(p)
                site_dirs_unique.append(p)

        rest = []
        for p in old:
            try:
                pp = Path(p).resolve()
            except Exception:
                rest.append(p)
                continue
            # Drop anything inside the repo to avoid importing from source tree.
            if pp == repo_root or repo_root in pp.parents:
                continue
            rest.append(p)

        sys.path[:] = site_dirs_unique + rest
        yield
    finally:
        sys.path[:] = old


def _import_installed_halo_composer() -> object:
    """Import composer.halo_composer from the installed wheel (site-packages).

    This test is meant to validate that the *wheel installation* works, including
    package-data (grammars + stdlib .hmml). If we cannot import from site-packages,
    the test should fail with an actionable message (not skip).
    """
    repo_root = Path(__file__).resolve().parents[3]

    # Force re-import.
    for name in list(sys.modules.keys()):
        if name == "composer" or name.startswith("composer."):
            del sys.modules[name]

    with _prefer_site_packages_over_repo(repo_root):
        try:
            mod = importlib.import_module("composer.halo_composer")
        except ImportError as e:
            if os.environ.get("HALO_REQUIRE_INSTALLED_WHEEL") == "1":
                raise AssertionError(
                    "Failed to import composer.halo_composer from the current interpreter. "
                    "Install the built wheel into this environment, e.g. `pip install dist/halo-*.whl`, "
                    "then rerun this test. "
                    f"ImportError: {e}"
                ) from e
            pytest.skip(
                "composer.halo_composer is not installed in this interpreter; skipping wheel-only test. "
                "To run it, install the built wheel (e.g. `pip install dist/halo-*.whl`) or set "
                "HALO_REQUIRE_INSTALLED_WHEEL=1 to force failure."
            )

    mod_path = Path(getattr(mod, "__file__", "")).resolve()
    paths = sysconfig.get_paths()
    site_roots = [p for p in [paths.get("purelib"), paths.get("platlib")] if p]

    # Windows Store Python commonly installs user packages under LocalCache\...\site-packages,
    # which may not match sysconfig's purelib/platlib roots. Treat user site-packages as valid.
    try:
        usp = site.getusersitepackages()
        if usp:
            site_roots.append(usp)
    except Exception:
        pass
    try:
        for sp in getattr(site, "getsitepackages", lambda: [])() or []:
            if sp:
                site_roots.append(sp)
    except Exception:
        pass

    site_roots = list(dict.fromkeys(site_roots))

    if not any(Path(root).resolve() in mod_path.parents for root in site_roots):
        if os.environ.get("HALO_REQUIRE_INSTALLED_WHEEL") == "1":
            raise AssertionError(
                "composer.halo_composer did not resolve to site-packages. "
                "This usually means you're still importing the source tree (editable install or PYTHONPATH). "
                f"Resolved path: {mod_path}"
            )
        pytest.skip(
            "composer.halo_composer did not resolve to site-packages; skipping wheel-only test. "
            "Install the wheel into a clean environment or set HALO_REQUIRE_INSTALLED_WHEEL=1 to force failure. "
            f"Resolved path: {mod_path}"
        )

    return mod


def test_installed_wheel_can_compose_from_hadl_with_stdlib_profiles(tmp_path: Path):
    """Smoke test for a wheel installation.

    Validates:
    - The installed package contains grammars (required by _compose_from_hadl)
    - The packaged stdlib template halo_hml_profiles.hmml can be injected via
        include_stdlib_profiles=True (no copying into the project folder)
    """
    halo_composer = _import_installed_halo_composer()

    hadls_root = tmp_path / "hadls"
    out_dir = tmp_path / "out"
    hadls_root.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"HADL temp root: {hadls_root}")

    # --- minimal ADL
    (hadls_root / "sys.adl").write_text(
        """component MySystem {
    components {
        Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
        Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
    }

    connections {
        connection Core1ToCore2 {
            from Core1 to Core2
            interface: If1
            profile: MMIO0
        }
    }
    }
    """,
        encoding="utf-8",
    )

    # --- minimal IDL (+ include-only data file)
    (hadls_root / "data.iddl").write_text(
        """dataStructures {
    SharedData {
        integer cnt
    }
    }
    """,
        encoding="utf-8",
    )
    (hadls_root / "ifaces.idl").write_text(
        """include data.iddl

    interface If1 {
    access {
        read { SharedData }
        write { SharedData }
    }

    integrity {
        crc32 { SharedData }
    }
    }
    """,
        encoding="utf-8",
    )

    # --- HML instance WITHOUT including templates. Defaults should come from stdlib.
    (hadls_root / "profiles.hml").write_text(
        """Profiles {
    MemoryMappedIO MMIO0 {
        size: 1MB
        cacheable: False
        priority: Low
        syncBlocking: False
        address: 0xA0000000
    }
    }
    """,
        encoding="utf-8",
    )

    written = sorted([p.name for p in hadls_root.glob("*") if p.is_file()])
    print(f"HADL files written: {written}")

    rc = halo_composer._compose_from_hadl(
        str(hadls_root),
        str(out_dir),
        log_level=40,  # logging.ERROR
        include_stdlib_profiles=True,
    )
    assert rc == 0

    json_path = out_dir / "halo_unified_model.json"
    print(f"Unified model JSON path: {json_path}")
    assert json_path.exists()

    obj = __import__("json").loads(json_path.read_text(encoding="utf-8"))
    profiles = obj.get("profiles") or {}
    mmio = profiles.get("MMIO0")
    assert isinstance(mmio, dict)

    # Confirm template defaults are present (from packaged halo_hml_profiles.hmml).
    assert mmio.get("cacheable") == False
    assert mmio.get("priority") == "Low"
    assert mmio.get("syncBlocking") is False


def test_installed_wheel_exports_dot_and_renders_svg_when_graphviz_available(tmp_path: Path, capsys):
    """Wheel smoke test for DOT export + optional Graphviz rendering.

    Expectations:
    - Always writes halo_unified_model.dot
    - If Graphviz `dot` is available, also writes halo_unified_model.svg
    - If not available, logs a warning but still succeeds
    """

    halo_composer = _import_installed_halo_composer()

    hadls_root = tmp_path / "hadls"
    out_dir = tmp_path / "out"
    hadls_root.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)

    (hadls_root / "sys.adl").write_text(
        """component MySystem {
    components {
        Core1 : Component { Type: Application, Platform: Linux, Function: GeneralProcessing }
        Core2 : Component { Type: Application, Platform: FreeRTOS, Function: RealTimeProcessing }
    }

    connections {
        connection Core1ToCore2 {
            from Core1 to Core2
            interface: If1
            profile: MMIO0
        }
    }
    }
    """,
        encoding="utf-8",
    )

    (hadls_root / "data.iddl").write_text(
        """dataStructures {
    SharedData {
        integer cnt
    }
    }
    """,
        encoding="utf-8",
    )
    (hadls_root / "ifaces.idl").write_text(
        """include data.iddl

    interface If1 {
    access {
        read { SharedData }
        write { SharedData }
    }

    integrity {
        crc32 { SharedData }
    }
    }
    """,
        encoding="utf-8",
    )
    (hadls_root / "profiles.hml").write_text(
        """Profiles {
    MemoryMappedIO MMIO0 {
        size: 1MB
        address: 0xA0000000
    }
    }
    """,
        encoding="utf-8",
    )

    rc = halo_composer._compose_from_hadl(
        str(hadls_root),
        str(out_dir),
        log_level=20,  # logging.INFO (lets warnings through)
        include_stdlib_profiles=True,
    )
    assert rc == 0

    dot_path = out_dir / "halo_unified_model.dot"
    assert dot_path.exists(), "Expected DOT export to be produced by composer"

    svg_path = out_dir / "halo_unified_model.svg"

    # Our render helper checks PATH first, then a default Windows install location.
    dot_on_path = shutil.which("dot") is not None
    dot_default = Path(os.environ.get("ProgramFiles", r"C:\\Program Files")) / "Graphviz" / "bin" / "dot.exe"
    dot_available = dot_on_path or dot_default.exists()

    out = capsys.readouterr()
    if dot_available:
        assert svg_path.exists(), "Expected SVG render when Graphviz dot is available"
    else:
        # Rendering is optional; verify we warned rather than failing.
        assert "Graphviz 'dot'" in (out.err + out.out)
