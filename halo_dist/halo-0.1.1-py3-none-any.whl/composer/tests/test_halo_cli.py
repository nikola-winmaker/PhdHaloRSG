import sys
import types
from pathlib import Path

import pytest


def _import_halo_main_module():
    """Import the halo CLI entrypoint from the source tree."""
    sw_dir = Path(__file__).resolve().parents[2]
    if str(sw_dir) not in sys.path:
        sys.path.insert(0, str(sw_dir))

    for mod in ("halo.__main__", "halo"):
        if mod in sys.modules:
            del sys.modules[mod]

    import halo.__main__ as halo_main  # type: ignore

    return halo_main


def _install_fake_composer(monkeypatch: pytest.MonkeyPatch, *, return_code: int = 0) -> list[list[str]]:
    calls: list[list[str]] = []

    fake_pkg = types.ModuleType("composer")
    fake_pkg.__path__ = []  # type: ignore[attr-defined]
    fake_mod = types.ModuleType("composer.halo_composer")

    def fake_main(argv: list[str]) -> int:
        calls.append(list(argv))
        return return_code

    fake_mod.main = fake_main  # type: ignore[attr-defined]

    monkeypatch.setitem(sys.modules, "composer", fake_pkg)
    monkeypatch.setitem(sys.modules, "composer.halo_composer", fake_mod)
    return calls


def test_compose_dispatches_hadl_to_composer(monkeypatch: pytest.MonkeyPatch):
    halo_main = _import_halo_main_module()
    calls = _install_fake_composer(monkeypatch, return_code=7)

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "halo",
            "compose",
            "--hadls-root",
            "hadls",
            "--output-dir",
            "out",
            "--log-level",
            "DEBUG",
            "--include-stdlib-profiles",
            "--user-types",
            "types.json",
        ],
    )

    assert halo_main.main() == 7
    assert calls == [
        [
            "from-hadl",
            "--hadls-root",
            "hadls",
            "--output-dir",
            "out",
            "--log-level",
            "DEBUG",
            "--include-stdlib-profiles",
            "--user-types",
            "types.json",
        ]
    ]


def test_compose_dispatches_xmi_to_composer(monkeypatch: pytest.MonkeyPatch):
    halo_main = _import_halo_main_module()
    calls = _install_fake_composer(monkeypatch, return_code=5)

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "halo",
            "compose",
            "--from-xmi",
            "model.uml",
            "--output-dir",
            "out",
            "--user-types",
            "types.json",
        ],
    )

    assert halo_main.main() == 5
    assert calls == [
        [
            "from-xmi",
            "--input",
            "model.uml",
            "--output-dir",
            "out",
            "--user-types",
            "types.json",
        ]
    ]


def test_compose_rejects_stdlib_profiles_in_xmi_mode(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
):
    halo_main = _import_halo_main_module()

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "halo",
            "compose",
            "--from-xmi",
            "model.uml",
            "--output-dir",
            "out",
            "--include-stdlib-profiles",
        ],
    )

    with pytest.raises(SystemExit) as excinfo:
        halo_main.main()

    assert excinfo.value.code == 2
    assert "--include-stdlib-profiles is only supported with --hadls-root" in capsys.readouterr().err


def test_top_level_from_xmi_command_is_not_available(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
):
    halo_main = _import_halo_main_module()

    monkeypatch.setattr(
        sys,
        "argv",
        ["halo", "from-xmi", "--input", "model.uml", "--output-dir", "out"],
    )

    with pytest.raises(SystemExit) as excinfo:
        halo_main.main()

    assert excinfo.value.code == 2
    assert "invalid choice: 'from-xmi'" in capsys.readouterr().err
