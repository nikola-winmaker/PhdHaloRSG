import json
import os
import re
from dataclasses import dataclass
from typing import Any, Iterable

from jinja2 import Environment, FileSystemLoader, StrictUndefined


_ID_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_HEX_RE = re.compile(r"^0[xX][0-9a-fA-F]+$")
_SIZE_RE = re.compile(r"^\d+(B|kB|MB|GB)$")


def _sanitize_id(value: Any) -> str:
    s = "" if value is None else str(value)
    s = re.sub(r"[^A-Za-z0-9_]", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    if not s:
        s = "id"
    if s[0].isdigit():
        s = f"_{s}"
    return s


def _idl_type(t: Any) -> str:
    if t is None:
        return "integer"
    s = str(t).strip()
    s_low = s.replace(" ", "").lower()
    if s_low in ("unsignedint", "uint", "u32", "unsigned"):
        return "unsigned int"
    if s_low in ("int", "integer", "i32"):
        return "integer"
    if s_low in ("byte", "u8"):
        return "byte"
    # Fall back to the raw token; grammar accepts only the above, but we prefer
    # a predictable output rather than crashing.
    return "integer"


def _hml_value(v: Any) -> str:
    if isinstance(v, bool):
        return "True" if v else "False"
    if isinstance(v, int):
        return str(v)
    if v is None:
        return "None"

    s = str(v)
    if _HEX_RE.match(s) or _SIZE_RE.match(s) or _ID_RE.match(s):
        return s

    escaped = s.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def _profile_kind(profile_name: str, profile: dict[str, Any]) -> str:
    n = (profile_name or "").lower()
    keys = {k.lower() for k in profile.keys()}

    if "controller" in keys or "channel" in keys or "src" in keys or "dst" in keys or "dma" in n:
        return "DMA"
    if "mmio" in n:
        return "MemoryMappedIO"
    if "shared" in n or "synctype" in keys or "syncprimitive" in keys or "coherence" in keys:
        return "SharedMemory"

    # Best-effort default.
    return "SharedMemory"


@dataclass(frozen=True)
class _ProfileItem:
    key: str
    value: str


@dataclass(frozen=True)
class _ProfileView:
    kind: str
    name: str
    items: list[_ProfileItem]


class HADLExporter:
    """Export HADL files (.adl/.idl/.iddl/.hml) from a HALO unified model dict."""

    def __init__(self, templates_dir: str | None = None):
        if templates_dir is None:
            templates_dir = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "dsl", "templates"
            )
        self._env = Environment(
            loader=FileSystemLoader(templates_dir),
            undefined=StrictUndefined,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self._env.filters["sanitize_id"] = _sanitize_id

    def export(
        self,
        model: dict[str, Any],
        output_dir: str,
        *,
        system_name: str = "halo_system",
        user_types: dict[str, list[str]] | None = None,
        user_types_filename: str = "user_types.json",
    ) -> dict[str, str]:
        os.makedirs(output_dir, exist_ok=True)

        if user_types:
            user_types_path = os.path.join(output_dir, user_types_filename)
            with open(user_types_path, "w", encoding="utf-8") as f:
                json.dump(user_types, f, indent=2, sort_keys=True)

        components = list(model.get("components") or [])
        connections = list(model.get("connections") or [])

        interfaces_dict = model.get("interfaces") or {}
        profiles_dict = model.get("profiles") or {}
        structs_dict = ((model.get("dataTypes") or {}).get("structs") or {})

        # ---- ADL ----
        adl_path = os.path.join(output_dir, f"{_sanitize_id(system_name)}.adl")
        adl_tpl = self._env.get_template("adl.j2")
        adl_payload = adl_tpl.render(
            system_name=system_name,
            components=sorted(components, key=lambda c: str((c or {}).get("name", ""))),
            connections=sorted(connections, key=lambda c: str((c or {}).get("name", ""))),
        )
        with open(adl_path, "w", encoding="utf-8") as f:
            f.write(adl_payload)

        # ---- IDDL (structs) ----
        iddl_name = "halo_interface_data.iddl"
        iddl_path = os.path.join(output_dir, iddl_name)
        iddl_tpl = self._env.get_template("interface_data.iddl.j2")

        structs_view: list[dict[str, Any]] = []
        for sname, sobj in sorted(structs_dict.items(), key=lambda kv: str(kv[0])):
            fields = []
            for field in (sobj.get("fields") if isinstance(sobj, dict) else []) or []:
                array_size = None
                init_value = None
                if isinstance(field, dict):
                    arr = field.get("array")
                    if isinstance(arr, dict) and isinstance(arr.get("size"), int):
                        array_size = arr["size"]
                    init = field.get("init")
                    if isinstance(init, dict) and "value" in init:
                        init_value = init.get("value")

                    fields.append(
                        {
                            "type": _idl_type(field.get("type")),
                            "name": field.get("name"),
                            "array_size": array_size,
                            "init_value": init_value,
                        }
                    )

            structs_view.append({"name": sname, "fields": fields})

        iddl_payload = iddl_tpl.render(structs=structs_view)
        with open(iddl_path, "w", encoding="utf-8") as f:
            f.write(iddl_payload)

        # ---- IDL (interfaces) ----
        idl_path = os.path.join(output_dir, "halo_interfaces.idl")
        idl_tpl = self._env.get_template("interfaces.idl.j2")

        interfaces_view: list[dict[str, Any]] = []
        for iname, iobj in sorted(interfaces_dict.items(), key=lambda kv: str(kv[0])):
            if not isinstance(iobj, dict):
                continue

            access = iobj.get("access") or {}
            reads = (access.get("reads") or []) if isinstance(access, dict) else []
            writes = (access.get("writes") or []) if isinstance(access, dict) else []

            integrity = iobj.get("integrity") or {}
            entries = (integrity.get("entries") or []) if isinstance(integrity, dict) else []
            integrity_entries: list[dict[str, Any]] = []
            for e in entries:
                if not isinstance(e, dict):
                    continue
                targets = ((e.get("targets") or {}).get("refs") or [])
                integrity_entries.append(
                    {"type": e.get("type"), "targets": list(targets) if isinstance(targets, list) else []}
                )

            interfaces_view.append(
                {
                    "name": iname,
                    "reads": list(reads) if isinstance(reads, list) else [],
                    "writes": list(writes) if isinstance(writes, list) else [],
                    "integrity_entries": integrity_entries,
                }
            )

        idl_payload = idl_tpl.render(iddl_name=iddl_name, interfaces=interfaces_view)
        with open(idl_path, "w", encoding="utf-8") as f:
            f.write(idl_payload)

        # ---- HML (profiles) ----
        hml_path = os.path.join(output_dir, "halo_profiles.hml")
        hml_tpl = self._env.get_template("profiles.hml.j2")

        profiles_view: list[_ProfileView] = []
        for pname, pobj in sorted(profiles_dict.items(), key=lambda kv: str(kv[0])):
            if not isinstance(pobj, dict):
                continue

            kind = _profile_kind(pname, pobj)

            # Prefer HADL dialect keys in output.
            items: list[_ProfileItem] = []
            for k, v in sorted(pobj.items(), key=lambda kv: str(kv[0])):
                if k == "name":
                    continue
                out_k = k
                if k == "memSize":
                    out_k = "size"
                elif k == "baseAddress":
                    out_k = "address"
                items.append(_ProfileItem(key=out_k, value=_hml_value(v)))

            profiles_view.append(_ProfileView(kind=kind, name=pname, items=items))

        hml_payload = hml_tpl.render(profiles=profiles_view)
        with open(hml_path, "w", encoding="utf-8") as f:
            f.write(hml_payload)

        return {
            "adl": adl_path,
            "iddl": iddl_path,
            "idl": idl_path,
            "hml": hml_path,
        }
