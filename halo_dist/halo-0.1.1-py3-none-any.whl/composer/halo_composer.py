import pickle
import json
import colorama
import argparse
from textx import metamodel_from_file
from textx import scoping
from dataclasses import dataclass, field
from typing import List, Dict, Any
import logging
import os
import glob
import re
from pathlib import Path
from types import SimpleNamespace
import hashlib
import shutil
import subprocess

try:
    # Source-tree/dev layout (when running with sw/composer on sys.path)
    from uml.halo_uml_xmi import HALOUMLXMIExporter
    from uml.halo_plantuml import HALOPlantUMLGenerator
    from uml.halo_to_uml import convert_halo_to_uml
    from uml.uml_ir_xmi import UMLIRXMIExporter
    from uml.uml_to_halo import load_xmi_to_halo_unified_model
    from hadl_exporter import HADLExporter
    from uml.halo_value_domains import (
        DEFAULT_HALO_ENUMS,
        COMPONENT_KEY_TO_ENUM,
        PROFILE_KEY_TO_ENUM,
        merge_enums,
        enum_literals_by_name,
        is_address_field,
        address_type_and_value,
        load_user_types_from_json,
    )
except ImportError:
    # Wheel/install layout
    from composer.uml.halo_uml_xmi import HALOUMLXMIExporter
    from composer.uml.halo_plantuml import HALOPlantUMLGenerator
    from composer.uml.halo_to_uml import convert_halo_to_uml
    from composer.uml.uml_ir_xmi import UMLIRXMIExporter
    from composer.uml.uml_to_halo import load_xmi_to_halo_unified_model
    from composer.hadl_exporter import HADLExporter
    from composer.uml.halo_value_domains import (
        DEFAULT_HALO_ENUMS,
        COMPONENT_KEY_TO_ENUM,
        PROFILE_KEY_TO_ENUM,
        merge_enums,
        enum_literals_by_name,
        is_address_field,
        address_type_and_value,
        load_user_types_from_json,
    )


def _build_value_domains(*, user_types: Dict[str, List[str]] | None) -> Dict[str, Any]:
    """Build the value-domain section for the unified model.

    This is the single source of truth for code generation of enumerations.
    """

    merged = merge_enums(DEFAULT_HALO_ENUMS, user_types or {})
    return {
        "schemaVersion": 1,
        "enums": merged,
        "componentKeyToEnum": COMPONENT_KEY_TO_ENUM,
        "profileKeyToEnum": PROFILE_KEY_TO_ENUM,
    }

class _ColoredFormatter(logging.Formatter):
    FORMATS = {
        logging.ERROR: colorama.Fore.RED + '%(levelname)s: %(message)s' + colorama.Style.RESET_ALL,
        logging.WARNING: colorama.Fore.YELLOW + '%(levelname)s: %(message)s' + colorama.Style.RESET_ALL,
        logging.INFO: colorama.Fore.GREEN + '%(levelname)s: %(message)s' + colorama.Style.RESET_ALL,
        logging.DEBUG: colorama.Fore.BLUE + '%(levelname)s: %(message)s' + colorama.Style.RESET_ALL
    }
    
    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno, '%(levelname)s: %(message)s')
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


def _find_graphviz_dot() -> str | None:
    dot_exe = shutil.which("dot")
    if dot_exe:
        return dot_exe
    # Common Windows install location.
    program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
    candidate = os.path.join(program_files, "Graphviz", "bin", "dot.exe")
    if os.path.exists(candidate):
        return candidate
    return None


def _render_dot_tb(dot_path: str, svg_path: str, *, logger: logging.Logger) -> None:
    dot_exe = _find_graphviz_dot()
    if not dot_exe:
        logger.warning(
            "Graphviz 'dot' was not found (not on PATH, and not at the default install location). "
            "Skipping SVG render: %s",
            svg_path,
        )
        return

    try:
        subprocess.run(
            [dot_exe, "-Grankdir=TB", "-Tsvg", dot_path, "-o", svg_path],
            check=True,
        )
        logger.info("Communication model SVG saved to %s", svg_path)
    except Exception as e:
        logger.warning("Failed to render DOT via Graphviz: %s", e)
        
@dataclass
class _ConnectionData:
    name: str
    from_component: str
    to_component: str
    interface: Any
    profile: Any
    
    def to_dict(self):
        return {
            'name': self.name,
            'from_component': self.from_component,
            'to_component': self.to_component,
            'interface': self.interface.name if hasattr(self.interface, 'name') else str(self.interface),
            'profile': self.profile.name if self.profile else None
        }

@dataclass
class _ComponentData:
    name: str
    type: str
    platform: str
    function: str
    incoming_connections: List['_ConnectionData'] = field(default_factory=list)
    outgoing_connections: List['_ConnectionData'] = field(default_factory=list)
    profiles: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self, include_profiles: bool = True):
        def serialize_value(val):
            if hasattr(val, '__dict__'):
                return {key: serialize_value(v) for key, v in val.__dict__.items() if not key.startswith('_') and key != 'parent'}
            elif isinstance(val, list):
                return [serialize_value(item) for item in val]
            elif isinstance(val, dict):
                return {k: serialize_value(v) for k, v in val.items()}
            else:
                return str(val) if not isinstance(val, (str, int, float, bool, type(None))) else val
        
        out = {
            'name': self.name,
            'type': self.type,
            'platform': self.platform,
            'function': self.function,
            'incoming_connections': [conn.name for conn in self.incoming_connections],
            'outgoing_connections': [conn.name for conn in self.outgoing_connections],
        }

        if include_profiles:
            out['profiles'] = {k: serialize_value(v) for k, v in self.profiles.items()}

        return out

class HALOComposer:
    def __init__(self, adl_grammar_file, adl_file,
                 idl_grammar_file=None, idl_files=None,
                 profile_grammar_file=None, profile_files=None, 
                 log_level=logging.ERROR,
                 user_types: Dict[str, List[str]] | None = None):

        self.adl_grammar_file = adl_grammar_file
        self.idl_grammar_file = idl_grammar_file
        self.profile_grammar_file = profile_grammar_file

        self.model_file = adl_file

        # Optional user-provided value-domain extensions (merged with DEFAULT_HALO_ENUMS).
        self.user_types = user_types if user_types is not None else {}
        self.idl_files = idl_files or []
        self.profile_files = profile_files or []
        self.adl_mm = None
        self.idl_mm = None
        self.profile_mm = None
        self.adl_descr = None
        self.idl_descr = []
        self.profile_descr = []
        self.model_ast = None
        self.uml_ir = None  # Store the UML IR model

        # Configure logging with colored output for errors
        colorama.init(autoreset=True)

        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(log_level)
        handler = logging.StreamHandler()
        handler.setFormatter(_ColoredFormatter())
        self.logger.addHandler(handler)
        self.logger.debug("HALO Composer initialized.")


    def parse_adl_model(self):
        """
        This function loads the ADL grammar from a file and parses the ADL model.
        """
        # Load the grammar file from disk
        try:
            self.adl_mm = metamodel_from_file(self.adl_grammar_file)
        except Exception as e:
            self.logger.error(f"Error loading ADL grammar file: {e}")
            raise e

        # Load the ADL model file from disk and parse it
        try:
            with open(self.model_file, 'r') as f:
                adl_content = f.read()
            # Parse the ADL model
            self.adl_descr = self.adl_mm.model_from_str(adl_content)
        except FileNotFoundError:
            self.logger.error(f"ADL model file not found: {self.model_file}")
            raise ValueError("ADL model file not found.")
        except Exception as e:
            self.logger.error(f"Error reading ADL model file: {e}")
            raise e


    def parse_idl_files(self):
        """
        Parse the provided IDL files using the same grammar or different grammar if needed.
        """
        if not self.idl_files:
            self.logger.warning("No IDL files provided.")
            exit()

        # Reset to avoid duplicates if called multiple times.
        self.idl_descr = []

        # Assuming the same grammar file or different IDL grammar (if different grammar, adjust accordingly)
        try:
            idl_mm = metamodel_from_file(self.idl_grammar_file)
            # idl_mm.register_scope_providers({"*.*": scoping.providers.FQN(), 
            #                                  "Connection.from_port": "from_inst.component.slots",  # RREL
            #                                  "Connection.to_port": "from_inst.component.slots"      # RREL
            #                                  })
        except Exception as e:
            self.logger.error(f"Error loading IDL grammar file: {e}")
            raise e

        parsed_files = set()

        def _norm(path: str) -> str:
            return os.path.normcase(os.path.abspath(os.path.normpath(path)))

        def _attach_shared_data(model):
            shared_data = getattr(model, 'data', None)
            if shared_data:
                for iface in getattr(model, 'interfaces', []) or []:
                    if getattr(iface, 'data', None) is None:
                        iface.data = shared_data

        def _coerce_field_initializers(model):
            """Normalize parsed initializer values to expected scalar Python types."""

            def _iter_structs_from_data(data_obj):
                for st in getattr(data_obj, 'structs', []) or []:
                    if hasattr(st, 'fields'):
                        yield st

            seen_struct_ids = set()
            struct_lists = []

            top_data = getattr(model, 'data', None)
            if top_data is not None:
                struct_lists.append(top_data)

            for iface in getattr(model, 'interfaces', []) or []:
                iface_data = getattr(iface, 'data', None)
                if iface_data is not None:
                    struct_lists.append(iface_data)

            for data_obj in struct_lists:
                for st in _iter_structs_from_data(data_obj):
                    sid = id(st)
                    if sid in seen_struct_ids:
                        continue
                    seen_struct_ids.add(sid)

                    for field in getattr(st, 'fields', []) or []:
                        init = getattr(field, 'init', None)
                        if not init or not hasattr(init, 'value'):
                            continue

                        raw = init.value
                        ftype = str(getattr(field, 'type', '')).replace(' ', '').lower()

                        if isinstance(raw, str):
                            v = raw.strip()

                            if ftype in ('float', 'double'):
                                try:
                                    init.value = float(v)
                                    continue
                                except ValueError:
                                    pass

                            if ftype in ('int', 'integer', 'unsignedint'):
                                # Accept any numeric string (int or float), truncate to int
                                try:
                                    init.value = int(float(v))
                                    continue
                                except ValueError:
                                    pass

                            if ftype == 'bool':
                                if v.lower() == 'true':
                                    init.value = True
                                elif v.lower() == 'false':
                                    init.value = False

        def _type_refs_all(refs_obj) -> bool:
            return bool(refs_obj) and getattr(refs_obj, 'all', None) == '*'

        def _collect_referenced_struct_names(iface) -> tuple[bool, set[str]]:
            """Return (all_structs, names) referenced by access/integrity for an interface."""
            names: set[str] = set()
            all_structs = False

            access = getattr(iface, 'access', None)
            if access:
                for rl in getattr(access, 'readLines', []) or []:
                    reads = getattr(rl, 'reads', None)
                    if _type_refs_all(reads):
                        all_structs = True
                    for r in (getattr(reads, 'refs', None) or []):
                        names.add(str(r))
                for wl in getattr(access, 'writeLines', []) or []:
                    writes = getattr(wl, 'writes', None)
                    if _type_refs_all(writes):
                        all_structs = True
                    for r in (getattr(writes, 'refs', None) or []):
                        names.add(str(r))

            integrity = getattr(iface, 'integrity', None)
            if integrity:
                for entry in getattr(integrity, 'entries', []) or []:
                    targets = getattr(entry, 'targets', None)
                    if _type_refs_all(targets):
                        all_structs = True
                    for r in (getattr(targets, 'refs', None) or []):
                        names.add(str(r))

            return all_structs, names

        def _struct_entry_names(struct_entry) -> set[str]:
            """Names a struct entry can be referenced by (def name, ref tail, full ref)."""
            out = set()
            if hasattr(struct_entry, 'name'):
                out.add(str(struct_entry.name))
            if hasattr(struct_entry, 'reference'):
                ref = str(struct_entry.reference)
                out.add(ref)
                if '.' in ref:
                    out.add(ref.split('.')[-1])
            return out

        def _filter_interface_data(model):
            """Reduce iface.data.structs to only the structs that iface references."""
            for iface in getattr(model, 'interfaces', []) or []:
                data = getattr(iface, 'data', None)
                if not data or not getattr(data, 'structs', None):
                    iface.data = SimpleNamespace(structs=[])
                    continue

                all_structs, needed = _collect_referenced_struct_names(iface)
                if all_structs:
                    continue

                if not needed:
                    iface.data = SimpleNamespace(structs=[])
                    continue

                filtered = []
                for s in getattr(data, 'structs', []) or []:
                    if _struct_entry_names(s) & needed:
                        filtered.append(s)
                iface.data = SimpleNamespace(structs=filtered)

        def _resolve_structs_for_names(structs, names: set[str]):
            out = []
            for s in structs or []:
                if _struct_entry_names(s) & names:
                    out.append(s)
            return out

        def _annotate_interface_access(model):
            """Attach resolved struct objects to access/integrity for downstream tooling."""
            for iface in getattr(model, 'interfaces', []) or []:
                structs = list(getattr(getattr(iface, 'data', None), 'structs', []) or [])

                access = getattr(iface, 'access', None)
                if access:
                    read_all = False
                    read_names: set[str] = set()
                    for rl in getattr(access, 'readLines', []) or []:
                        reads = getattr(rl, 'reads', None)
                        if _type_refs_all(reads):
                            read_all = True
                        for r in (getattr(reads, 'refs', None) or []):
                            read_names.add(str(r))

                    write_all = False
                    write_names: set[str] = set()
                    for wl in getattr(access, 'writeLines', []) or []:
                        writes = getattr(wl, 'writes', None)
                        if _type_refs_all(writes):
                            write_all = True
                        for r in (getattr(writes, 'refs', None) or []):
                            write_names.add(str(r))

                    access.readStructs = structs if read_all else _resolve_structs_for_names(structs, read_names)
                    access.writeStructs = structs if write_all else _resolve_structs_for_names(structs, write_names)

                integrity = getattr(iface, 'integrity', None)
                if integrity:
                    by_type: Dict[str, List[Any]] = {}
                    by_type_refs: Dict[str, List[str]] = {}
                    for entry in getattr(integrity, 'entries', []) or []:
                        etype = str(getattr(entry, 'type', 'integrity'))
                        targets = getattr(entry, 'targets', None)
                        if _type_refs_all(targets):
                            by_type[etype] = structs
                            by_type_refs[etype] = ['*']
                        else:
                            raw_names = [str(r) for r in (getattr(targets, 'refs', None) or [])]
                            names_set = set(raw_names)

                            # Merge (union) across multiple entries of the same type.
                            if by_type_refs.get(etype) == ['*']:
                                # Already all
                                pass
                            else:
                                prev_names = by_type_refs.get(etype, [])
                                # Keep insertion order + unique
                                merged_names = prev_names + [n for n in raw_names if n not in prev_names]
                                by_type_refs[etype] = merged_names

                            if by_type.get(etype) is structs:
                                # Already all
                                pass
                            else:
                                prev_structs = by_type.get(etype, [])
                                resolved = _resolve_structs_for_names(structs, names_set)
                                # Keep insertion order + unique by object id
                                seen_ids = {id(s) for s in prev_structs}
                                merged_structs = prev_structs + [s for s in resolved if id(s) not in seen_ids]
                                by_type[etype] = merged_structs

                    # Public shape: crc_type -> structures (resolved) + raw refs for display/debug
                    integrity.byType = by_type
                    integrity.byTypeRefs = by_type_refs

        interfaces_by_name: Dict[str, Any] = {}

        for idl_file in self.idl_files:
            try:
                norm_entry = _norm(idl_file)
                if norm_entry in parsed_files:
                    continue
                expanded_content, _visited_files = self._read_file_with_includes_and_visited(idl_file)
                entry_model = idl_mm.model_from_str(expanded_content)
                _attach_shared_data(entry_model)
                _coerce_field_initializers(entry_model)
                _filter_interface_data(entry_model)
                _annotate_interface_access(entry_model)

                for iface in getattr(entry_model, 'interfaces', []) or []:
                    iname = getattr(iface, 'name', None)
                    if not iname:
                        continue
                    if iname in interfaces_by_name:
                        self.logger.warning(f"Duplicate interface '{iname}' across IDL files; last one wins.")
                    interfaces_by_name[iname] = iface
                parsed_files.add(norm_entry)
            except FileNotFoundError as e:
                err_msg = str(e)
                include_prefix = "Include file not found:"

                if include_prefix in err_msg:
                    missing_path = err_msg.split(include_prefix, 1)[1].strip()
                    self.logger.error(
                        "Included file not found while parsing IDL '%s': %s",
                        idl_file,
                        missing_path,
                    )
                    raise ValueError(
                        f"Included file not found while parsing IDL '{idl_file}': {missing_path}"
                    ) from e

                self.logger.error("IDL file not found: %s", idl_file)
                raise ValueError(f"IDL file not found: {idl_file}") from e
            except Exception as e:
                self.logger.error(f"Error parsing IDL file {idl_file}: {e}")
                raise e

        # Keep a single consolidated model-like object, similar to profiles.
        self.idl_descr = [SimpleNamespace(interfaces=list(interfaces_by_name.values()))]

    def get_idl_interfaces(self, idl_models):
        # Iterate through ADL connections and enrich with IDL/HML data
        # Build IDL and HML lookup dictionaries
        idl_interfaces = {}
        for idl_model in idl_models:
            for interface in idl_model.interfaces:
                idl_interfaces[interface.name] = interface

        return idl_interfaces

    def parse_hml_profile_files(self):
        """Parse hardware mapping profile files using the dedicated profile grammar."""
        if not self.profile_files:
            self.logger.warning("No profile files provided.")
            raise ValueError("No profile files provided.")

        try:
            self.profile_mm = metamodel_from_file(self.profile_grammar_file)
        except Exception as e:
            self.logger.error(f"Error loading profile grammar file: {e}")
            raise e

        for profile_file in self.profile_files:
            try:
                content = self._read_file_with_includes(profile_file)
                model = self.profile_mm.model_from_str(content)
                self.profile_descr.append(model)
            except Exception as e:
                self.logger.error(f"Error parsing profile file {profile_file}: {e}")
                raise e

        # Reduce parsed profiles to only the named instances used by ADL.
        # Included .hmml template profiles are treated as part of the .hml content,
        # but we don't keep them as standalone entries after merging.
        merged_instances = self.get_hml_profiles(self.profile_descr)  # name -> profile (defaults merged)

        # Keep all named instances described by hml (across all .hml files).
        # Filtering to only ADL-referenced profile names happens later during composition.
        self.profile_descr = [SimpleNamespace(profiles=list(merged_instances.values()))]

    def get_hml_profiles(self, profile_models):
        """Return name->profile instance mapping.

        HML parsing produces:
          - Template profiles (from .hmml): usually no instance name (name is None)
          - Instance profiles (from .hml): name is the identifier referenced in ADL

        Instances inherit default attributes from their template (same kind),
        and then override with their own specified values.
        """
        templates_by_kind = {}
        instances = []

        for profile_model in profile_models:
            for prof in getattr(profile_model, 'profiles', []) or []:
                self._materialize_profile_attributes(prof)

                kind = getattr(prof, 'kind', prof.__class__.__name__)
                inst_name = getattr(prof, 'name', None)
                if inst_name:
                    instances.append((inst_name, kind, prof))
                else:
                    # Template: last one wins for the same kind
                    if kind:
                        templates_by_kind[kind] = prof

        # Merge defaults from template -> instance (fill missing only)
        for inst_name, kind, prof in instances:
            tmpl = templates_by_kind.get(kind)
            if tmpl:
                self._merge_profile_defaults(dst=prof, src=tmpl)

        # Return only instances (templates aren't referenced from ADL)
        hml_profiles = {}
        for inst_name, _kind, prof in instances:
            hml_profiles[inst_name] = prof
        return hml_profiles

    # ----------------------------
    # Include preprocessing helpers
    # ----------------------------
    _include_re = re.compile(r"^\s*include\s+([^\s]+)\s*$")

    def _read_file_with_includes(self, entry_file: str) -> str:
        """Read a HADL/IDL/HML file and inline all `include <path>` directives."""
        expanded, _visited = self._read_file_with_includes_and_visited(entry_file)
        return expanded

    def _read_file_with_includes_and_visited(self, entry_file: str):
        """Read a file, inline includes, and also return the visited file list.

        - Includes are resolved relative to the including file.
        - Included files can themselves contain includes.
        - Cycles are ignored (file content included once).
        - Supports both `include foo.iddl` and `include <foo.iddl>`.
        """
        def _norm(path: str) -> str:
            return os.path.normcase(os.path.abspath(os.path.normpath(path)))

        def _resolve_include_path(base_dir: str, include_ref: str, including_file: str) -> str:
            """Resolve include references and enforce grammar-specific extension rules."""
            include_ref = include_ref.strip()
            including_ext = Path(including_file).suffix.lower()
            include_ext = Path(include_ref).suffix.lower()

            if including_ext == '.idl' and include_ext != '.iddl':
                raise ValueError(
                    f"Invalid include '{include_ref}' in IDL file '{including_file}'. "
                    "Only .iddl files can be included from .idl files."
                )

            if including_ext == '.hml' and include_ext != '.hmml':
                raise ValueError(
                    f"Invalid include '{include_ref}' in HML file '{including_file}'. "
                    "Only .hmml files can be included from .hml files."
                )

            direct_path = os.path.join(base_dir, include_ref)
            if not os.path.exists(direct_path):
                raise FileNotFoundError(f"Include file not found: {direct_path}")
            return direct_path

        visited_set = set()
        visited_list = []

        def _read_recursive(path: str) -> str:
            abspath = os.path.abspath(path)
            norm = _norm(path)
            if norm in visited_set:
                return ""
            visited_set.add(norm)
            visited_list.append(abspath)

            try:
                with open(abspath, 'r', encoding='utf-8') as f:
                    txt = f.read()
            except UnicodeDecodeError:
                with open(abspath, 'r') as f:
                    txt = f.read()

            base_dir = os.path.dirname(abspath)
            out_lines = []
            for line in txt.splitlines(True):
                m = self._include_re.match(line)
                if m:
                    inc = m.group(1).strip().strip('<>').strip()
                    inc_path = _resolve_include_path(base_dir, inc, abspath)
                    out_lines.append(_read_recursive(inc_path))
                    out_lines.append("\n")
                else:
                    out_lines.append(line)
            return "".join(out_lines)

        expanded = _read_recursive(entry_file)
        return expanded, visited_list

    # --------------------------------
    # Profile normalization and merging
    # --------------------------------
    def _materialize_profile_attributes(self, prof):
        """Turn parsed Attribute items into direct attributes on the profile object.

        The HML grammar parses bodies as a list of `items` (key/value). For tooling
        and exporters that expect plain attributes, we materialize them.
        """
        items = getattr(prof, 'items', None)
        # `items` exists even for empty bodies (e.g., DMA DmaProfile5 {}).
        # Always strip it so it doesn't leak into exported UML.
        if items is None:
            return

        kind = getattr(prof, 'kind', prof.__class__.__name__)

        def convert(val):
            # Size objects: value + unit
            if hasattr(val, 'value') and hasattr(val, 'unit'):
                return f"{val.value}{val.unit}"
            # Booleans come through as strings from the grammar
            if isinstance(val, str) and val.lower() in ('true', 'false'):
                return val.lower() == 'true'
            # Strip quotes from strings
            if isinstance(val, str) and len(val) >= 2 and val[0] == '"' and val[-1] == '"':
                return val[1:-1]
            return val

        # Canonicalize keys so different dialects map to the same attribute names
        common_aliases = {
            'size': 'memSize',
            'memSize': 'memSize',
            'address': 'baseAddress',
            'baseAddress': 'baseAddress',
        }

        for it in items:
            key = getattr(it, 'key', None)
            raw_val = getattr(it, 'val', None)
            if not key:
                continue

            # Avoid clobbering the profile identifier (used by ADL references).
            # In DMA profiles the body often uses `name: DMA0` to mean controller name.
            if kind == 'DMA' and key == 'name':
                attr = 'controller'
            else:
                attr = common_aliases.get(key, key)

            setattr(prof, attr, convert(raw_val))

        # Remove raw items list to keep exports clean
        try:
            delattr(prof, 'items')
        except Exception:
            pass

        # Ensure a canonical profile type field is present (e.g., SharedMemory, DMA)
        if not hasattr(prof, 'type') or getattr(prof, 'type') in (None, ''):
            setattr(prof, 'type', kind)

    def _merge_profile_defaults(self, dst, src):
        """Fill missing attributes on dst from src (template)."""
        for key, val in getattr(src, '__dict__', {}).items():
            if key.startswith('_') or key == 'parent':
                continue
            if not hasattr(dst, key) or getattr(dst, key) is None:
                setattr(dst, key, val)

    def compose_to_fs_ast(self, adl_model, idl_models, profile_models):
        """
        Compose the ADL, IDL, and Profile models into a unified AST representation.
        First stage: Initialize the basic structure.
        """
        halo_ast = {
            'components': {},
            'connections': []
        }

        # Iterate through ADL connections and enrich with IDL/HML data
        # Build IDL and HML lookup dictionaries
        idl_interfaces = self.get_idl_interfaces(idl_models)
        hml_profiles = self.get_hml_profiles(profile_models)

        if adl_model is None:
            self.logger.error("ADL model has no components defined.")
            raise ValueError("ADL model has no components defined.")

        # Initialize component entries
        for comp in adl_model.components:
            halo_ast['components'][comp.name] = {
                'component': comp,
                'connections': [],
                'profiles': {}
            }

        # Populate connections and link to components
        for conn in adl_model.connections:
            # Find matching IDL interface
            conn_idl_data = idl_interfaces.get(conn.interface)
            if not conn_idl_data:
                self.logger.warning(f"Interface '{conn.interface}' not found in IDL models")

            # Find matching HML profile
            conn_hml_data = hml_profiles.get(conn.profile)
            if not conn_hml_data:
                self.logger.warning(f"Profile '{conn.profile}' not found in HML models")

            # Create connection entry
            conn_entry = {
                'connection': conn,
                'idl_data': conn_idl_data,
                'hml_data': conn_hml_data
            }
            halo_ast['connections'].append(conn_entry)

            # Link to source and destination components
            for comp_name in [conn.src.name, conn.dst.name]:
                if comp_name in halo_ast['components']:
                    halo_ast['components'][comp_name]['connections'].append(conn_entry)
                    if conn.profile and conn_hml_data:
                        halo_ast['components'][comp_name]['profiles'][conn.profile] = conn_hml_data

        return halo_ast
    
    def compose_ast(self, halo_fs_ast):
        """
        Compose the ADL, IDL, and Profile models into a unified AST representation.
        Second stage: Flatten the structure for easier access.
        """
        # Implementation of flattening logic goes here
        # Create a Python AST module to represent the HALO model

        components = []
        connections = []

        # Add components
        for comp_name, comp_data in halo_fs_ast['components'].items():
            comp = comp_data['component']
            component = _ComponentData(
                name=comp_name,
                type=comp.type,
                platform=comp.platform,
                function=comp.function,
                profiles=comp_data['profiles']
            )
            components.append(component)

        # Add connections and link to components
        for conn_entry in halo_fs_ast['connections']:
            conn = conn_entry['connection']
            idl_data = conn_entry['idl_data']
            hml_data = conn_entry['hml_data']

            connection = _ConnectionData(
                name=conn.name,
                from_component=conn.src.name,
                to_component=conn.dst.name,
                interface=idl_data,
                profile=hml_data
            )
            connections.append(connection)
            
            # Link connections to components
            for component in components:
                if component.name == conn.src.name:
                    component.outgoing_connections.append(connection)
                    if conn.profile and hml_data and conn.profile not in component.profiles:
                        component.profiles[conn.profile] = hml_data
                if component.name == conn.dst.name:
                    component.incoming_connections.append(connection)
                    if conn.profile and hml_data and conn.profile not in component.profiles:
                        component.profiles[conn.profile] = hml_data

        return {'components': components, 'connections': connections}

    def generate_unified_model(self):
        """
        Generate a unified model that combines ADL, IDL, and Profile models.
        Also generates UML IR representation.
        """
        halo_fs_ast = self.compose_to_fs_ast(self.adl_descr, self.idl_descr, self.profile_descr)
        halo_ast = self.compose_ast(halo_fs_ast)
        
        # Generate UML IR from the unified model
        self.uml_ir = convert_halo_to_uml(
            halo_ast,
            self.idl_descr,
            self.profile_descr,
            user_types=self.user_types,
        )

        return halo_ast

    def validate_models(self):

        # Generate unified model with symbols table
        self.unified_model = self.generate_unified_model()

        # Auto-detect custom component domains from HADL before validation
        # This enables using custom platforms/types/functions without explicitly passing --user-types
        default_type = set(DEFAULT_HALO_ENUMS.get('componentType', []))
        default_platform = set(DEFAULT_HALO_ENUMS.get('componentPlatform', []))
        default_function = set(DEFAULT_HALO_ENUMS.get('componentFunction', []))
        
        extra_type: set[str] = set()
        extra_platform: set[str] = set()
        extra_function: set[str] = set()
        
        for comp in getattr(self.adl_descr, 'components', []) or []:
            ctype = getattr(comp, 'type', None)
            cplat = getattr(comp, 'platform', None)
            cfunc = getattr(comp, 'function', None)
            
            if isinstance(ctype, str) and ctype.strip() and ctype.strip() not in default_type:
                extra_type.add(ctype.strip())
            if isinstance(cplat, str) and cplat.strip() and cplat.strip() not in default_platform:
                extra_platform.add(cplat.strip())
            if isinstance(cfunc, str) and cfunc.strip() and cfunc.strip() not in default_function:
                extra_function.add(cfunc.strip())
        
        # Merge detected custom values with any existing user types
        if extra_type:
            existing = set(self.user_types.get('componentType', []))
            self.user_types['componentType'] = sorted(existing | extra_type)
        if extra_platform:
            existing = set(self.user_types.get('componentPlatform', []))
            self.user_types['componentPlatform'] = sorted(existing | extra_platform)
        if extra_function:
            existing = set(self.user_types.get('componentFunction', []))
            self.user_types['componentFunction'] = sorted(existing | extra_function)

        # Single source of truth: sw/composer/uml/halo_value_domains.py
        enums = merge_enums(DEFAULT_HALO_ENUMS, self.user_types)
        literals_by_name = enum_literals_by_name(enums)

        self.logger.info("\nSemantic Checks:")
        errors: list[str] = []

        # 1) Validate component metadata values (enums)
        # Platform is intentionally unconstrained by enum, but it must be non-empty.
        for comp in getattr(self.adl_descr, 'components', []) or []:
            cname = getattr(comp, 'name', '<component>')
            ctype = getattr(comp, 'type', None)
            cplat = getattr(comp, 'platform', None)
            cfunc = getattr(comp, 'function', None)

            if isinstance(ctype, str) and ctype.strip() and ctype.strip() not in literals_by_name.get('componentType', set()):
                errors.append(
                    f"Component '{cname}': invalid type '{ctype}'. Allowed: {sorted(literals_by_name.get('componentType', set()))}"
                )
            if not (isinstance(cplat, str) and cplat.strip()):
                errors.append(f"Component '{cname}': platform cannot be empty")
            if isinstance(cfunc, str) and cfunc.strip() and cfunc.strip() not in literals_by_name.get('componentFunction', set()):
                errors.append(
                    f"Component '{cname}': invalid function '{cfunc}'. Allowed: {sorted(literals_by_name.get('componentFunction', set()))}"
                )

        # 2) Validate profiles: enum-like fields and address-like fields
        profiles_by_name: Dict[str, Any] = {}
        profile_kind_by_name: Dict[str, str] = {}
        builtin_profile_types: set[str] = set(literals_by_name.get("profileType", set()))
        allowed_kinds: set[str] = set(builtin_profile_types)

        def _iter_kv(obj):
            for k, v in getattr(obj, '__dict__', {}).items():
                if k.startswith('_') or k == 'parent':
                    continue
                if k in ("name", "kind"):
                    continue
                yield k, v

        for root in (self.profile_descr or []):
            for prof in getattr(root, 'profiles', []) or []:
                pname = getattr(prof, 'name', None)
                kind = getattr(prof, 'kind', prof.__class__.__name__)
                if kind:
                    allowed_kinds.add(str(kind))
                if pname:
                    profiles_by_name[str(pname)] = prof
                    profile_kind_by_name[str(pname)] = str(kind) if kind else prof.__class__.__name__

                prof_label = str(pname) if pname else str(getattr(prof, '__class__', type(prof)).__name__)

                for key, value in _iter_kv(prof):
                    if hasattr(value, '__dict__'):
                        for sub_key, sub_value in _iter_kv(value):
                            domain = PROFILE_KEY_TO_ENUM.get(str(sub_key))
                            if sub_key == "type":
                                if isinstance(sub_value, str):
                                    v = sub_value.strip()
                                    # Inform when a built-in profile kind is used; custom kinds remain unconstrained.
                                    if v and v in builtin_profile_types:
                                        self.logger.info(
                                            f"Profile '{prof_label}': using built-in profile type '{v}'"
                                        )
                                # Skip further domain checks for type
                            elif domain and isinstance(sub_value, str) and sub_value.strip() and sub_value.strip() not in literals_by_name.get(domain, set()):
                                errors.append(
                                    f"Profile '{prof_label}': invalid {sub_key}='{sub_value}'. Allowed ({domain}): {sorted(literals_by_name.get(domain, set()))}"
                                )

                            parsed_addr = address_type_and_value(str(sub_key), sub_value)
                            if is_address_field(str(sub_key)) and parsed_addr is None and sub_value is not None:
                                errors.append(
                                    f"Profile '{prof_label}': invalid address value {sub_key}={sub_value!r} (expected 0x.. hex, digits, or int)"
                                )
                    else:
                        domain = PROFILE_KEY_TO_ENUM.get(str(key))
                        if key == "type":
                            if isinstance(value, str):
                                v = value.strip()
                                # Inform when a built-in profile kind is used; custom kinds remain unconstrained.
                                if v and v in builtin_profile_types:
                                    self.logger.info(
                                        f"Profile '{prof_label}': using built-in profile type '{v}'"
                                    )
                        elif domain and isinstance(value, str) and value.strip() and value.strip() not in literals_by_name.get(domain, set()):
                            errors.append(
                                f"Profile '{prof_label}': invalid {key}='{value}'. Allowed ({domain}): {sorted(literals_by_name.get(domain, set()))}"
                            )

                        parsed_addr = address_type_and_value(str(key), value)
                        if is_address_field(str(key)) and parsed_addr is None and value is not None:
                            errors.append(
                                f"Profile '{prof_label}': invalid address value {key}={value!r} (expected 0x.. hex, digits, or int)"
                            )

        # 3) Connection checks
        idl_interface_names: set[str] = set()
        for idl_model in (self.idl_descr or []):
            for iface in getattr(idl_model, 'interfaces', []) or []:
                iname = getattr(iface, 'name', None)
                if iname:
                    idl_interface_names.add(str(iname))

        if self.adl_descr and hasattr(self.adl_descr, 'connections'):
            for conn in getattr(self.adl_descr, 'connections', []) or []:
                conn_name = getattr(conn, 'name', '<connection>')
                comm = getattr(conn, 'communication', None)
                prof_name = getattr(conn, 'profile', None)
                iface_name = getattr(conn, 'interface', None)

                src_comp = getattr(getattr(conn, 'src', None), 'name', None)
                dst_comp = getattr(getattr(conn, 'dst', None), 'name', None)
                if not src_comp:
                    errors.append(f"Connection '{conn_name}': source component is undefined in ADL description")
                if not dst_comp:
                    errors.append(f"Connection '{conn_name}': destination component is undefined in ADL description")

                if src_comp and dst_comp and src_comp == dst_comp:
                    errors.append(
                        f"Connection '{conn_name}': source and destination are the same component '{src_comp}'"
                    )

                if iface_name and str(iface_name) not in idl_interface_names:
                    errors.append(
                        f"Connection '{conn_name}' references undefined interface '{iface_name}' in IDL"
                    )

                if prof_name and str(prof_name) not in profiles_by_name:
                    errors.append(
                        f"Connection '{conn_name}' references undefined profile '{prof_name}' in HML"
                    )

                # If profile exists, compare its kind to 'communication'
                if prof_name and str(prof_name) in profile_kind_by_name and comm:
                    expected_kind = profile_kind_by_name[str(prof_name)]
                    if str(comm) != expected_kind:
                        errors.append(
                            f"Connection '{conn_name}': communication '{comm}' doesn't match profile '{prof_name}' kind '{expected_kind}'"
                        )
                elif comm and allowed_kinds and str(comm) not in allowed_kinds:
                    self.logger.warning(
                        f"Connection '{conn_name}': communication '{comm}' not described in HML (available: {', '.join(sorted(allowed_kinds))})"
                    )

        if errors:
            for e in errors:
                self.logger.error(e)
            raise ValueError(f"Validation failed with {len(errors)} error(s):\n" + "\n".join(errors))

    def generate_output_files(self, output_dir):
        """
        Generate output files (e.g., JSON, Pickle) representing the unified model.
        """
        if not hasattr(self, 'unified_model'):
            self.logger.error("Unified model not generated. Please run `generate_unified_model()` first.")
            return

        def _serialize_value(val):
            """Serialize objects coming from textX / dataclasses into plain JSON types."""
            if hasattr(val, '__dict__'):
                out = {}
                for key, v in val.__dict__.items():
                    if key.startswith('_') or key == 'parent':
                        continue
                    # Always omit derived helper fields from JSON output.
                    if key in {"readStructs", "writeStructs", "byType", "byTypeRefs"}:
                        continue
                    # `kind` is an internal normalization hint used during composition/validation.
                    # It should not leak into the exported unified model JSON.
                    if key == "kind":
                        continue
                    # In the grammar, TypeRefs has `all='*' | '{' refs+=ID+ '}'`.
                    # When the refs-branch is used, TextX leaves `all` as an empty string.
                    # Omit empty `all` to avoid noise.
                    if key == "all" and (v is None or v == ""):
                        continue
                    out[key] = _serialize_value(v)
                return out
            if isinstance(val, list):
                return [_serialize_value(item) for item in val]
            if isinstance(val, dict):
                return {k: _serialize_value(v) for k, v in val.items()}
            return str(val) if not isinstance(val, (str, int, float, bool, type(None))) else val

        def _build_serializable_model() -> Dict[str, Any]:
            """Build the unified JSON model (pre-optimization)."""
            # Always omit component-local profiles from JSON output.
            include_component_profiles = False
            interfaces_by_name: Dict[str, Any] = {}
            for idl_model in (self.idl_descr or []):
                for iface in getattr(idl_model, 'interfaces', []) or []:
                    iname = getattr(iface, 'name', None)
                    if iname:
                        interfaces_by_name[iname] = _serialize_value(iface)

            profiles_by_name: Dict[str, Any] = {}
            for prof_model in (self.profile_descr or []):
                for prof in getattr(prof_model, 'profiles', []) or []:
                    pname = getattr(prof, 'name', None)
                    if pname:
                        profiles_by_name[pname] = _serialize_value(prof)

            return {
                'components': [comp.to_dict(include_profiles=include_component_profiles) for comp in self.unified_model['components']],
                'connections': [conn.to_dict() for conn in self.unified_model['connections']],
                'interfaces': interfaces_by_name,
                'profiles': profiles_by_name,
            }

        def _optimize_json_model(model: Dict[str, Any]) -> Dict[str, Any]:
            """Reduce redundancy for compact JSON by normalizing struct definitions.

            - Hoists interface-local `data.structs` definitions into `types.structs`.
            - Replaces per-interface struct bodies with `data.structRefs`.
            - Flattens access read/write permissions to `access.reads` / `access.writes`.
            """
            interfaces = model.get('interfaces') or {}
            global_structs: Dict[str, Any] = {}
            name_to_sig: Dict[str, str] = {}

            def _stable_sig(struct_obj: Any) -> str:
                try:
                    payload = json.dumps(struct_obj, sort_keys=True, separators=(',', ':'))
                except TypeError:
                    payload = json.dumps(_serialize_value(struct_obj), sort_keys=True, separators=(',', ':'))
                return hashlib.sha1(payload.encode('utf-8')).hexdigest()

            def _register_struct(struct_dict: Dict[str, Any]) -> str:
                base_name = str(struct_dict.get('name') or 'Struct')
                sig = _stable_sig(struct_dict)

                prev_sig = name_to_sig.get(base_name)
                if prev_sig is None:
                    name_to_sig[base_name] = sig
                    global_structs[base_name] = struct_dict
                    return base_name

                if prev_sig == sig:
                    return base_name

                suffix = sig[:8]
                key = f"{base_name}__{suffix}"
                if key not in global_structs:
                    global_structs[key] = struct_dict
                return key

            for _iname, iface in interfaces.items():
                if not isinstance(iface, dict):
                    continue

                # --- access: flatten readLines/writeLines -> reads[]/writes[]
                access = iface.get('access')
                if isinstance(access, dict):
                    def _collect_refs(lines_key: str, op_key: str) -> List[str]:
                        lines = access.get(lines_key)
                        if not isinstance(lines, list):
                            return []

                        out: List[str] = []
                        seen = set()

                        for line in lines:
                            if not isinstance(line, dict):
                                continue
                            op = line.get(op_key)
                            if not isinstance(op, dict):
                                continue

                            # Wildcard case: in compact serialization, `all` only exists if it is '*'
                            if op.get('all') == '*':
                                return ['*']

                            refs = op.get('refs')
                            if isinstance(refs, list):
                                for r in refs:
                                    rs = str(r)
                                    if rs not in seen:
                                        seen.add(rs)
                                        out.append(rs)
                        return out

                    reads = _collect_refs('readLines', 'reads')
                    writes = _collect_refs('writeLines', 'writes')

                    # Always emit the simplified shape in compact mode.
                    access_compact: Dict[str, Any] = {'reads': reads, 'writes': writes}
                    iface['access'] = access_compact

                data = iface.get('data')
                if not isinstance(data, dict):
                    continue
                structs = data.get('structs')
                if not isinstance(structs, list) or not structs:
                    continue

                refs: List[str] = []
                for s in structs:
                    if not isinstance(s, dict):
                        continue
                    refs.append(_register_struct(s))

                data.pop('structs', None)
                data['structRefs'] = refs
                iface['data'] = data

            if global_structs:
                model['dataTypes'] = {'structs': global_structs}

            return model

        serializable_model = _optimize_json_model(_build_serializable_model())

        # Include value domains (defaults + user types) so downstream codegen can
        # generate enum types and validate literals deterministically.
        if isinstance(serializable_model, dict):
            serializable_model["valueDomains"] = _build_value_domains(user_types=self.user_types)

        json_output_path = os.path.join(output_dir, "halo_unified_model.json")
        pickle_output_path = os.path.join(output_dir, "halo_unified_model.pkl")

        with open(json_output_path, 'w') as f:
            json.dump(serializable_model, f, indent=2)
        with open(pickle_output_path, 'wb') as f:
            pickle.dump(serializable_model, f)

        self.logger.info(f"Unified model JSON saved to {json_output_path}")
        self.logger.info(f"Unified model Pickle saved to {pickle_output_path}")

        # Also export Graphviz DOT and render a vertical (TB) SVG.
        try:
            try:
                from composer.tools.unified_json_to_dot import unified_model_to_dot
            except ImportError:
                from tools.unified_json_to_dot import unified_model_to_dot

            dot_output_path = os.path.join(output_dir, "halo_unified_model.dot")
            svg_output_path = os.path.join(output_dir, "halo_unified_model.svg")

            with open(dot_output_path, "w", encoding="utf-8") as f:
                f.write(unified_model_to_dot(serializable_model))
            self.logger.info(f"Unified model DOT saved to {dot_output_path}")

            _render_dot_tb(dot_output_path, svg_output_path, logger=self.logger)
        except Exception as e:
            self.logger.warning(f"Failed to generate DOT/SVG: {e}")

        # Additionally, generate PlantUML diagrams
        try:
            uml_out_dir = os.path.join(output_dir, "uml")
            arch_path = os.path.join(uml_out_dir, "architecture.puml")
            gen = HALOPlantUMLGenerator(self.unified_model, self.idl_descr, self.profile_descr)
            gen.write_architecture(arch_path)
            iface_dir = os.path.join(uml_out_dir, "interfaces")
            gen.write_interfaces(iface_dir)
            profile_dir = os.path.join(uml_out_dir, "profiles")
            gen.write_profiles(profile_dir)
            self.logger.info(f"UML (architecture) saved to {arch_path}")
            self.logger.info(f"UML (interfaces) saved to {iface_dir}")
            self.logger.info(f"UML (profiles) saved to {profile_dir}")
        except Exception as e:
            self.logger.warning(f"Failed to generate UML diagrams: {e}")
        
        # Generate standard UML (XMI) file from UML IR
        if self.uml_ir:
            try:
                xmi_out_dir = os.path.join(output_dir, "uml")
                xmi_path = os.path.join(xmi_out_dir, "halo_model.uml")
                xmi_exporter = UMLIRXMIExporter(self.uml_ir)
                xmi_exporter.export(xmi_path)
                self.logger.info(f"UML IR XMI saved to {xmi_path}")
            except Exception as e:
                self.logger.warning(f"Failed to generate UML IR XMI: {e}")
        else:
            # Fallback to old exporter if UML IR not available
            try:
                xmi_out_dir = os.path.join(output_dir, "uml")
                xmi_path = os.path.join(xmi_out_dir, "halo_model_legacy.uml")
                xmi = HALOUMLXMIExporter(serializable_model, self.idl_descr)
                xmi.export(xmi_path)
                self.logger.info(f"UML (XMI) saved to {xmi_path}")
            except Exception as e:
                self.logger.warning(f"Failed to generate UML XMI: {e}")
    
    def _print_uml_ir_summary(self):
        """Print a summary of the UML IR model"""
        if not self.uml_ir:
            return
        
        print("\n" + "="*80)
        print("UML IR Model Summary")
        print("="*80)
        
        print(f"\nModel: {self.uml_ir.name}")
        
        # Separate classes by stereotype
        components = [c for c in self.uml_ir.classes if "component" in c.stereotypes]
        interfaces = [c for c in self.uml_ir.classes if "interface" in c.stereotypes]
        profiles = [c for c in self.uml_ir.classes if "profile" in c.stereotypes]
        connections = [c for c in self.uml_ir.classes if "connection" in c.stereotypes]
        data_classes = [c for c in self.uml_ir.classes if "dataType" in c.stereotypes]
    
        print(f"\nComponents ({len(components)}):")
        for comp in components:
            other_stereo = [s for s in comp.stereotypes if s != "component"]
            stereotypes = f" <<{', '.join(other_stereo)}>>" if other_stereo else ""
            print(f"  - {comp.name}{stereotypes}")
            if comp.attributes:
                for attr in comp.attributes:
                    print(f"      {attr.name}: {attr.type}")
        
        print(f"\nInterfaces ({len(interfaces)}):")
        for iface in interfaces:
            print(f"  - {iface.name}")
            for op in iface.operations:
                params = ", ".join([f"{p.name}: {p.type}" for p in op.parameters])
                print(f"    + {op.name}({params})")
        
        print(f"\nProfiles ({len(profiles)}):")
        for prof in profiles:
            other_stereo = [s for s in prof.stereotypes if s != "profile"]
            stereotypes = f" <<{', '.join(other_stereo)}>>" if other_stereo else ""
            print(f"  - {prof.name}{stereotypes}")
        
        print(f"\nData Classes ({len(data_classes)}):")
        for cls in data_classes:
            stereotypes = f" <<{', '.join([s for s in cls.stereotypes if s != 'dataType'])}>>" if len(cls.stereotypes) > 1 else ""
            print(f"  - {cls.name}{stereotypes}")
            for attr in cls.attributes:
                mult = ""
                if attr.multiplicity_upper != 1:
                    mult = "[*]" if attr.multiplicity_upper is None else f"[{attr.multiplicity_upper}]"
                print(f"      {attr.name}: {attr.type}{mult}")
        
        print(f"\nConnections (Association Classes) ({len(connections)}):")
        for conn in connections:
            other_stereo = [s for s in conn.stereotypes if s != "connection"]
            stereotypes = f" <<{', '.join(other_stereo)}>>" if other_stereo else ""
            print(f"  - {conn.name}{stereotypes}")
            for attr in conn.attributes:
                print(f"      {attr.name}: {attr.type}")
        
        print(f"\nAssociations ({len(self.uml_ir.associations)}):")
        for assoc in self.uml_ir.associations:
            assoc_class_info = f" (association class: {assoc.association_class})" if assoc.association_class else ""
            print(f"  - {assoc.source} -> {assoc.target}{assoc_class_info}")
        
        print("="*80 + "\n")

    def print_components_and_connections(self):
        """
        This function prints out the parsed components and connections from the ADL model.
        """
        # Check if the model has been parsed
        if self.adl_descr is None:
            raise ValueError("Model has not been parsed. Please call `parse_adl_model()` first.")

        # Access parsed components
        print("Components:")
        for comp in self.adl_descr.components:
            print(f"Component {comp.name}, Platform: {comp.platform}, Function: {comp.function}")

        # Access parsed connections
        print("\nConnections:")
        for conn in self.adl_descr.connections:
            print(f"Connection {conn.name} from {conn.src.name} to {conn.dst.name}, "
                  f"Communication: {conn.communication}, Interface: {conn.interface}")

    def print_idl_data(self):
        """
        Print the data parsed from IDL files.
        """
        if not self.idl_descr:
            self.logger.info("No IDL models parsed.")
            return

        def print_idl_ifcs_data(idl_model):
            for interface in idl_model.interfaces:
                print(f"  Interface Name: {interface.name}")
                for struct in interface.data.structs:
                    if hasattr(struct, 'name'):
                        print(f"      Struct: {struct.name}")
                        for field in struct.fields:
                            size_info = f", Size: {field.array.size}" if field.array else ""
                            init_info = f", Init: {field.init.value}" if field.init else ""
                            print(f"          Field: {field.name}, Type: {field.type}{size_info}{init_info}")
                    else:
                        print(f"      Struct: {struct.reference}")

        
        def print_idl_ifcs_access(idl_model):
            for interface in idl_model.interfaces:
                print(f"  Interface Name: {interface.name}")
                for line in interface.access.readLines:
                    print(f"      ReadAccess: {line.reads.refs}")
                for line in interface.access.writeLines:
                    print(f"      WriteAccess: {line.writes.refs}")

        def print_idl_ifcs_integrity(idl_model):
            for interface in idl_model.interfaces:
                print(f"  Interface Name: {interface.name}")
                # for integrity in interface.integrity:
                for entry in interface.integrity.entries:
                    print(f"      Integrity: {entry.type}, Parameters: {entry.targets.refs}")

        for idl_model in self.idl_descr:
            print_idl_ifcs_data(idl_model)
            print_idl_ifcs_access(idl_model)
            print_idl_ifcs_integrity(idl_model)

    def print_profile_data(self):
        """Pretty-print parsed hardware mapping profiles with normalized sizes."""
        if not self.profile_descr:
            self.logger.info("No profile models parsed.")
            return

        print("\nHardware Mapping Profiles Summary:")
        for profile in self.profile_descr:  # Each root is a HardwareProfilesModel
            for prof in getattr(profile, 'profiles', []):
                print(f"\n  Profile Type: {prof.__class__.__name__}")
                for key, value in prof.__dict__.items():
                    if key.startswith('_') or key == 'parent':
                        continue
                    if hasattr(value, '__dict__'):
                        print(f"    {key}:")
                        for sub_key, sub_value in value.__dict__.items():
                            if not sub_key.startswith('_') and sub_key != 'parent':
                                print(f"      {sub_key}: {sub_value}")
                    else:
                        print(f"    {key}: {value}")
    def get_uml_ir(self):
        """
        Get the UML IR model. Must call generate_unified_model() first.
        
        Returns:
            UMLModel: The UML intermediate representation of the HALO system
        """
        if not self.uml_ir:
            raise ValueError("UML IR not generated. Please call `generate_unified_model()` first.")
        return self.uml_ir

def _compose_from_hadl(
    hadls_root: str,
    output_dir: str,
    log_level: int,
    *,
    include_stdlib_profiles: bool = False,
    user_types_path: str | None = None
    ) -> int:
    root_dir = os.path.dirname(os.path.abspath(__file__))

    adl_grammar = os.path.join(root_dir, "dsl", "grammars", "halo_adl_grammar.tx")
    idl_grammar = os.path.join(root_dir, "dsl", "grammars", "halo_idl_grammar.tx")
    hml_grammar = os.path.join(root_dir, "dsl", "grammars", "halo_hml_grammar.tx")

    adl_files = glob.glob(os.path.join(hadls_root, '*.adl'))
    idl_files = glob.glob(os.path.join(hadls_root, '*.idl'))
    hml_files = glob.glob(os.path.join(hadls_root, '*.hml'))

    # .hmml files are template profiles and should be parsed with the same grammar.
    hmml_files = glob.glob(os.path.join(hadls_root, '*.hmml'))
    hml_files = hml_files + hmml_files

    # Optionally inject packaged stdlib profile templates so projects can
    # reference profile kinds without copying halo_hml_profiles.hmml.
    if include_stdlib_profiles:
        stdlib_hmml = Path(root_dir) / "dsl" / "hadls" / "halo_hml_profiles.hmml"
        if stdlib_hmml.exists():
            # Parse stdlib templates first so project-local templates can override.
            hml_files = [str(stdlib_hmml)] + hml_files
        else:
            logging.getLogger(__name__).warning(
                "--include-stdlib-profiles was set, but stdlib file not found at %s",
                stdlib_hmml,
            )

    if not adl_files:
        raise ValueError(f"No .adl files found in {hadls_root}")

    user_types: Dict[str, List[str]] = {}
    selected_path = user_types_path
    if not selected_path:
        # Auto-discover a user-types file colocated with HADL sources.
        # This enables reproducible round-trips: XMI -> HADL exports can carry
        # custom value domains without requiring users to pass --user-types.
        for candidate_name in ("user_types.json", "halo_user_types.json"):
            candidate = os.path.join(hadls_root, candidate_name)
            if os.path.exists(candidate):
                selected_path = candidate
                break
    if selected_path:
        user_types = load_user_types_from_json(selected_path)

    halo_composer = HALOComposer(
        adl_grammar_file=adl_grammar,
        idl_grammar_file=idl_grammar,
        profile_grammar_file=hml_grammar,
        adl_file=adl_files[0],
        idl_files=idl_files,
        profile_files=hml_files,
        log_level=log_level,
        user_types=user_types,
    )

    try:
        halo_composer.parse_adl_model()
        halo_composer.parse_idl_files()
        halo_composer.parse_hml_profile_files()
        halo_composer.validate_models()
        os.makedirs(output_dir, exist_ok=True)
        halo_composer.generate_output_files(output_dir)
    except Exception as e:
        halo_composer.logger.error(f"An error occurred: {e}")
        return 1
    return 0


def _compose_from_xmi(xmi_path: str, output_dir: str, *, user_types_path: str | None = None) -> int:
    model = load_xmi_to_halo_unified_model(xmi_path)
    os.makedirs(output_dir, exist_ok=True)

    user_types: Dict[str, List[str]] = {}
    if user_types_path:
        user_types = load_user_types_from_json(user_types_path)
    else:
        # Auto-detect custom component domains (type/platform/function) that are not
        # covered by built-in HALO enumerations. This enables reproducible XMI -> HADL
        # round-trips even when the user didn't pass --user-types.
        default_type = set(DEFAULT_HALO_ENUMS.get('componentType', []))
        default_platform = set(DEFAULT_HALO_ENUMS.get('componentPlatform', []))
        default_function = set(DEFAULT_HALO_ENUMS.get('componentFunction', []))

        extra_type: set[str] = set()
        extra_platform: set[str] = set()
        extra_function: set[str] = set()

        for comp in (model.get('components', []) if isinstance(model, dict) else []) or []:
            if not isinstance(comp, dict):
                continue
            ctype = comp.get('type')
            cplat = comp.get('platform')
            cfunc = comp.get('function')

            if isinstance(ctype, str) and ctype.strip() and ctype.strip() not in default_type:
                extra_type.add(ctype.strip())
            if isinstance(cplat, str) and cplat.strip() and cplat.strip() not in default_platform:
                extra_platform.add(cplat.strip())
            if isinstance(cfunc, str) and cfunc.strip() and cfunc.strip() not in default_function:
                extra_function.add(cfunc.strip())

        if extra_type:
            user_types['componentType'] = sorted(extra_type)
        if extra_platform:
            user_types['componentPlatform'] = sorted(extra_platform)
        if extra_function:
            user_types['componentFunction'] = sorted(extra_function)

    if user_types:
        # Validate imported model component domains with defaults+custom.
        # Platform is intentionally unconstrained: any non-empty platform value is accepted.
        enums = merge_enums(DEFAULT_HALO_ENUMS, user_types)
        literals_by_name = enum_literals_by_name(enums)
        errors: list[str] = []

        for comp in (model.get('components', []) if isinstance(model, dict) else []) or []:
            if not isinstance(comp, dict):
                continue
            cname = str(comp.get('name') or '<component>')
            ctype = comp.get('type')
            cplat = comp.get('platform')
            cfunc = comp.get('function')

            if isinstance(ctype, str) and ctype.strip() and ctype.strip() not in literals_by_name.get('componentType', set()):
                errors.append(
                    f"Component '{cname}': invalid type '{ctype}'. Allowed: {sorted(literals_by_name.get('componentType', set()))}"
                )
            if not (isinstance(cplat, str) and cplat.strip()):
                errors.append(f"Component '{cname}': platform cannot be empty")
            if isinstance(cfunc, str) and cfunc.strip() and cfunc.strip() not in literals_by_name.get('componentFunction', set()):
                errors.append(
                    f"Component '{cname}': invalid function '{cfunc}'. Allowed: {sorted(literals_by_name.get('componentFunction', set()))}"
                )

        if errors:
            for msg in errors:
                logging.getLogger(__name__).error(msg)
            return 1

        # Keep a reference copy next to the outputs for reproducibility.
        with open(os.path.join(output_dir, 'halo_user_types.json'), 'w', encoding='utf-8') as f:
            json.dump(user_types, f, indent=2, sort_keys=True)

    # Always include value domains in the unified model (defaults + any detected/provided user types).
    if isinstance(model, dict):
        model["valueDomains"] = _build_value_domains(user_types=user_types)

    json_output_path = os.path.join(output_dir, "halo_unified_model.json")
    pickle_output_path = os.path.join(output_dir, "halo_unified_model.pkl")

    with open(json_output_path, 'w', encoding='utf-8') as f:
        json.dump(model, f, indent=2)
    with open(pickle_output_path, 'wb') as f:
        pickle.dump(model, f)

    # Also export HADL (ADL/IDL/IDDL/HML) from the imported unified model.
    hadl_out_dir = os.path.join(output_dir, "hadl")
    system_name = os.path.splitext(os.path.basename(xmi_path))[0]
    hadl_paths = HADLExporter().export(
        model,
        hadl_out_dir,
        system_name=system_name,
        user_types=user_types if user_types else None,
    )

    logging.getLogger(__name__).info("Unified model JSON saved to %s", json_output_path)
    logging.getLogger(__name__).info("Unified model Pickle saved to %s", pickle_output_path)
    logging.getLogger(__name__).info("HADL files saved to %s", os.path.abspath(hadl_out_dir))

    # Also export Graphviz DOT and render a vertical (TB) SVG.
    try:
        try:
            from composer.tools.unified_json_to_dot import unified_model_to_dot
        except ImportError:
            from tools.unified_json_to_dot import unified_model_to_dot

        dot_output_path = os.path.join(output_dir, "halo_unified_model.dot")
        svg_output_path = os.path.join(output_dir, "halo_unified_model.svg")

        with open(dot_output_path, "w", encoding="utf-8") as f:
            f.write(unified_model_to_dot(model))
        logging.getLogger(__name__).info("Unified model DOT saved to %s", dot_output_path)

        _render_dot_tb(dot_output_path, svg_output_path, logger=logging.getLogger(__name__))
    except Exception as e:
        logging.getLogger(__name__).warning("Failed to generate DOT/SVG: %s", e)
    return 0


def compose_from_hadl(
    hadls_root: str,
    output_dir: str,
    *,
    log_level: str | int = "INFO",
    include_stdlib_profiles: bool = False,
    user_types_path: str | None = None,
) -> int:
    """Public Python API for composing a unified model from HADL files."""
    resolved_level = (
        getattr(logging, str(log_level).upper(), logging.INFO)
        if not isinstance(log_level, int)
        else log_level
    )
    return _compose_from_hadl(
        hadls_root,
        output_dir,
        resolved_level,
        include_stdlib_profiles=include_stdlib_profiles,
        user_types_path=user_types_path,
    )


def compose_from_xmi(
    xmi_path: str,
    output_dir: str,
    *,
    user_types_path: str | None = None,
) -> int:
    """Public Python API for composing a unified model from UML XMI."""
    return _compose_from_xmi(
        xmi_path,
        output_dir,
        user_types_path=user_types_path,
    )


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for HALO Composer."""
    root_dir = os.path.dirname(os.path.abspath(__file__))

    default_hadls_root = os.path.join(root_dir, "dsl", "hadls")
    default_output_dir = os.path.normpath(os.path.join(root_dir, "../../", "output"))

    p = argparse.ArgumentParser(
        prog='halo_composer',
        description=(
            'HALO Composer (HADL/IDL/HML -> unified model, or XMI -> unified model). '
            'Built-in profile kinds available out of the box: SharedMemory, MemoryMappedIO, DMA, EventChannel, BlackBoard.'
        ),
    )
    sub = p.add_subparsers(dest='command')

    p_hadl = sub.add_parser(
        'from-hadl',
        help='Compose from HADL/IDL/HML (default behavior).',
        description=(
            'Compose from HADL/IDL/HML. Built-in profile kinds: SharedMemory, MemoryMappedIO, DMA, EventChannel, BlackBoard. '
            'In ADL, connections reference named profile instances defined in HML.'
        ),
    )
    p_hadl.add_argument('--hadls-root', default=default_hadls_root, help='Folder containing .adl/.idl/.hml files')
    p_hadl.add_argument('--output-dir', default=default_output_dir, help='Output folder')
    p_hadl.add_argument('--log-level', default='INFO', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'], help='Log level')
    p_hadl.add_argument(
        '--include-stdlib-profiles',
        action='store_true',
        help=(
            'Include built-in template profiles (halo_hml_profiles.hmml) shipped with the package. '
            'This lets HML profile instances inherit defaults without copying templates into the project.'
        ),
    )
    p_hadl.add_argument(
        '--user-types',
        dest='user_types',
        default=None,
        help=(
            'Optional path to a JSON file defining user types to extend HALO built-in types.'
        ),
    )

    p_xmi = sub.add_parser('from-xmi', help='Compose from UML XMI (.uml/.xmi) into HALO unified model JSON/Pickle.')
    p_xmi.add_argument('--input', '-i', required=True, help='Path to UML XMI model (.uml/.xmi)')
    p_xmi.add_argument('--output-dir', '-o', default=default_output_dir, help='Output folder')
    p_xmi.add_argument(
        '--user-types',
        dest='user_types',
        default=None,
        help=(
            'Optional path to a JSON file defining user types to validate/record during XMI import.'
        ),
    )

    args = p.parse_args(argv)

    # Backwards compatible default if no subcommand was provided.
    if args.command is None:
        return _compose_from_hadl(default_hadls_root, default_output_dir, logging.INFO)

    if args.command == 'from-xmi':
        return _compose_from_xmi(
            args.input,
            args.output_dir,
            user_types_path=getattr(args, 'user_types', None),
        )

    if args.command == 'from-hadl':
        level = getattr(logging, str(args.log_level).upper(), logging.INFO)
        return _compose_from_hadl(
            args.hadls_root,
            args.output_dir,
            level,
            include_stdlib_profiles=bool(getattr(args, 'include_stdlib_profiles', False)),
            user_types_path=getattr(args, 'user_types', None),
        )

    p.error(f"Unknown command: {args.command}")
    return 2


if __name__ == "__main__":
    exit(main())
