"""
UML IR to XMI Exporter
Exports UML IR (from ir.py) to standard UML 2.x XMI format using Jinja2 templates.
"""

import os
import re
from typing import Set, Dict
from jinja2 import Environment, FileSystemLoader, select_autoescape
from .ir import UMLModel


def _sanitize_id(name: str) -> str:
    """Sanitize a name to be used as an XMI ID."""
    return re.sub(r"[^0-9A-Za-z_]+", "_", str(name))


def _escape_xml_attr(value: str) -> str:
    """Escape XML special characters in attribute values."""
    if not isinstance(value, str):
        value = str(value)
    value = value.replace("&", "&amp;")  # Must be first!
    value = value.replace("<", "&lt;")
    value = value.replace(">", "&gt;")
    value = value.replace('"', "&quot;")
    value = value.replace("'", "&apos;")
    return value


def _get_type_ref(name: str, class_names: Set[str]) -> str:
    """Get the proper type reference (class_ or prim_) for a type name."""
    if name in class_names:
        return f"class_{_sanitize_id(name)}"
    else:
        return f"prim_{_sanitize_id(name)}"


class UMLIRXMIExporter:
    """Export UML IR model to standard UML 2.x XMI format using Jinja2 templates."""
    
    def __init__(self, uml_model: UMLModel):
        self.uml_model = uml_model
        
        # Setup Jinja2 environment
        template_dir = os.path.join(os.path.dirname(__file__), 'templates')
        self.jinja_env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=select_autoescape(['xml']),
            trim_blocks=False,
            lstrip_blocks=False
        )
        
        # Add custom filters
        self.jinja_env.filters['sanitize'] = _sanitize_id
        self.jinja_env.filters['xml_escape'] = _escape_xml_attr
    
    def _collect_class_names(self) -> Set[str]:
        """Collect all class names in the model."""
        return {cls.name for cls in self.uml_model.classes}

    def _collect_enumeration_names(self) -> Set[str]:
        """Collect all enumeration names in the model."""
        return {e.name for e in getattr(self.uml_model, 'enumerations', [])}
    
    def _collect_primitive_types(self, type_names: Set[str]) -> Set[str]:
        """Collect all primitive types used in the model (excluding class/enum types)."""
        types = set()
        
        # Collect from class attributes
        for cls in self.uml_model.classes:
            for attr in cls.attributes:
                if attr.type and attr.type not in type_names:
                    types.add(attr.type)
            for op in cls.operations:
                if op.return_type and op.return_type not in type_names:
                    types.add(op.return_type)
                for param in op.parameters:
                    if param.type and param.type not in type_names:
                        types.add(param.type)
        
        # Collect from interfaces
        for iface in self.uml_model.interfaces:
            for op in iface.operations:
                if op.return_type and op.return_type not in type_names:
                    types.add(op.return_type)
                for param in op.parameters:
                    if param.type and param.type not in type_names:
                        types.add(param.type)
        
        # Collect from components
        for comp in self.uml_model.components:
            for attr in comp.attributes:
                if attr.type and attr.type not in type_names:
                    types.add(attr.type)
        
        return types
    
    def export(self, output_path: str, profile_path: str | None = None):
        """Export the UML IR model to XMI file using Jinja2 templates.

        Also emits an external UML Profile (Objing/Eclipse UML2 style) so stereotype
        applications (<<HALO_COMPONENT>> etc.) are visible when importing the model
        into UML tools.
        """
        # Collect all class names first
        class_names = self._collect_class_names()
        enumeration_names = self._collect_enumeration_names()
        type_names = set(class_names) | set(enumeration_names)
        
        # Collect interface names (both actual interfaces and classes with "interface" stereotype)
        interface_names = {iface.name for iface in self.uml_model.interfaces}
        interface_names.update({c.name for c in self.uml_model.classes if "interface" in c.stereotypes})
        
        # Collect only true primitive types (excluding classes)
        primitive_types = sorted(self._collect_primitive_types(type_names))
        
        # Organize classes into categories
        components = [c for c in self.uml_model.classes if "component" in c.stereotypes]
        interfaces = [c for c in self.uml_model.classes if "interface" in c.stereotypes]
        profiles = [c for c in self.uml_model.classes if "profile" in c.stereotypes]
        connections = [c for c in self.uml_model.classes if "connection" in c.stereotypes]
        data_types = [c for c in self.uml_model.classes if "dataType" in c.stereotypes]
        other_classes = [c for c in self.uml_model.classes 
                        if not any(s in c.stereotypes for s in ["component", "interface", "profile", "connection", "dataType"])]

        # Used to render connection classes as UML AssociationClasses.
        connection_classes_by_name = {c.name: c for c in connections if getattr(c, 'name', None)}
        
        # External profile defaults (written next to the model unless overridden)
        out_dir = os.path.dirname(output_path) if os.path.dirname(output_path) else "."
        profile_file_name = "halo_profile.xmi"
        if profile_path is None:
            profile_path = os.path.join(out_dir, profile_file_name)
        else:
            profile_file_name = os.path.basename(profile_path)

        profile_name = "HALOProfile"
        profile_ns_prefix = "HALOProfile"
        profile_ns_uri = "http:///schemas/HALOProfile/0"

        # Deterministic IDs used across profile + model references
        profile_id = "_HALOProfile"
        profile_epackage_id = "_HALOProfile_EPackage"
        profile_eanno_id = "_HALOProfile_eAnnotations"
        profile_metaclass_import_id = "_HALOProfile_metaclass_Class"
        profile_metaclass_import_interface_id = "_HALOProfile_metaclass_Interface"

        st_halo_component_id = "_HALOProfile_ST_HALO_COMPONENT"
        st_halo_component_base_id = "_HALOProfile_ST_HALO_COMPONENT_base_Class"
        ext_halo_component_id = "_HALOProfile_EXT_Class_HALO_COMPONENT"
        extend_halo_component_end_id = "_HALOProfile_EXTENDEND_HALO_COMPONENT"
        profile_ec_halo_component_id = "_HALOProfile_EC_HALO_COMPONENT"
        profile_ec_halo_component_anno_id = "_HALOProfile_EC_HALO_COMPONENT_anno"
        profile_ec_halo_component_base_id = "_HALOProfile_EC_HALO_COMPONENT_base_Class"

        st_halo_profile_id = "_HALOProfile_ST_HALO_PROFILE"
        st_halo_profile_base_id = "_HALOProfile_ST_HALO_PROFILE_base_Class"
        ext_halo_profile_id = "_HALOProfile_EXT_Class_HALO_PROFILE"
        extend_halo_profile_end_id = "_HALOProfile_EXTENDEND_HALO_PROFILE"
        profile_ec_halo_profile_id = "_HALOProfile_EC_HALO_PROFILE"
        profile_ec_halo_profile_anno_id = "_HALOProfile_EC_HALO_PROFILE_anno"
        profile_ec_halo_profile_base_id = "_HALOProfile_EC_HALO_PROFILE_base_Class"

        st_halo_connection_id = "_HALOProfile_ST_HALO_CONNECTION"
        st_halo_connection_base_id = "_HALOProfile_ST_HALO_CONNECTION_base_Class"
        ext_halo_connection_id = "_HALOProfile_EXT_Class_HALO_CONNECTION"
        extend_halo_connection_end_id = "_HALOProfile_EXTENDEND_HALO_CONNECTION"
        profile_ec_halo_connection_id = "_HALOProfile_EC_HALO_CONNECTION"
        profile_ec_halo_connection_anno_id = "_HALOProfile_EC_HALO_CONNECTION_anno"
        profile_ec_halo_connection_base_id = "_HALOProfile_EC_HALO_CONNECTION_base_Class"

        st_halo_interface_id = "_HALOProfile_ST_HALO_INTERFACE"
        st_halo_interface_base_id = "_HALOProfile_ST_HALO_INTERFACE_base_Interface"
        ext_halo_interface_id = "_HALOProfile_EXT_Interface_HALO_INTERFACE"
        extend_halo_interface_end_id = "_HALOProfile_EXTENDEND_HALO_INTERFACE"
        profile_ec_halo_interface_id = "_HALOProfile_EC_HALO_INTERFACE"
        profile_ec_halo_interface_anno_id = "_HALOProfile_EC_HALO_INTERFACE_anno"
        profile_ec_halo_interface_base_id = "_HALOProfile_EC_HALO_INTERFACE_base_Interface"

        st_halo_datatype_id = "_HALOProfile_ST_HALO_DATATYPE"
        st_halo_datatype_base_id = "_HALOProfile_ST_HALO_DATATYPE_base_Class"
        ext_halo_datatype_id = "_HALOProfile_EXT_Class_HALO_DATATYPE"
        extend_halo_datatype_end_id = "_HALOProfile_EXTENDEND_HALO_DATATYPE"
        profile_ec_halo_datatype_id = "_HALOProfile_EC_HALO_DATATYPE"
        profile_ec_halo_datatype_anno_id = "_HALOProfile_EC_HALO_DATATYPE_anno"
        profile_ec_halo_datatype_base_id = "_HALOProfile_EC_HALO_DATATYPE_base_Class"

        # Render the external profile file
        profile_template = self.jinja_env.get_template('profile.xmi.j2')
        profile_content = profile_template.render(
            profile_id=profile_id,
            profile_name=profile_name,
            profile_ns_uri=profile_ns_uri,
            profile_ns_prefix=profile_ns_prefix,
            profile_epackage_id=profile_epackage_id,
            profile_eanno_id=profile_eanno_id,
            profile_metaclass_import_id=profile_metaclass_import_id,
            profile_metaclass_import_interface_id=profile_metaclass_import_interface_id,

            st_halo_component_id=st_halo_component_id,
            st_halo_component_base_id=st_halo_component_base_id,
            ext_halo_component_id=ext_halo_component_id,
            extend_halo_component_end_id=extend_halo_component_end_id,
            profile_ec_halo_component_id=profile_ec_halo_component_id,
            profile_ec_halo_component_anno_id=profile_ec_halo_component_anno_id,
            profile_ec_halo_component_base_id=profile_ec_halo_component_base_id,

            st_halo_profile_id=st_halo_profile_id,
            st_halo_profile_base_id=st_halo_profile_base_id,
            ext_halo_profile_id=ext_halo_profile_id,
            extend_halo_profile_end_id=extend_halo_profile_end_id,
            profile_ec_halo_profile_id=profile_ec_halo_profile_id,
            profile_ec_halo_profile_anno_id=profile_ec_halo_profile_anno_id,
            profile_ec_halo_profile_base_id=profile_ec_halo_profile_base_id,

            st_halo_connection_id=st_halo_connection_id,
            st_halo_connection_base_id=st_halo_connection_base_id,
            ext_halo_connection_id=ext_halo_connection_id,
            extend_halo_connection_end_id=extend_halo_connection_end_id,
            profile_ec_halo_connection_id=profile_ec_halo_connection_id,
            profile_ec_halo_connection_anno_id=profile_ec_halo_connection_anno_id,
            profile_ec_halo_connection_base_id=profile_ec_halo_connection_base_id,

            st_halo_interface_id=st_halo_interface_id,
            st_halo_interface_base_id=st_halo_interface_base_id,
            ext_halo_interface_id=ext_halo_interface_id,
            extend_halo_interface_end_id=extend_halo_interface_end_id,
            profile_ec_halo_interface_id=profile_ec_halo_interface_id,
            profile_ec_halo_interface_anno_id=profile_ec_halo_interface_anno_id,
            profile_ec_halo_interface_base_id=profile_ec_halo_interface_base_id,

            st_halo_datatype_id=st_halo_datatype_id,
            st_halo_datatype_base_id=st_halo_datatype_base_id,
            ext_halo_datatype_id=ext_halo_datatype_id,
            extend_halo_datatype_end_id=extend_halo_datatype_end_id,
            profile_ec_halo_datatype_id=profile_ec_halo_datatype_id,
            profile_ec_halo_datatype_anno_id=profile_ec_halo_datatype_anno_id,
            profile_ec_halo_datatype_base_id=profile_ec_halo_datatype_base_id,
        )

        # Ensure output directory exists
        os.makedirs(out_dir, exist_ok=True)
        with open(profile_path, 'w', encoding='utf-8') as f:
            f.write(profile_content)

        # Load the main model template
        template = self.jinja_env.get_template('model.xmi.j2')
        
        # Create a filter for getting type references (check interfaces first, then classes)
        def get_type_ref(name: str) -> str:
            if name in interface_names:
                return f"iface_{_sanitize_id(name)}"
            elif name in enumeration_names:
                return f"enum_{_sanitize_id(name)}"
            elif name in class_names:
                return f"class_{_sanitize_id(name)}"
            else:
                return f"prim_{_sanitize_id(name)}"
        
        self.jinja_env.filters['type_ref'] = get_type_ref
        
        enumerations = list(getattr(self.uml_model, 'enumerations', []) or [])
        enumerations_by_name = {e.name: e for e in enumerations if getattr(e, 'name', None)}

        # Render the template
        xmi_content = template.render(
            model=self.uml_model,
            primitive_types=primitive_types,
            class_names=class_names,
            components=components,
            interfaces=interfaces,
            profiles=profiles,
            connections=connections,
            data_types=data_types,
            other_classes=other_classes,
            connection_classes_by_name=connection_classes_by_name,
            enumerations=enumerations,
            enumerations_by_name=enumerations_by_name,

            # External profile wiring
            profile_file_name=profile_file_name,
            profile_name=profile_name,
            profile_ns_uri=profile_ns_uri,
            profile_ns_prefix=profile_ns_prefix,
            profile_id=profile_id,
            profile_epackage_id=profile_epackage_id,
        )
        
        # Write to model file with proper formatting
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(xmi_content)
