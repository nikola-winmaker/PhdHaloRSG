# HALO semantics → UML IR
"""
HALO to UML IR Converter
This module transforms HALO unified model (ADL/IDL/HML) into tool-neutral UML IR.
"""

from typing import Dict, List, Any, Optional
import re
from .ir import (
    UMLModel, UMLClass, UMLAssociation,
    UMLOperation, UMLParameter, UMLProperty,
    DirectionKind, VisibilityKind, UMLEnumeration
)

from .halo_value_domains import (
    DEFAULT_HALO_ENUMS,
    merge_enums,
    enum_literals_by_name,
    enum_names_by_literal,
    map_scalar_type,
    enum_type_for_field,
    enum_type_for_value,
    address_type_and_value,
)


class HALOToUMLConverter:
    """Converts HALO unified model to UML IR using class-based approach"""
    
    def __init__(
        self,
        unified_model: Dict[str, Any],
        idl_models: List[Any],
        profile_models: List[Any],
        user_types: Optional[Dict[str, List[str]]] = None
    ):
        self.unified_model = unified_model
        self.idl_models = idl_models
        self.profile_models = profile_models
        self.user_types = user_types if user_types is not None else {}
        self.uml_model = UMLModel(name="HALO_System")
        
        # Track created elements to avoid duplicates
        self._component_map: Dict[str, UMLClass] = {}
        self._interface_map: Dict[str, UMLClass] = {}
        self._profile_map: Dict[str, UMLClass] = {}
        self._class_map: Dict[str, UMLClass] = {}

        # enum_name -> set(literals)
        self._enum_literals_by_name: Dict[str, set] = {}
        # literal -> set(enum_names)
        self._enum_names_by_literal: Dict[str, set] = {}
    
    def convert(self) -> UMLModel:
        """Main conversion method"""
        self._ensure_halo_enumerations(self.user_types)

        # Convert profiles to classes
        self._convert_profiles()
        
        # Convert interfaces to classes
        self._convert_interfaces()
        
        # Convert components to classes
        self._convert_components()
        
        # Convert connections to association classes
        self._convert_connections()
        
        return self.uml_model

    def _ensure_halo_enumerations(self, user_types: Optional[Dict[str, List[str]]] = None) -> None:
        """Ensure common HALO value domains exist as UML Enumerations.
        
        Args:
            user_types: Optional dictionary of user value domains to add/extend
        """

        existing = {e.name for e in getattr(self.uml_model, 'enumerations', [])}

        enums: Dict[str, List[str]] = merge_enums(DEFAULT_HALO_ENUMS, user_types)

        for enum_name, literals in enums.items():
            if enum_name in existing:
                continue
            self.uml_model.enumerations.append(
                UMLEnumeration(name=enum_name, id=f"enum_{enum_name}", literals=list(literals))
            )

        current = {e.name: list(e.literals) for e in self.uml_model.enumerations}
        self._enum_literals_by_name = enum_literals_by_name(current)
        self._enum_names_by_literal = enum_names_by_literal(current)

    def _map_scalar_type(self, value: Any) -> str:
        return map_scalar_type(value)

    def _enum_type_for_field(self, field_name: str, value: Any) -> Optional[str]:
        return enum_type_for_field(field_name, value, self._enum_literals_by_name)

    def _enum_type_for_value(self, value: Any) -> Optional[str]:
        return enum_type_for_value(value, self._enum_names_by_literal)
    
    def _convert_profiles(self):
        """Convert HML profiles to UML classes with stereotype 'profile'"""

        size_re = re.compile(r"^\s*(?P<num>\d+(?:\.\d+)?)\s*(?P<unit>B|kB|MB)\s*$")

        def _size_type_and_value(val: Any):
            """Return (unit, numeric_value) if val is like '1MB'/'256B', else None."""
            if not isinstance(val, str):
                return None
            m = size_re.match(val)
            if not m:
                return None
            unit = m.group('unit')
            num_s = m.group('num')
            # Keep decimal value (no unit conversion).
            num = float(num_s) if '.' in num_s else int(num_s)
            return unit, num

        for profile_model in self.profile_models:
            for prof in getattr(profile_model, 'profiles', []):
                profile_name = getattr(prof, 'name', prof.__class__.__name__)
                if not profile_name:
                    continue
                
                uml_profile = UMLClass(
                    name=profile_name,
                    id=f"profile_{profile_name}",
                    stereotypes=["profile", prof.__class__.__name__]
                )
                
                # Add profile attributes
                for key, value in prof.__dict__.items():
                    if key.startswith('_') or key == 'parent':
                        continue
                    # Avoid redundancy: instance identifier is already the UML class name.
                    # Also avoid repeating kind (already represented as a stereotype).
                    if key in ("name", "kind"):
                        continue
                    if hasattr(value, '__dict__'):
                        # Nested block - flatten attributes
                        for sub_key, sub_value in value.__dict__.items():
                            if not sub_key.startswith('_') and sub_key != 'parent':
                                parsed = _size_type_and_value(sub_value)
                                if parsed:
                                    unit, num = parsed
                                    uml_profile.attributes.append(UMLProperty(
                                        name=f"{key}_{sub_key}",
                                        type=unit,
                                        default_value=num
                                    ))
                                    continue

                                parsed_addr = address_type_and_value(sub_key, sub_value)
                                if parsed_addr:
                                    addr_type, addr_val = parsed_addr
                                    uml_profile.attributes.append(UMLProperty(
                                        name=f"{key}_{sub_key}",
                                        type=addr_type,
                                        default_value=addr_val,
                                    ))
                                    continue

                                enum_type = self._enum_type_for_field(sub_key, sub_value)
                                if not enum_type:
                                    enum_type = self._enum_type_for_value(sub_value)
                                if enum_type:
                                    uml_profile.attributes.append(UMLProperty(
                                        name=f"{key}_{sub_key}",
                                        type=enum_type,
                                        default_value=str(sub_value).strip(),
                                    ))
                                    continue
                                uml_profile.attributes.append(UMLProperty(
                                    name=f"{key}_{sub_key}",
                                    type=self._map_scalar_type(sub_value),
                                    default_value=sub_value
                                ))
                    else:
                        parsed = _size_type_and_value(value)
                        if parsed:
                            unit, num = parsed
                            uml_profile.attributes.append(UMLProperty(
                                name=key,
                                type=unit,
                                default_value=num
                            ))
                            continue

                        parsed_addr = address_type_and_value(key, value)
                        if parsed_addr:
                            addr_type, addr_val = parsed_addr
                            uml_profile.attributes.append(UMLProperty(
                                name=key,
                                type=addr_type,
                                default_value=addr_val,
                            ))
                            continue

                        enum_type = self._enum_type_for_field(key, value)
                        if not enum_type:
                            enum_type = self._enum_type_for_value(value)
                        if enum_type:
                            uml_profile.attributes.append(UMLProperty(
                                name=key,
                                type=enum_type,
                                default_value=str(value).strip(),
                            ))
                            continue
                        uml_profile.attributes.append(UMLProperty(
                            name=key,
                            type=self._map_scalar_type(value),
                            default_value=value
                        ))
                
                self.uml_model.classes.append(uml_profile)
                self._profile_map[profile_name] = uml_profile
    
    def _convert_interfaces(self):
        """Convert IDL interfaces to UML classes with stereotype 'interface'"""
        for idl_model in self.idl_models:
            for interface in getattr(idl_model, "interfaces", []):
                name = getattr(interface, "name", None)
                if not name:
                    continue

                def _ref_tail(ref: Any) -> str:
                    s = str(ref)
                    return s.split(".")[-1] if "." in s else s

                def _resolve_param_type(ref: Any) -> str:
                    """Resolve a ref name to a known struct/data type name.

                    Goal: operation params should be typed to a class that will be emitted
                    under HaloDataTypes (i.e., a UML class with stereotype 'dataType').
                    """
                    tail = _ref_tail(ref)
                    if not tail:
                        return "DataElement"
                    # If a dataType class already exists, use it.
                    if tail in self._class_map:
                        return tail

                    # Check if the interface defines or references the struct; if so, create
                    # a forward dataType to ensure it lands in HaloDataTypes.
                    data = getattr(interface, "data", None)
                    structs = getattr(data, "structs", []) if data else []
                    for st in structs or []:
                        st_name = getattr(st, "name", None)
                        st_ref = getattr(st, "reference", None)
                        if st_name and str(st_name) == tail:
                            self._class_map[tail] = UMLClass(
                                name=tail,
                                id=f"cls_{tail}",
                                stereotypes=["dataType"],
                            )
                            self.uml_model.classes.append(self._class_map[tail])
                            return tail
                        if st_ref and _ref_tail(st_ref) == tail:
                            # Reference-only: create forward dataType
                            self._class_map[tail] = UMLClass(
                                name=tail,
                                id=f"cls_{tail}",
                                stereotypes=["dataType"],
                            )
                            self.uml_model.classes.append(self._class_map[tail])
                            return tail

                    # Fallback: preserve prior behavior.
                    return "DataElement"
                
                uml_iface = UMLClass(
                    name=name,
                    id=f"iface_{name}",
                    stereotypes=["interface"]
                )
                
                # Add read/write/integrity as operations
                access = getattr(interface, "access", None)
                if access:
                    read_params = []
                    for read_line in getattr(access, "readLines", []):
                        refs = getattr(getattr(read_line, "reads", None), "refs", [])
                        read_params.extend(refs)
                    
                    if read_params:
                        read_op = UMLOperation(name="read", id=f"op_{name}_read")
                        for param_name in read_params:
                            read_op.parameters.append(UMLParameter(
                                name=param_name,
                                type=_resolve_param_type(param_name),
                                direction=DirectionKind.OUT
                            ))
                        uml_iface.operations.append(read_op)
                    
                    write_params = []
                    for write_line in getattr(access, "writeLines", []):
                        refs = getattr(getattr(write_line, "writes", None), "refs", [])
                        write_params.extend(refs)
                    
                    if write_params:
                        write_op = UMLOperation(name="write", id=f"op_{name}_write")
                        for param_name in write_params:
                            write_op.parameters.append(UMLParameter(
                                name=param_name,
                                type=_resolve_param_type(param_name),
                                direction=DirectionKind.IN
                            ))
                        uml_iface.operations.append(write_op)
                
                integrity = getattr(interface, "integrity", None)
                if integrity:
                    for entry in getattr(integrity, "entries", []):
                        integrity_type = getattr(entry, "type", "integrity")
                        refs = getattr(getattr(entry, "targets", None), "refs", [])
                        
                        integrity_op = UMLOperation(name=integrity_type, id=f"op_{name}_{integrity_type}")
                        for ref in refs:
                            integrity_op.parameters.append(UMLParameter(
                                name=ref,
                                type=_resolve_param_type(ref),
                                direction=DirectionKind.IN
                            ))
                        uml_iface.operations.append(integrity_op)
                
                self.uml_model.classes.append(uml_iface)
                self._interface_map[name] = uml_iface
                
                # Create classes for data structures
                self._create_classes_from_interface(interface)
    
    def _create_classes_from_interface(self, idl_interface: Any):
        """Create UML Classes for data structures in IDL interface"""
        data = getattr(idl_interface, "data", None)
        if not data:
            return
        
        def _ref_tail(ref: Any) -> str:
            s = str(ref)
            return s.split(".")[-1] if "." in s else s

        created_structs: List[str] = []
        for struct in getattr(data, "structs", []):
            struct_name = getattr(struct, "name", None)
            struct_ref = getattr(struct, "reference", None)
            if not struct_name and struct_ref:
                # Reference-only: create a forward dataType so operations can type to it.
                ref_name = _ref_tail(struct_ref)
                if ref_name and ref_name not in self._class_map:
                    uml_class = UMLClass(
                        name=ref_name,
                        id=f"cls_{ref_name}",
                        stereotypes=["dataType"],
                    )
                    self.uml_model.classes.append(uml_class)
                    self._class_map[ref_name] = uml_class
                    created_structs.append(ref_name)
                continue
            if not struct_name:
                continue

            # Ensure unique struct classes across interfaces
            if struct_name in self._class_map:
                # If we created a forward placeholder earlier (e.g., from access refs),
                # upgrade it with real fields once we see the full definition.
                existing = self._class_map[struct_name]
                if not existing.attributes and getattr(struct, "fields", None):
                    # Keep stereotypes but ensure it's marked as a dataType.
                    if "dataType" not in existing.stereotypes:
                        existing.stereotypes.append("dataType")

                    for field in getattr(struct, "fields", []) or []:
                        field_type = getattr(field, "type", "type")
                        field_name = getattr(field, "name", "field")
                        arr = getattr(field, "array", None)
                        init = getattr(field, "init", None)

                        # Scalar fields must default to 1..1. Arrays carry multiplicity.
                        mult_upper = 1
                        if arr:
                            size = getattr(arr, "size", None)
                            mult_upper = None if size is None else int(size)

                        default = None
                        if init:
                            default = getattr(init, "value", None)

                        existing.attributes.append(
                            UMLProperty(
                                name=field_name,
                                type=field_type,
                                multiplicity_lower=0 if arr else 1,
                                multiplicity_upper=mult_upper,
                                default_value=default,
                                visibility=VisibilityKind.PRIVATE,
                            )
                        )

                created_structs.append(struct_name)
                continue
            
            uml_class = UMLClass(
                name=struct_name,
                id=f"cls_{struct_name}",
                stereotypes=["dataType"]
            )
            
            # Add fields as attributes
            for field in getattr(struct, "fields", []):
                field_type = getattr(field, "type", "type")
                field_name = getattr(field, "name", "field")
                arr = getattr(field, "array", None)
                init = getattr(field, "init", None)
                
                # Scalar fields must default to 1..1. Arrays carry multiplicity.
                mult_upper = 1
                if arr:
                    size = getattr(arr, "size", None)
                    mult_upper = None if size is None else int(size)
                
                default = None
                if init:
                    default = getattr(init, "value", None)
                
                uml_prop = UMLProperty(
                    name=field_name,
                    type=field_type,
                    multiplicity_lower=0 if arr else 1,
                    multiplicity_upper=mult_upper,
                    default_value=default,
                    visibility=VisibilityKind.PRIVATE
                )
                uml_class.attributes.append(uml_prop)
            
            self.uml_model.classes.append(uml_class)
            self._class_map[struct_name] = uml_class
            created_structs.append(struct_name)

        # Group all data structures under a typedef-like class so they stay linked to the interface
        if created_structs:
            iface_name = getattr(idl_interface, "name", "Interface")
            group_name = f"{iface_name}_dataStructures"

            # Avoid duplicate grouping classes
            if group_name in self._class_map:
                return

            group_class = UMLClass(
                name=group_name,
                id=f"typedef_{group_name}",
                stereotypes=["typedef", "dataGroup"]
            )
            for sname in created_structs:
                group_class.attributes.append(UMLProperty(
                    name=sname,
                    type=sname,
                    visibility=VisibilityKind.PUBLIC
                ))
            self.uml_model.classes.append(group_class)
            self._class_map[group_name] = group_class
    
    def _convert_components(self):
        """Convert HALO components to UML classes with stereotype 'component'"""
        for comp in self.unified_model.get("components", []):
            comp_name = getattr(comp, "name", None)
            comp_type = getattr(comp, "type", None)
            # Newer ADL uses `platform`; keep `os` as a backward-compatible alias.
            comp_platform = getattr(comp, "platform", None) or getattr(comp, "os", None)
            comp_function = getattr(comp, "function", None)
            
            if not comp_name:
                continue
            
            # Build stereotypes - only include non-None, non-empty values
            stereotypes = ["component"]
            if comp_type:
                stereotypes.append(comp_type)
            if comp_platform and comp_platform != comp_type:  # Avoid duplication with type
                stereotypes.append(comp_platform)
            if comp_function:
                stereotypes.append(comp_function)
            
            uml_comp = UMLClass(
                name=comp_name,
                id=f"component_{comp_name}",
                stereotypes=stereotypes
            )
            
            # Add attributes for component metadata
            if comp_type:
                uml_comp.attributes.append(UMLProperty(
                    name="type",
                    type="componentType" if comp_type in self._enum_literals_by_name.get("componentType", set()) else "String",
                    visibility=VisibilityKind.PUBLIC,
                    default_value=comp_type
                ))
            
            if comp_platform and comp_platform != comp_type:  # Only add platform attribute if it's different from type
                uml_comp.attributes.append(UMLProperty(
                    name="platform",
                    type="componentPlatform" if comp_platform in self._enum_literals_by_name.get("componentPlatform", set()) else "String",
                    visibility=VisibilityKind.PUBLIC,
                    default_value=comp_platform
                ))
            
            if comp_function:
                uml_comp.attributes.append(UMLProperty(
                    name="function",
                    type="componentFunction" if comp_function in self._enum_literals_by_name.get("componentFunction", set()) else "String",
                    visibility=VisibilityKind.PUBLIC,
                    default_value=comp_function
                ))
            
            self.uml_model.classes.append(uml_comp)
            self._component_map[comp_name] = uml_comp
    
    def _convert_connections(self):
        """Convert HALO connections to UML association classes"""
        for conn in self.unified_model.get("connections", []):
            src = getattr(conn, "from_component", None)
            dst = getattr(conn, "to_component", None)
            conn_name = getattr(conn, "name", None)
            communication = getattr(conn, "communication", None)
            interface_name = self._get_interface_name(conn)
            profile_name = self._get_profile_name(conn)
            
            if not (src and dst):
                continue
            
            # Create association class for the connection
            assoc_class = UMLClass(
                name=conn_name or f"{src}_to_{dst}",
                id=f"assoc_{conn_name or f'{src}_{dst}'}",
                stereotypes=["connection"] + ([communication] if communication else [])
            )
            
            # Add interface as attribute
            if interface_name:
                assoc_class.attributes.append(UMLProperty(
                    name="interface",
                    type=interface_name,
                    visibility=VisibilityKind.PUBLIC
                ))
            
            # Add profile as attribute
            if profile_name:
                assoc_class.attributes.append(UMLProperty(
                    name="profile",
                    type=profile_name,
                    visibility=VisibilityKind.PUBLIC
                ))
            
            self.uml_model.classes.append(assoc_class)
            
            # Create association from source component to target component
            # with the connection as association class
            association = UMLAssociation(
                name=f"{src}_to_{dst}_link",
                id=f"assoc_link_{src}_{dst}",
                source=src,
                target=dst,
                association_class=assoc_class.name
            )
            
            self.uml_model.associations.append(association)
    
    def _get_interface_name(self, connection: Any) -> Optional[str]:
        """Extract interface name from connection"""
        interface = getattr(connection, "interface", None)
        if interface is None:
            return None
        if hasattr(interface, "name"):
            return getattr(interface, "name")
        return str(interface)
    
    def _get_profile_name(self, connection: Any) -> Optional[str]:
        """Extract profile name from connection"""
        profile = getattr(connection, "profile", None)
        if profile is None:
            return None
        if hasattr(profile, "name"):
            return getattr(profile, "name")
        return str(profile)


def convert_halo_to_uml(
    unified_model: Dict[str, Any],
    idl_models: List[Any],
    profile_models: List[Any],
    user_types: Optional[Dict[str, List[str]]] = None
) -> UMLModel:
    """Convenience function to convert HALO model to UML IR"""
    converter = HALOToUMLConverter(
        unified_model,
        idl_models,
        profile_models,
        user_types=user_types,
    )
    return converter.convert()
