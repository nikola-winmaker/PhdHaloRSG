import os
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

NS_XMI = "http://www.omg.org/XMI"
NS_UML = "http://www.eclipse.org/uml2/5.0.0/UML"
# TODO: interfaces link to other interfaces not ok
ET.register_namespace("xmi", NS_XMI)
ET.register_namespace("uml", NS_UML)

# TODO interfaces link to other interfaces not ok

# ========================================================================
# Utility Functions
# ========================================================================

def _sid(prefix: str, name: str) -> str:
    """Generate a sanitized ID by prefixing and cleaning the name."""
    safe = re.sub(r"[^0-9A-Za-z_]+", "_", str(name))
    return f"{prefix}_{safe}"


def _safe_get(obj: Any, key: str) -> Optional[Any]:
    """Safely extract a value from dict or object attribute."""
    if isinstance(obj, dict):
        return obj.get(key)
    if hasattr(obj, key):
        return getattr(obj, key)
    return None


def _extract_name(value: Any) -> Optional[str]:
    """Extract name from various value types (string, dict, object)."""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return value.get("name")
    if hasattr(value, "name"):
        return getattr(value, "name")
    return None


# ========================================================================
# Data Classes
# ========================================================================

@dataclass
class FieldInfo:
    """Represents a struct field with type, name, and optional array/init."""
    name: str
    type: str
    upper: Optional[int] = None
    init: Optional[Any] = None


@dataclass
class IntegrityInfo:
    """Represents an integrity constraint with type and target refs."""
    type: str
    refs: List[str] = field(default_factory=list)


@dataclass
class IDLInterfaceInfo:
    """Aggregates all information about an IDL interface."""
    name: str
    structs: Dict[str, List[FieldInfo]] = field(default_factory=dict)
    struct_refs: List[Tuple[str, str]] = field(default_factory=list)  # (source_interface, struct_name)
    read: List[str] = field(default_factory=list)
    write: List[str] = field(default_factory=list)
    integrity: List[IntegrityInfo] = field(default_factory=list)


@dataclass
class ProfileInfo:
    """Represents a hardware mapping profile with its attributes."""
    name: str
    profile_type: str  # SharedMemory, DMA, MemoryMappedIO, etc.
    attributes: Dict[str, Any] = field(default_factory=dict)


class HALOUMLXMIExporter:
    """Export UML 2.x (XMI) from the HALO unified model and IDL models.

    Produces a single .uml (XMI) file containing:
    - Components as uml:Component
    - Interfaces as uml:Interface with operations for read/write/integrity
    - Structs as uml:Class with ownedAttributes for fields
    - Primitive types for basic field types (byte, integer, unsigned_int)
    - Usages (uml:Usage) from components to interfaces for each connection
    - Profiles as uml:Profile with stereotypes for hardware mapping configurations
    """

    def __init__(self, unified_model: Dict[str, Any], idl_models: Optional[List[Any]] = None, 
                 profile_models: Optional[List[Any]] = None) -> None:
        self.unified_model = unified_model or {"components": [], "connections": []}
        self.idl_models = idl_models or []
        self.profile_models = profile_models or []

        # UML specific maps
        self._id_map: Dict[str, str] = {}
        self._iface_id: Dict[str, str] = {}
        self._class_id: Dict[str, str] = {}
        self._comp_id: Dict[str, str] = {}
        self._prim_id: Dict[str, str] = {}
        self._profile_id: Dict[str, str] = {}
        self._stereotype_id: Dict[str, str] = {}

    def _ensure_primitive(self, parent: ET.Element, name: str) -> str:
        key = name.replace(" ", "_")
        if key in self._prim_id:
            return self._prim_id[key]
        pid = _sid("prim", key)
        el = ET.SubElement(parent, f"{{{NS_UML}}}packagedElement", {
            f"{{{NS_XMI}}}type": "uml:PrimitiveType",
            f"{{{NS_XMI}}}id": pid,
            "name": name,
        })
        self._prim_id[key] = pid
        return pid

    def _add_component(self, parent: ET.Element, name: str) -> str:
        if name in self._comp_id:
            return self._comp_id[name]
        cid = _sid("comp", name)
        ET.SubElement(parent, f"{{{NS_UML}}}packagedElement", {
            f"{{{NS_XMI}}}type": "uml:Component",
            f"{{{NS_XMI}}}id": cid,
            "name": name,
        })
        self._comp_id[name] = cid
        return cid

    def _add_interface(self, parent: ET.Element, name: str) -> ET.Element:
        if name in self._iface_id:
            iid = self._iface_id[name]
            # find existing element? Not needed for single pass
        iid = _sid("ifc", name)
        el = ET.SubElement(parent, f"{{{NS_UML}}}packagedElement", {
            f"{{{NS_XMI}}}type": "uml:Interface",
            f"{{{NS_XMI}}}id": iid,
            "name": name,
        })
        self._iface_id[name] = iid
        return el

    def _add_class(self, parent: ET.Element, name: str) -> ET.Element:
        if name in self._class_id:
            # Should be unique by name
            pass
        cid = _sid("cls", name)
        el = ET.SubElement(parent, f"{{{NS_UML}}}packagedElement", {
            f"{{{NS_XMI}}}type": "uml:Class",
            f"{{{NS_XMI}}}id": cid,
            "name": name,
        })
        self._class_id[name] = cid
        return el

    def _add_operation_with_params(self, iface_el: ET.Element, name: str, param_types: List[str], model_root: ET.Element):
        op_id = _sid("op", f"{iface_el.get('name')}_{name}")
        op = ET.SubElement(iface_el, f"{{{NS_UML}}}ownedOperation", {
            f"{{{NS_XMI}}}id": op_id,
            "name": name,
            "visibility": "public",
        })
        for idx, ptype in enumerate(param_types, start=1):
            # Ensure class exists for param type
            if ptype in self._class_id:
                tid = self._class_id[ptype]
            else:
                # create a forward class if not present yet
                tid = self._add_class(model_root, ptype).get(f"{{{NS_XMI}}}id")
            ET.SubElement(op, f"{{{NS_UML}}}ownedParameter", {
                f"{{{NS_XMI}}}id": _sid("param", f"{name}_{idx}_{ptype}"),
                "name": f"p{idx}",
                "type": tid,
                "direction": "in",
            })

    def _collect_idl(self) -> Dict[str, IDLInterfaceInfo]:
        """Collect and structure IDL interface information."""
        info_map: Dict[str, IDLInterfaceInfo] = {}
        
        if not self.idl_models:
            return info_map
        
        for idl_model in self.idl_models:
            # Skip if idl_model is None or not an object
            if not idl_model or not hasattr(idl_model, "__dict__"):
                continue
            
            interfaces = getattr(idl_model, "interfaces", [])
            if not interfaces:
                continue
            
            for interface in interfaces:
                # Skip if interface is a string or None
                if isinstance(interface, str) or interface is None:
                    continue
                
                name = getattr(interface, "name", None)
                if not name:
                    continue
                
                info = info_map.setdefault(name, IDLInterfaceInfo(name=name))
                self._collect_struct_info(interface, info)
                self._collect_access_info(interface, info)
                self._collect_integrity_info(interface, info)
        
        return info_map
    
    def _collect_struct_info(self, interface: Any, info: IDLInterfaceInfo) -> None:
        """Extract struct definitions and references from an interface."""
        data_section = getattr(interface, "data", None)
        if not data_section:
            return
        
        for struct in getattr(data_section, "structs", []) or []:
            # Check if this is a struct definition (has name and fields)
            struct_name = getattr(struct, "name", None)
            if struct_name:
                # This is a StructDef - full struct definition
                fields: List[FieldInfo] = []
                for field in getattr(struct, "fields", []) or []:
                    ftype = getattr(field, "type", "type")
                    fname = getattr(field, "name", "field")
                    arr = getattr(field, "array", None)
                    init = getattr(field, "init", None)
                    size = getattr(arr, "size", None) if arr else None
                    init_val = getattr(init, "value", None) if init else None
                    fields.append(FieldInfo(name=fname, type=ftype, upper=size, init=init_val))
                
                info.structs[struct_name] = fields
            else:
                # This is a StructRef - reference to external struct (e.g., TstIf_1.dataStructures.SharedData)
                reference = getattr(struct, "reference", None)
                if reference:
                    # Parse the FQN: Interface.dataStructures.StructName
                    parts = reference.split('.')
                    if len(parts) >= 3:  # Interface.dataStructures.StructName
                        source_interface = parts[0]
                        struct_name = parts[-1]
                        # Track this as a reference to be resolved during export
                        info.struct_refs.append((source_interface, struct_name))
    
    def _collect_access_info(self, interface: Any, info: IDLInterfaceInfo) -> None:
        """Extract read/write access information from an interface."""
        access = getattr(interface, "access", None)
        if not access:
            return
        
        for read_line in getattr(access, "readLines", []) or []:
            refs = getattr(getattr(read_line, "reads", None), "refs", []) or []
            info.read.extend(refs)
        
        for write_line in getattr(access, "writeLines", []) or []:
            refs = getattr(getattr(write_line, "writes", None), "refs", []) or []
            info.write.extend(refs)
    
    def _collect_integrity_info(self, interface: Any, info: IDLInterfaceInfo) -> None:
        """Extract integrity constraints from an interface."""
        integrity = getattr(interface, "integrity", None)
        if not integrity:
            return
        
        for entry in getattr(integrity, "entries", []) or []:
            etype = getattr(entry, "type", "integrity")
            refs = getattr(getattr(entry, "targets", None), "refs", []) or []
            info.integrity.append(IntegrityInfo(type=etype, refs=list(refs)))
    
    def _collect_profiles(self) -> Dict[str, ProfileInfo]:
        """Collect and structure profile information from HADL profile models."""
        profile_map: Dict[str, ProfileInfo] = {}
        
        if not self.profile_models:
            return profile_map
        
        for profile_model in self.profile_models:
            # Skip if profile_model is None or not an object
            if not profile_model or not hasattr(profile_model, "__dict__"):
                continue
            
            profiles = getattr(profile_model, "profiles", [])
            if not profiles:
                continue
            
            for prof in profiles:
                # Skip if prof is a string or None
                if isinstance(prof, str) or prof is None:
                    continue
                
                # Use _extract_name helper for consistent name extraction
                name = _extract_name(prof)
                if not name:
                    # Fallback to class name if no name attribute
                    name = prof.__class__.__name__ if hasattr(prof, "__class__") else None
                    if not name:
                        continue
                
                # Determine profile type; prefer explicit 'kind' for custom profiles
                profile_type = getattr(prof, "kind", None) or (prof.__class__.__name__ if hasattr(prof, "__class__") else "Profile")
                
                # Collect all profile attributes recursively
                try:
                    attributes = self._extract_profile_attributes(prof)
                except Exception:
                    # If attribute extraction fails, use empty dict
                    attributes = {}

                # Avoid redundancy in exported UML: profile instance id is already the class name,
                # and profile kind/type is already exported separately.
                attributes.pop("name", None)
                attributes.pop("kind", None)
                
                profile_map[name] = ProfileInfo(
                    name=name,
                    profile_type=profile_type,
                    attributes=attributes
                )
        
        return profile_map
    
    def _extract_profile_attributes(self, obj: Any, prefix: str = "") -> Dict[str, Any]:
        """Recursively extract attributes from a profile object."""
        attributes = {}
        
        if not hasattr(obj, "__dict__"):
            return attributes
        
        for key, value in obj.__dict__.items():
            if key.startswith("_") or key == "parent":
                continue
            
            full_key = f"{prefix}.{key}" if prefix else key
            
            if hasattr(value, "__dict__") and not isinstance(value, (str, int, float, bool)):
                # Recursively process nested objects
                nested = self._extract_profile_attributes(value, full_key)
                attributes.update(nested)
            elif isinstance(value, list):
                # Handle lists
                attributes[full_key] = ", ".join(str(v) for v in value)
            elif value is not None:
                attributes[full_key] = str(value)
        
        return attributes
    
    @staticmethod
    def _extract_component_descriptor(comp: Any) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
        """Extract name, type, platform, and function from a component object."""
        if isinstance(comp, str):
            return comp, None, None, None
        elif isinstance(comp, dict):
            platform = comp.get("platform")
            return (comp.get("name"), comp.get("type"), platform, comp.get("function"))
        else:
            platform = getattr(comp, "platform", None)
            return (
                getattr(comp, "name", None),
                getattr(comp, "type", None),
                platform,
                getattr(comp, "function", None)
            )
    
    def _create_uml_root(self) -> Tuple[ET.Element, ET.Element]:
        """Create and return the root XMI and model elements."""
        model = ET.Element(
            f"{{{NS_UML}}}Model",
            {
                f"{{{NS_XMI}}}version": "2.1",
                f"{{{NS_XMI}}}id": _sid("model", "HALO"),
                "name": "HALOModel",
            }
        )
        root = ET.Element(f"{{{NS_XMI}}}XMI")
        root.append(model)
        return root, model
    
    def _setup_primitives(self, model: ET.Element) -> Dict[str, str]:
        """Create primitive type definitions and return a mapping."""
        prim_map = {
            "bool": None,
            "byte": None,
            "int": None,
            "integer": None,
            "float": None,
            "double": None,
            "unsignedint": None,
            "String": None,
            "Hex": None,
            # Size-unit primitives
            "B": None,
            "kB": None,
            "MB": None,
        }
        for pname in prim_map.keys():
            prim_map[pname] = self._ensure_primitive(model, pname)
        return prim_map

    _hex_re = re.compile(r"^\s*0[xX][0-9a-fA-F]+\s*$")
    _uint_re = re.compile(r"^\s*\d+\s*$")

    _size_re = re.compile(r"^\s*(?P<num>\d+(?:\.\d+)?)\s*(?P<unit>B|kB|MB)\s*$")

    @classmethod
    def _parse_size_literal(cls, value: Any):
        """Parse strings like '1MB'/'256B' -> (unit, number_str, is_float)."""
        if not isinstance(value, str):
            return None
        m = cls._size_re.match(value)
        if not m:
            return None
        unit = m.group('unit')
        num_s = m.group('num')
        is_float = '.' in num_s
        return unit, num_s, is_float
    
    def _find_element_by_id(self, root: ET.Element, xmi_id: str) -> Optional[ET.Element]:
        """Find any UML element in the tree by its xmi:id."""
        for el in root.iter():
            if el.get(f"{{{NS_XMI}}}id") == xmi_id:
                return el
        return None

    def export(self, out_path: str) -> str:
        """Main export entry point - orchestrates the UML/XMI generation."""
        root, model = self._create_uml_root()
        prim_map = self._setup_primitives(model)
        
        # Track literal value classes (for component properties)
        self._literal_class_ids: Dict[str, str] = {}
        
        # Export major sections (profiles before components to get IDs)
        self._export_profiles(model)
        self._export_components(model)
        self._export_interfaces(model, prim_map)
        self._export_connections(model)
        
        # Write to file
        tree = ET.ElementTree(root)
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        tree.write(out_path, encoding="utf-8", xml_declaration=True)
        return out_path
    
    def _ensure_literal_class(self, model: ET.Element, value: str) -> str:
        """Create or reuse a UML Class representing a literal value."""
        if not value:
            return ""
        if value in self._literal_class_ids:
            return self._literal_class_ids[value]
        
        tid = _sid("tagcls", value)
        ET.SubElement(
            model,
            f"{{{NS_UML}}}packagedElement",
            {
                f"{{{NS_XMI}}}type": "uml:Class",
                f"{{{NS_XMI}}}id": tid,
                "name": str(value),
            },
        )
        self._literal_class_ids[value] = tid
        return tid
    
    def _add_component_property( self, model: ET.Element, 
                                comp_el: ET.Element, 
                                prop_name: str, prop_value: Optional[Any]) -> None:
        """Add a UML Property to a Component for metadata like type/platform/function."""
        if prop_value is None:
            return
        
        type_id = self._ensure_literal_class(model, str(prop_value))
        attr = ET.SubElement(
            comp_el,
            f"{{{NS_UML}}}ownedAttribute",
            {
                f"{{{NS_XMI}}}type": "uml:Property",
                f"{{{NS_XMI}}}id": _sid("prop", f"{comp_el.get('name')}_{prop_name}_{prop_value}"),
                "name": prop_name,
                "visibility": "private",
                "type": type_id,
                "lower": "1",
                "upper": "1",
                "default": str(prop_value),
            },
        )
    
    def _export_components(self, model: ET.Element) -> None:
        """Export all components with their properties to the UML model."""
        comps = self.unified_model.get("components", []) if isinstance(self.unified_model, dict) else []
        
        for comp in comps:
            name, c_type, c_platform, c_func = self._extract_component_descriptor(comp)
            if not name:
                continue
            
            cid = self._comp_id.get(name) or self._add_component(model, name)
            comp_el = self._find_element_by_id(model, cid)
            if comp_el is None:
                continue
            
            self._add_component_property(model, comp_el, "type", c_type)
            self._add_component_property(model, comp_el, "platform", c_platform)
            self._add_component_property(model, comp_el, "function", c_func)
            
            # Add Usage dependencies from component to its profiles
            comp_profiles = _safe_get(comp, "profiles")
            if comp_profiles:
                for profile_name in comp_profiles.keys() if isinstance(comp_profiles, dict) else []:
                    profile_id = self._profile_id.get(profile_name)
                    if profile_id:
                        ET.SubElement(
                            model,
                            f"{{{NS_UML}}}packagedElement",
                            {
                                f"{{{NS_XMI}}}type": "uml:Usage",
                                f"{{{NS_XMI}}}id": _sid("use", f"{name}_{profile_name}"),
                                "name": f"{name}_uses_{profile_name}",
                                "client": cid,
                                "supplier": profile_id,
                            },
                        )
    
    def _export_interfaces(self, model: ET.Element, prim_map: dict) -> None:
        """Export all IDL interfaces with their structs and operations to the UML model."""
        idl = self._collect_idl()

        for iface_name, info in idl.items():
            iface_el = self._add_interface(model, iface_name)
            iface_id = iface_el.get(f"{{{NS_XMI}}}id")

            # Track nested struct IDs for type resolution
            nested_ids = {}

            # Export structs (only definitions, not references)
            for struct_name, fields in info.structs.items():
                struct_id = _sid("cls", f"{iface_name}_{struct_name}")
                nested_ids[struct_name] = struct_id

                struct_el = ET.SubElement(
                    iface_el,
                    f"{{{NS_UML}}}nestedClassifier",
                    {
                        f"{{{NS_XMI}}}type": "uml:Class",
                        f"{{{NS_XMI}}}id": struct_id,
                        "name": struct_name,
                    },
                )

                # Export fields
                for field in fields:
                    # Resolve type ID
                    tid = self._resolve_type_id(model, field.type, prim_map, nested_ids)

                    field_el = ET.SubElement(
                        struct_el,
                        f"{{{NS_UML}}}ownedAttribute",
                        {
                            f"{{{NS_XMI}}}id": _sid("attr", f"{struct_name}_{field.name}"),
                            "name": field.name,
                            "type": tid,
                            "lower": "0" if field.upper else "1",
                            "upper": str(field.upper) if field.upper else "1",
                        },
                    )

                    if field.init is not None:
                        sval = str(field.init)
                        is_int = re.fullmatch(r"[-+]?\d+", sval) is not None
                        field_el.set("default", sval)
                        ET.SubElement(
                            field_el,
                            f"{{{NS_UML}}}defaultValue",
                            {
                                f"{{{NS_XMI}}}type": "uml:LiteralInteger" if is_int else "uml:LiteralString",
                                f"{{{NS_XMI}}}id": _sid("def", f"{struct_name}_{field.name}"),
                                "value": sval,
                            },
                        )

                # Create UML Usage: interface -> struct
                ET.SubElement(
                    model,
                    f"{{{NS_UML}}}packagedElement",
                    {
                        f"{{{NS_XMI}}}type": "uml:Usage",
                        f"{{{NS_XMI}}}id": _sid("use", f"{iface_name}_{struct_name}"),
                        "name": f"{iface_name}_uses_{struct_name}",
                        "client": iface_id,
                        "supplier": struct_id,
                    },
                )

            # Export operations
            self._add_operations(iface_el, iface_name, info, prim_map, nested_ids)
            
            # Create Usage dependencies for struct references to other interfaces
            for source_iface, ref_struct_name in info.struct_refs:
                # Find the referenced struct ID from the source interface
                ref_struct_id = _sid("cls", f"{source_iface}_{ref_struct_name}")
                # Create Usage: current interface -> referenced struct
                ET.SubElement(
                    model,
                    f"{{{NS_UML}}}packagedElement",
                    {
                        f"{{{NS_XMI}}}type": "uml:Usage",
                        f"{{{NS_XMI}}}id": _sid("ref", f"{iface_name}_{source_iface}_{ref_struct_name}"),
                        "name": f"{iface_name}_references_{ref_struct_name}",
                        "client": iface_id,
                        "supplier": ref_struct_id,
                    },
                )
    
    def _resolve_type_id(self, model: ET.Element, type_name: str, prim_map: dict, nested_ids: dict) -> str:
        """Resolve UML type ID for a given type name."""
        alias_map = {
            "string": "String",
            "unsigned int": "unsignedint",
        }
        type_name = alias_map.get(type_name, type_name)

        if type_name in prim_map:
            return prim_map[type_name]
        elif type_name in nested_ids:
            return nested_ids[type_name]
        else:
            # Fallback: create class if missing
            if type_name not in self._class_id:
                cls_el = self._add_class(model, type_name)
                return cls_el.get(f"{{{NS_XMI}}}id")
            else:
                return self._class_id[type_name]
    
    def _add_operations(self, iface_el: ET.Element, iface_name: str, info: IDLInterfaceInfo, 
                       prim_map: dict, nested_ids: dict) -> None:
        """Add operations (read, write, integrity) to an interface."""
        def add_operation(op_name: str, param_types: list) -> None:
            op_el = ET.SubElement(
                iface_el,
                f"{{{NS_UML}}}ownedOperation",
                {
                    f"{{{NS_XMI}}}id": _sid("op", f"{iface_name}_{op_name}"),
                    "name": op_name,
                },
            )
            for i, ptype in enumerate(param_types, 1):
                pid = nested_ids.get(ptype) or prim_map.get(ptype)

                par_el = ET.SubElement(
                    op_el,
                    f"{{{NS_UML}}}ownedParameter",
                    {
                        f"{{{NS_XMI}}}id": _sid("param", f"{op_name}_p{i}"),
                        "name": f"p{i}",
                        "direction": "in",
                    },
                )
                if pid:
                    par_el.set("type", pid)

        if info.read:
            add_operation("read", info.read)
        if info.write:
            add_operation("write", info.write)
        for intr in info.integrity:
            add_operation(intr.type, intr.refs)
    
    def _export_profiles(self, model: ET.Element) -> None:
        """Export hardware mapping profiles as UML Classes with attributes (same as interfaces)."""
        profiles = self._collect_profiles()
        
        if not profiles:
            return
        
        for profile_name, profile_info in profiles.items():
            # Create profile as a UML Class (just like structs in interfaces)
            profile_id = _sid("profile_cls", profile_name)
            profile_el = ET.SubElement(
                model,
                f"{{{NS_UML}}}packagedElement",
                {
                    f"{{{NS_XMI}}}type": "uml:Class",
                    f"{{{NS_XMI}}}id": profile_id,
                    "name": profile_name,
                },
            )
            self._profile_id[profile_name] = profile_id
            
            # Add all profile attributes as class attributes (only from model, no extra attributes)
            for attr_name, attr_value in profile_info.attributes.items():
                attr_id = _sid("attr", f"{profile_name}_{attr_name}")
                attr_el = ET.SubElement(
                    profile_el,
                    f"{{{NS_UML}}}ownedAttribute",
                    {
                        f"{{{NS_XMI}}}id": attr_id,
                        "name": attr_name,
                        "visibility": "public",
                    },
                )

                if attr_value is None:
                    continue

                s = str(attr_value).strip()

                # Any hex literal becomes type Hex.
                if self._hex_re.match(s):
                    type_id = self._prim_id.get("Hex") or self._ensure_primitive(model, "Hex")
                    attr_el.set("type", type_id)
                    attr_el.set("default", s)
                    ET.SubElement(
                        attr_el,
                        f"{{{NS_UML}}}defaultValue",
                        {
                            f"{{{NS_XMI}}}type": "uml:LiteralString",
                            f"{{{NS_XMI}}}id": _sid("val", f"{profile_name}_{attr_name}"),
                            "value": s,
                        },
                    )
                    continue

                # Address-like fields: decimal values become unsigned int
                # Decimal integers: signed or unsigned
                if self._uint_re.match(s):
                    # Positive integer -> unsignedint
                    type_id = self._prim_id.get("unsignedint") or self._ensure_primitive(model, "unsignedint")
                    attr_el.set("type", type_id)
                    attr_el.set("default", s)
                    ET.SubElement(
                        attr_el,
                        f"{{{NS_UML}}}defaultValue",
                        {
                            f"{{{NS_XMI}}}type": "uml:LiteralInteger",
                            f"{{{NS_XMI}}}id": _sid("val", f"{profile_name}_{attr_name}"),
                            "value": s,
                        },
                    )
                    continue
                elif re.match(r"^\s*-\d+\s*$", s):
                    # Negative integer -> integer
                    type_id = self._prim_id.get("integer") or self._ensure_primitive(model, "integer")
                    attr_el.set("type", type_id)
                    attr_el.set("default", s)
                    ET.SubElement(
                        attr_el,
                        f"{{{NS_UML}}}defaultValue",
                        {
                            f"{{{NS_XMI}}}type": "uml:LiteralInteger",
                            f"{{{NS_XMI}}}id": _sid("val", f"{profile_name}_{attr_name}"),
                            "value": s,
                        },
                    )
                    continue

                parsed = self._parse_size_literal(attr_value)
                if parsed:
                    unit, num_s, is_float = parsed
                    # Ensure primitive exists and set property type accordingly.
                    type_id = self._prim_id.get(unit) or self._ensure_primitive(model, unit)
                    attr_el.set("type", type_id)
                    attr_el.set("default", num_s)
                    ET.SubElement(
                        attr_el,
                        f"{{{NS_UML}}}defaultValue",
                        {
                            f"{{{NS_XMI}}}type": "uml:LiteralReal" if is_float else "uml:LiteralInteger",
                            f"{{{NS_XMI}}}id": _sid("val", f"{profile_name}_{attr_name}"),
                            "value": num_s,
                        },
                    )
                else:
                    attr_el.set("default", str(attr_value))
                    ET.SubElement(
                        attr_el,
                        f"{{{NS_UML}}}defaultValue",
                        {
                            f"{{{NS_XMI}}}type": "uml:LiteralString",
                            f"{{{NS_XMI}}}id": _sid("val", f"{profile_name}_{attr_name}"),
                            "value": str(attr_value),
                        },
                    )
    
    def _export_connections(self, model: ET.Element) -> None:
        """Export all component connections with provided/required interfaces."""
        conns = self.unified_model.get("connections", []) if isinstance(self.unified_model, dict) else []

        for conn in conns:
            src = _safe_get(conn, "from_component")
            dst = _safe_get(conn, "to_component")
            conn_name = _safe_get(conn, "name")
            iface_name = _safe_get(conn, "interface")

            if not (src and iface_name):
                continue

            sid = self._comp_id.get(src) or self._add_component(model, src)
            iid = self._iface_id.get(iface_name) or self._add_interface(model, iface_name).get(f"{{{NS_XMI}}}id")

            # Source component provides the interface (InterfaceRealization - lollipop notation)
            ET.SubElement(
                model,
                f"{{{NS_UML}}}packagedElement",
                {
                    f"{{{NS_XMI}}}type": "uml:InterfaceRealization",
                    f"{{{NS_XMI}}}id": _sid("prov", f"{conn_name}_{src}_{iface_name}"),
                    "name": f"{conn_name}_provided",
                    "client": sid,
                    "supplier": iid,
                    "contract": iid,
                },
            )

            if dst:
                did = self._comp_id.get(dst) or self._add_component(model, dst)
                # Destination component requires the interface (Usage - socket notation)
                ET.SubElement(
                    model,
                    f"{{{NS_UML}}}packagedElement",
                    {
                        f"{{{NS_XMI}}}type": "uml:Usage",
                        f"{{{NS_XMI}}}id": _sid("req", f"{conn_name}_{dst}_{iface_name}"),
                        "name": f"{conn_name}_required",
                        "client": did,
                        "supplier": iid,
                    },
                )
