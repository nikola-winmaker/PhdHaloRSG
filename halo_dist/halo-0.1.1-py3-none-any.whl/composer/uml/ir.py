# Tool-neutral UML IR (Model/Package/Class/Port/Connector...)
"""
UML Intermediate Representation (IR)
This module defines a tool-neutral UML metamodel for representing HALO systems.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from enum import Enum


class VisibilityKind(Enum):
    """UML visibility kinds"""
    PUBLIC = "public"
    PRIVATE = "private"
    PROTECTED = "protected"
    PACKAGE = "package"


class DirectionKind(Enum):
    """Parameter direction kinds"""
    IN = "in"
    OUT = "out"
    INOUT = "inout"
    RETURN = "return"


@dataclass
class UMLElement:
    """Base class for all UML elements"""
    name: str
    id: Optional[str] = None
    visibility: VisibilityKind = VisibilityKind.PUBLIC


@dataclass
class UMLProperty(UMLElement):
    """UML Property (attribute/field)"""
    type: str = "void"
    multiplicity_lower: int = 1
    multiplicity_upper: Optional[int] = 1  # None means unbounded (*)
    default_value: Optional[Any] = None
    is_static: bool = False
    is_read_only: bool = False


@dataclass
class UMLParameter(UMLElement):
    """UML Parameter"""
    type: str = "void"
    direction: DirectionKind = DirectionKind.IN
    default_value: Optional[Any] = None


@dataclass
class UMLOperation(UMLElement):
    """UML Operation (method)"""
    parameters: List[UMLParameter] = field(default_factory=list)
    return_type: Optional[str] = None
    is_abstract: bool = False
    is_static: bool = False


@dataclass
class UMLClass(UMLElement):
    """UML Class"""
    attributes: List[UMLProperty] = field(default_factory=list)
    operations: List[UMLOperation] = field(default_factory=list)
    stereotypes: List[str] = field(default_factory=list)
    is_abstract: bool = False
    generalizations: List[str] = field(default_factory=list)  # References to parent classes


@dataclass
class UMLInterface(UMLElement):
    """UML Interface"""
    operations: List[UMLOperation] = field(default_factory=list)
    stereotypes: List[str] = field(default_factory=list)


@dataclass
class UMLPort(UMLElement):
    """UML Port"""
    type: Optional[str] = None  # Reference to Interface or Class
    is_conjugated: bool = False
    is_service: bool = False
    is_behavior: bool = False


@dataclass
class UMLComponent(UMLElement):
    """UML Component"""
    ports: List[UMLPort] = field(default_factory=list)
    attributes: List[UMLProperty] = field(default_factory=list)
    stereotypes: List[str] = field(default_factory=list)
    provided_interfaces: List[str] = field(default_factory=list)  # References to interfaces
    required_interfaces: List[str] = field(default_factory=list)  # References to interfaces


@dataclass
class UMLConnector(UMLElement):
    """UML Connector (connects two ports/components)"""
    source: str = ""  # Reference to component/port
    target: str = ""  # Reference to component/port
    source_port: Optional[str] = None  # Reference to port on source
    target_port: Optional[str] = None  # Reference to port on target
    type: Optional[str] = None  # Reference to interface/protocol
    stereotypes: List[str] = field(default_factory=list)


@dataclass
class UMLDependency(UMLElement):
    """UML Dependency (usage, realization, etc.)"""
    client: str = ""  # Reference to client element
    supplier: str = ""  # Reference to supplier element
    stereotypes: List[str] = field(default_factory=list)


@dataclass
class UMLAssociation(UMLElement):
    """UML Association (connects two classes)"""
    source: str = ""  # Reference to source class
    target: str = ""  # Reference to target class
    source_multiplicity: str = "1"  # e.g., "1", "0..1", "1..*", "*"
    target_multiplicity: str = "1"
    association_class: Optional[str] = None  # Reference to association class if present
    stereotypes: List[str] = field(default_factory=list)


@dataclass
class UMLEnumeration(UMLElement):
    """UML Enumeration"""
    literals: List[str] = field(default_factory=list)


@dataclass
class UMLPackage(UMLElement):
    """UML Package"""
    classes: List[UMLClass] = field(default_factory=list)
    interfaces: List[UMLInterface] = field(default_factory=list)
    components: List[UMLComponent] = field(default_factory=list)
    enumerations: List[UMLEnumeration] = field(default_factory=list)
    packages: List['UMLPackage'] = field(default_factory=list)
    connectors: List[UMLConnector] = field(default_factory=list)
    dependencies: List[UMLDependency] = field(default_factory=list)
    associations: List[UMLAssociation] = field(default_factory=list)


@dataclass
class UMLModel(UMLElement):
    """UML Model (top-level container)"""
    packages: List[UMLPackage] = field(default_factory=list)
    classes: List[UMLClass] = field(default_factory=list)
    interfaces: List[UMLInterface] = field(default_factory=list)
    components: List[UMLComponent] = field(default_factory=list)
    connectors: List[UMLConnector] = field(default_factory=list)
    dependencies: List[UMLDependency] = field(default_factory=list)
    associations: List[UMLAssociation] = field(default_factory=list)
    enumerations: List[UMLEnumeration] = field(default_factory=list)
    
    def get_all_components(self) -> List[UMLComponent]:
        """Get all components including those in packages"""
        comps = list(self.components)
        for pkg in self.packages:
            comps.extend(pkg.components)
        return comps
    
    def get_all_interfaces(self) -> List[UMLInterface]:
        """Get all interfaces including those in packages"""
        ifaces = list(self.interfaces)
        for pkg in self.packages:
            ifaces.extend(pkg.interfaces)
        return ifaces
    
    def get_all_classes(self) -> List[UMLClass]:
        """Get all classes including those in packages"""
        classes = list(self.classes)
        for pkg in self.packages:
            classes.extend(pkg.classes)
        return classes

    def get_all_enumerations(self) -> List[UMLEnumeration]:
        """Get all enumerations including those in packages"""
        enums = list(self.enumerations)
        for pkg in self.packages:
            enums.extend(pkg.enumerations)
        return enums