import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from typing import Any, Dict, List, Optional


def _norm_label_text(text: str) -> str:
    # Some upstream names already contain literal "\\n"; treat that as a newline.
    return text.replace("\\n", "\n")


def _qid(text: str) -> str:
    """Graphviz quoted string."""
    text = _norm_label_text(text)
    # Escape backslashes and quotes, then encode real newlines as Graphviz \n.
    text = text.replace('\\', '\\\\').replace('"', '\\"')
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\n", "\\n")
    return '"' + text + '"'


def _node_id(name: str) -> str:
    # Use a stable node id distinct from the label.
    slug = re.sub(r"[^0-9A-Za-z_]", "_", name)
    slug = re.sub(r"_+", "_", slug).strip("_")
    return f"n_{slug or 'N'}"


def unified_model_to_dot(model: Dict[str, Any]) -> str:
    components = model.get("components") or []
    connections = model.get("connections") or []

    # Map component names -> node ids
    comp_names: List[str] = []
    for c in components:
        if isinstance(c, dict) and isinstance(c.get("name"), str):
            comp_names.append(c["name"])

    node_ids = {name: _node_id(name) for name in comp_names}

    lines: List[str] = []
    lines.append("digraph halo {")
    lines.append("  rankdir=LR;")
    lines.append("  graph [fontsize=10];")
    lines.append("  node [shape=box, fontsize=10];")
    lines.append("  edge [fontsize=9];")

    # Nodes
    for c in components:
        if not isinstance(c, dict):
            continue
        name = c.get("name")
        if not isinstance(name, str) or not name:
            continue

        ctype = c.get("type")
        platform = c.get("platform")
        function = c.get("function")

        label_parts = [_norm_label_text(name)]
        meta_bits = [b for b in [ctype, platform, function] if isinstance(b, str) and b]
        if meta_bits:
            label_parts.append(" / ".join(_norm_label_text(b) for b in meta_bits))
        label = "\n".join(label_parts)

        nid = node_ids.get(name, _node_id(name))
        lines.append(f"  {nid} [label={_qid(label)}];")

    lines.append("")

    # Edges
    for conn in connections:
        if not isinstance(conn, dict):
            continue

        src = conn.get("from_component")
        dst = conn.get("to_component")
        if not isinstance(src, str) or not isinstance(dst, str) or not src or not dst:
            continue

        src_id = node_ids.get(src, _node_id(src))
        dst_id = node_ids.get(dst, _node_id(dst))

        # Ensure nodes exist even if not listed in components.
        if src not in node_ids:
            lines.append(f"  {src_id} [label={_qid(src)}];")
            node_ids[src] = src_id
        if dst not in node_ids:
            lines.append(f"  {dst_id} [label={_qid(dst)}];")
            node_ids[dst] = dst_id

        name = conn.get("name")
        iface = conn.get("interface")
        prof = conn.get("profile")

        label_bits: List[str] = []
        if isinstance(name, str) and name:
            label_bits.append(_norm_label_text(name))
        if isinstance(iface, str) and iface:
            label_bits.append(_norm_label_text(f"iface:{iface}"))
        if isinstance(prof, str) and prof:
            label_bits.append(_norm_label_text(f"profile:{prof}"))

        if label_bits:
            label = "\n".join(label_bits)
            lines.append(f"  {src_id} -> {dst_id} [label={_qid(label)}];")
        else:
            lines.append(f"  {src_id} -> {dst_id};")

    lines.append("}")
    return "\n".join(lines) + "\n"


def _try_render(dot_path: str, out_path: str) -> None:
    dot_exe = shutil.which("dot")
    if not dot_exe:
        print(
            "Warning: Graphviz 'dot' was not found on PATH; skipping render. "
            "Install Graphviz and/or add its bin folder to PATH.",
            file=sys.stderr,
        )
        return
    fmt = os.path.splitext(out_path)[1].lstrip(".").lower() or "png"
    subprocess.run([dot_exe, f"-T{fmt}", dot_path, "-o", out_path], check=True)


def main() -> int:
    # When running from VS Code, the working directory can be different.
    # Anchor defaults to the repository root (HALO/) based on this file location.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    repo_root = os.path.normpath(os.path.join(script_dir, "..", "..", ".."))
    default_output_dir = os.path.join(repo_root, "output")
    default_input = os.path.join(default_output_dir, "halo_unified_model.json")
    default_dot = os.path.join(default_output_dir, "halo_unified_model.dot")
    default_svg = os.path.join(default_output_dir, "halo_unified_model.svg")

    no_args = len(sys.argv) <= 1

    p = argparse.ArgumentParser(description="Export Graphviz .dot (and optional image) from halo_unified_model.json")
    p.add_argument(
        "--input",
        "-i",
        default=default_input,
        help="Path to halo_unified_model.json",
    )
    p.add_argument(
        "--dot",
        default=default_dot,
        help="Output .dot path",
    )
    p.add_argument(
        "--render",
        nargs="?",
        const=default_svg,
        default=(default_svg if no_args else None),
        help=(
            "Optional image output path (e.g. output/halo_unified_model.png or .svg). "
            "If passed without a value, defaults to output/halo_unified_model.svg. "
            "Requires Graphviz 'dot' on PATH."
        ),
    )
    args = p.parse_args()

    try:
        with open(args.input, "r", encoding="utf-8") as f:
            model = json.load(f)
    except FileNotFoundError:
        raise SystemExit(
            f"Input JSON not found: {args.input}\n"
            "Tip: run the composer first to generate output/halo_unified_model.json, "
            "or pass --input explicitly."
        )
    if not isinstance(model, dict):
        raise SystemExit("Expected top-level JSON object")

    dot = unified_model_to_dot(model)
    os.makedirs(os.path.dirname(os.path.abspath(args.dot)), exist_ok=True)
    with open(args.dot, "w", encoding="utf-8") as f:
        f.write(dot)

    print(args.dot)

    if args.render:
        os.makedirs(os.path.dirname(os.path.abspath(args.render)), exist_ok=True)
        _try_render(args.dot, args.render)
        print(args.render)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
