import argparse
import hashlib
import json
import os
import pickle
from typing import Any, Tuple


def sha256_head(path: str, n: int = 16) -> str:
    with open(path, "rb") as f:
        data = f.read()
    return hashlib.sha256(data).hexdigest()[:n], len(data)


def first_diff(a: Any, b: Any, path: str = "$") -> Tuple[str, str] | None:
    if type(a) is not type(b):
        return path, f"type {type(a).__name__} != {type(b).__name__}"

    if isinstance(a, dict):
        ak = list(a.keys())
        bk = list(b.keys())
        if set(ak) != set(bk):
            return path, f"keys differ: {set(ak) ^ set(bk)}"

        # Walk in insertion order to surface ordering-based differences.
        for k in ak:
            d = first_diff(a[k], b[k], path + "." + str(k))
            if d:
                return d
        return None

    if isinstance(a, list):
        if len(a) != len(b):
            return path, f"len {len(a)} != {len(b)}"
        for i, (x, y) in enumerate(zip(a, b)):
            d = first_diff(x, y, path + f"[{i}]")
            if d:
                return d
        return None

    if a != b:
        return path, f"{a!r} != {b!r}"

    return None


def main() -> int:
    ap = argparse.ArgumentParser(description="Compare two pickle files by content.")
    ap.add_argument("pkl_a")
    ap.add_argument("pkl_b")
    args = ap.parse_args()

    p1 = os.path.abspath(args.pkl_a)
    p2 = os.path.abspath(args.pkl_b)

    h1, n1 = sha256_head(p1)
    h2, n2 = sha256_head(p2)
    print(f"A: {p1} bytes={n1} sha256[:16]={h1}")
    print(f"B: {p2} bytes={n2} sha256[:16]={h2}")

    with open(p1, "rb") as f:
        o1 = pickle.load(f)
    with open(p2, "rb") as f:
        o2 = pickle.load(f)

    print("Python equality (o1 == o2):", o1 == o2)

    s1 = json.dumps(o1, sort_keys=True, separators=(",", ":"))
    s2 = json.dumps(o2, sort_keys=True, separators=(",", ":"))
    print("Canonical JSON equal:", s1 == s2)

    if isinstance(o1, dict) and isinstance(o2, dict):
        for k in ["interfaces", "profiles", "dataTypes"]:
            if k in o1 and k in o2 and isinstance(o1[k], dict) and isinstance(o2[k], dict):
                ko1 = list(o1[k].keys())
                ko2 = list(o2[k].keys())
                same = ko1 == ko2
                print(f"Key order for {k}: same={same} len1={len(ko1)} len2={len(ko2)}")
                if not same:
                    print("  first5 A:", ko1[:5])
                    print("  first5 B:", ko2[:5])

    d = first_diff(o1, o2)
    print("First diff:", d)

    # Pickle encodes shared references; two equal graphs can pickle differently
    # if they share sub-objects differently. Report basic sharing stats.
    def sharing_stats(obj: Any) -> tuple[int, int]:
        seen: dict[int, int] = {}

        def walk(x: Any):
            if isinstance(x, (dict, list)):
                oid = id(x)
                seen[oid] = seen.get(oid, 0) + 1
                if isinstance(x, dict):
                    for v in x.values():
                        walk(v)
                else:
                    for v in x:
                        walk(v)

        walk(obj)
        total = len(seen)
        shared = sum(1 for c in seen.values() if c > 1)
        return total, shared

    t1, s1 = sharing_stats(o1)
    t2, s2 = sharing_stats(o2)
    print(f"Container identity stats: A containers={t1} shared_containers={s1}")
    print(f"Container identity stats: B containers={t2} shared_containers={s2}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
