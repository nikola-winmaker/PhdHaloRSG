import argparse
import sys


def _parse_supported_platforms_arg(value: str | list[str] | None) -> list[str]:
    if not value:
        return []

    if isinstance(value, list):
        raw_items = value
    else:
        raw_items = [value]

    parsed: list[str] = []
    for raw in raw_items:
        parsed.extend(
            item.strip().lower()
            for item in raw.split(',')
            if item.strip()
        )
    return parsed

def run_generator(args) -> int:
    # Delegate to generator CLI implementation to keep behavior in sync.
    from generator.executor import main as generator_main

    argv = [
        '--input',
        args.composer_output_dir,
    ]
    if getattr(args, 'output_dir', None):
        argv.extend(['--output', args.output_dir])
    if getattr(args, 'pkl_path', None):
        argv.extend(['--pkl', args.pkl_path])
    if getattr(args, 'log_level', None):
        argv.extend(['--log-level', args.log_level])
    for platform in getattr(args, 'platforms', []) or []:
        argv.extend(['--platform', platform])

    try:
        return int(generator_main(argv))
    except FileNotFoundError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[ERROR] Code generation failed: {e}", file=sys.stderr)
        print("[ERROR] Run with --debug for full stack trace", file=sys.stderr)
        return 1


def run_update_generator(args) -> int:
    """Update configuration attributes of an existing generator."""
    from pathlib import Path
    from generator.updater import GeneratorConfigUpdater
    
    # Find config.py in the generator package
    generator_path = Path(args.path).resolve()
    config_path = None
    
    # Search for config.py in common locations
    for search_path in [
        generator_path / "src" / "*/config.py",
        generator_path / "config.py",
    ]:
        matches = list(generator_path.glob(str(search_path).replace(str(generator_path), "").lstrip("/\\")))
        if matches:
            config_path = matches[0]
            break
    
    if not config_path or not config_path.exists():
        print(f"Error: Could not find config.py in {generator_path}")
        return 1
    
    try:
        updater = GeneratorConfigUpdater(config_path)
        
        # List current platforms
        if args.list_platforms:
            platforms = updater.get_platforms()
            if platforms:
                print(f"Supported platforms: {', '.join(platforms)}")
            else:
                print("No supported_platforms found in config")
            return 0
        
        # Add platforms
        if args.add_platforms:
            new_platforms = _parse_supported_platforms_arg(args.add_platforms)
            if not updater.add_platforms(new_platforms):
                return 1
            print(f"Added platforms: {', '.join(new_platforms)}")
        
        # Remove platforms
        if args.remove_platforms:
            remove_platforms = _parse_supported_platforms_arg(args.remove_platforms)
            if not updater.remove_platforms(remove_platforms):
                return 1
            print(f"Removed platforms: {', '.join(remove_platforms)}")
        
        # Update description
        if args.description:
            if not updater.update_attribute("description", args.description):
                return 1
            print(f"Updated description")
        
        # Update name
        if args.name:
            if not updater.update_attribute("name", args.name):
                return 1
            print(f"Updated name")
        
        return 0
        
    except Exception as e:
        print(f"Error: {e}")
        return 1


def run_create_generator(args) -> int:
    """Create a new HALO generator package with scaffolding."""
    from pathlib import Path
    from generator.questionnaire import GeneratorQuestionnaire
    from generator.scaffold import GeneratorScaffold
    
    # Determine output directory
    if args.output_dir:
        output_dir = Path(args.output_dir).expanduser().resolve()
    else:
        output_dir = Path.cwd()
    
    # Run questionnaire if in interactive mode
    if args.interactive:
        questionnaire = GeneratorQuestionnaire()
        params = questionnaire.run()
        
        if not params:
            return 1  # User cancelled
    else:
        target_name = args.protocol if args.protocol else args.platform

        # Non-interactive mode: require all common parameters and target name
        if not all([args.name, args.description, args.author, args.email, target_name]):
            print("Error: In non-interactive mode, all parameters are required:")
            print("  --name, --description, --author, --email")
            if args.generator_type == 'protocol':
                print("  --protocol")
            else:
                print("  --platform")
            return 1

        supported_platforms = _parse_supported_platforms_arg(args.supported_platforms)
        if args.generator_type == 'protocol':
            available_platforms = GeneratorQuestionnaire.get_available_platforms()
            if not available_platforms:
                print("Error: No available platforms were discovered. Install or register at least one platform generator before creating a protocol generator.")
                return 1

            is_valid, error_message, supported_platforms = GeneratorQuestionnaire.parse_supported_platforms(
                args.supported_platforms or "",
                available_platforms,
            )
            if not is_valid:
                print(f"Error: {error_message}")
                return 1
        
        params = {
            "name": args.name,
            "description": args.description,
            "author": args.author,
            "email": args.email,
            "target_platform": target_name,
            "supported_platforms": supported_platforms,
            "has_os": args.os,
            "template_engine": args.template_engine,
            "generator_type": args.generator_type,
        }
    
    # Create the generator
    try:
        scaffold = GeneratorScaffold(output_dir)
        scaffold.create_generator(**params)
        return 0
    except Exception as e:
        print(f"\nError creating generator: {e}")
        return 1

def main() -> int:

    def add_compose_args(p):
        input_group = p.add_mutually_exclusive_group(required=True)
        input_group.add_argument(
            '--hadls-root',
            '-a',
            dest='hadls_root',
            metavar='DIR',
            help='Root directory containing HADL description files',
        )
        input_group.add_argument(
            '--from-xmi',
            dest='from_xmi',
            metavar='FILE',
            help='Path to a UML XMI model (.uml/.xmi) to import instead of HADL',
        )
        p.add_argument(
            '--output-dir',
            '-o',
            dest='output_dir',
            metavar='DIR',
            required=True,
            help='Output directory for generated files',
        )
        # Keep options aligned with composer CLI.
        p.add_argument(
            '--log-level',
            '-l',
            dest='log_level',
            metavar='LEVEL',
            default='INFO',
            choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
            help='Logging levels: DEBUG, INFO, WARNING, ERROR',
        )

        p.add_argument(
            '--include-stdlib-profiles',
            action='store_true',
            help='Include built-in stdlib profile templates shipped with the package.',
        )
        p.add_argument(
            '--user-types',
            dest='user_types',
            default=None,
            help='Optional path to a JSON file defining user types to extend HALO built-in types.',
        )

    def add_generate_args(p):
        p.add_argument(
            '--composer-output-dir',
            '--input-dir',
            '-i',
            dest='composer_output_dir',
            metavar='DIR',
            required=True,
            help='Composer output directory containing halo_unified_model.pkl',
        )
        p.add_argument(
            '--output-dir',
            '-o',
            dest='output_dir',
            metavar='DIR',
            default=None,
            help='Output directory for generator artifacts (default: same as --composer-output-dir)',
        )
        # Platforms are auto-discovered from the unified model unless the user
        # explicitly filters generation with --platform/--env.
        p.add_argument(
            '--platform',
            '-p',
            dest='platforms',
            action='append',
            required=False,
            default=[],
            help='Generate only the specified platform. Repeat for multiple platforms.',
        )
        p.add_argument(
            '--env',
            '-e',
            dest='platforms',
            action='append',
            required=False,
            help='(Deprecated) Alias for --platform',
        )
        p.add_argument(
            '--pkl',
            dest='pkl_path',
            default=None,
            metavar='FILE',
            help='Optional explicit path to halo_unified_model.pkl (default: <composer-output-dir>/halo_unified_model.pkl)',
        )
        p.add_argument(
            '--log-level',
            '-l',
            dest='log_level',
            metavar='LEVEL',
            default='INFO',
            choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
            help='Logging level for generator and protocol plugins',
        )
    
    def add_create_generator_args(p):
        p.add_argument(
            '--interactive',
            '-i',
            action='store_true',
            default=True,
            help='Interactive mode with questionnaire (default)',
        )
        p.add_argument(
            '--no-interactive',
            dest='interactive',
            action='store_false',
            help='Non-interactive mode (requires all parameters)',
        )
        p.add_argument(
            '--generator-type',
            choices=['platform', 'protocol'],
            default='platform',
            help='Type of generator scaffold to create (default: platform)',
        )
        p.add_argument(
            '--name',
            help='Generator name (e.g., my_platform)',
        )
        p.add_argument(
            '--description',
            help='Brief description of the generator',
        )
        p.add_argument(
            '--author',
            help='Author name',
        )
        p.add_argument(
            '--email',
            help='Author email',
        )
        p.add_argument(
            '--protocol',
            help='Protocol name for protocol generators (non-interactive mode)',
        )
        p.add_argument(
            '--platform',
            help='Target platform/OS name for platform generators',
        )
        p.add_argument(
            '--supported-platforms',
            help='Comma-separated supported platforms for protocol generators',
        )
        p.add_argument(
            '--os',
            type=lambda x: x.lower() in ('true', '1', 'yes'),
            default=False,
            help='Whether target uses OS/RTOS (True/False, default: False)',
        )
        p.add_argument(
            '--template-engine',
            choices=['jinja2', 'mako', 'none'],
            default='jinja2',
            help='Template engine to use (default: jinja2)',
        )
        p.add_argument(
            '--output-dir',
            '-o',
            help='Output directory for generator package (default: current directory)',
        )

    def add_update_generator_args(p):
        p.add_argument(
            '--path',
            required=True,
            help='Path to generator package directory',
        )
        p.add_argument(
            '--add-platforms',
            nargs='+',
            help='Platforms to add to supported_platforms (space and/or comma separated)',
        )
        p.add_argument(
            '--remove-platforms',
            nargs='+',
            help='Platforms to remove from supported_platforms (space and/or comma separated)',
        )
        p.add_argument(
            '--list-platforms',
            action='store_true',
            help='List currently supported platforms',
        )
        p.add_argument(
            '--name',
            help='Update generator name',
        )
        p.add_argument(
            '--description',
            help='Update generator description',
        )

    parser = argparse.ArgumentParser(
        prog='halo',
        description='HALO - command line interface',
        formatter_class=argparse.RawTextHelpFormatter,
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    compose_p = subparsers.add_parser('compose', help='Compose HALO model from HADL or UML XMI')
    add_compose_args(compose_p)

    generate_p = subparsers.add_parser('generate', help='Generate code from HALO model')
    add_generate_args(generate_p)
    
    create_gen_p = subparsers.add_parser('create-generator', help='Create a new HALO generator package')
    add_create_generator_args(create_gen_p)

    update_gen_p = subparsers.add_parser('update-generator', help='Update configuration of existing generator')
    add_update_generator_args(update_gen_p)

    args = parser.parse_args()
    if args.command == 'compose':
        # Delegate to the composer CLI implementation so packaged `halo` stays
        # in sync with all composer features.
        from composer.halo_composer import main as composer_main

        if getattr(args, 'from_xmi', None):
            if getattr(args, 'include_stdlib_profiles', False):
                compose_p.error('--include-stdlib-profiles is only supported with --hadls-root')

            argv = [
                'from-xmi',
                '--input',
                args.from_xmi,
                '--output-dir',
                args.output_dir,
            ]
            if getattr(args, 'user_types', None):
                argv.extend(['--user-types', args.user_types])
            return int(composer_main(argv))

        argv = [
            'from-hadl',
            '--hadls-root',
            args.hadls_root,
            '--output-dir',
            args.output_dir,
            '--log-level',
            args.log_level,
        ]
        if getattr(args, 'include_stdlib_profiles', False):
            argv.append('--include-stdlib-profiles')
        if getattr(args, 'user_types', None):
            argv.extend(['--user-types', args.user_types])
        return int(composer_main(argv))

    elif args.command == 'generate':
        return run_generator(args)
    
    elif args.command == 'create-generator':
        return run_create_generator(args)

    elif args.command == 'update-generator':
        return run_update_generator(args)

    # Should not reach here due to required=True
    parser.print_help()
    return 2


if __name__ == '__main__':
    raise SystemExit(main())
