import sys
from pathlib import Path


def _import_generator_scaffold():
    sw_dir = Path(__file__).resolve().parents[2]
    if str(sw_dir) not in sys.path:
        sys.path.insert(0, str(sw_dir))

    from generator.scaffold import GeneratorScaffold  # type: ignore

    return GeneratorScaffold


def test_protocol_scaffold_creates_crc_templates(tmp_path: Path):
    GeneratorScaffold = _import_generator_scaffold()
    scaffold = GeneratorScaffold(tmp_path)

    package_dir = scaffold.create_generator(
        name="demo_protocol",
        description="desc",
        author="dev",
        email="dev@example.com",
        target_platform="demo_protocol",
        supported_platforms=["linux"],
        generator_type="protocol",
    )

    templates_dir = package_dir / "src" / "halo_proto_demo_protocol" / "templates"
    crc_header = templates_dir / "demo_protocol_crc.h.j2"
    crc_impl = templates_dir / "demo_protocol_crc.c.j2"

    assert crc_header.exists()
    assert crc_impl.exists()
    assert '#include "halo_types.h"' in crc_header.read_text(encoding="utf-8")
    assert '#include "{{ protocol }}_crc.h"' in crc_impl.read_text(encoding="utf-8")
