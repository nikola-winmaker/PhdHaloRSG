import sys
import types
from pathlib import Path

import pytest


def _import_halo_main_module():
    """Import the halo CLI entrypoint from the source tree."""
    sw_dir = Path(__file__).resolve().parents[2]
    if str(sw_dir) not in sys.path:
        sys.path.insert(0, str(sw_dir))

    for mod in ("halo.__main__", "halo"):
        if mod in sys.modules:
            del sys.modules[mod]

    import halo.__main__ as halo_main  # type: ignore

    return halo_main


def _install_fake_generator_modules(
    monkeypatch: pytest.MonkeyPatch,
    *,
    available_platforms: list[str] | None = None,
) -> list[dict]:
    create_calls: list[dict] = []

    fake_generator_pkg = types.ModuleType("generator")
    fake_generator_pkg.__path__ = []  # type: ignore[attr-defined]

    fake_scaffold_mod = types.ModuleType("generator.scaffold")

    class FakeGeneratorScaffold:
        def __init__(self, _output_dir):
            self.output_dir = _output_dir

        def create_generator(self, **kwargs):
            create_calls.append(kwargs)

    fake_scaffold_mod.GeneratorScaffold = FakeGeneratorScaffold  # type: ignore[attr-defined]

    fake_questionnaire_mod = types.ModuleType("generator.questionnaire")

    class FakeGeneratorQuestionnaire:
        @staticmethod
        def get_available_platforms() -> list[str]:
            return list(available_platforms or [])

        @staticmethod
        def parse_supported_platforms(value: str, available: list[str]):
            requested = [item.strip().lower() for item in value.split(",") if item.strip()]
            unsupported = [item for item in requested if item not in set(available)]
            if unsupported:
                return False, f"Unsupported platforms: {', '.join(unsupported)}", []
            return True, "", requested

        def run(self):
            return {}

    fake_questionnaire_mod.GeneratorQuestionnaire = FakeGeneratorQuestionnaire  # type: ignore[attr-defined]

    monkeypatch.setitem(sys.modules, "generator", fake_generator_pkg)
    monkeypatch.setitem(sys.modules, "generator.scaffold", fake_scaffold_mod)
    monkeypatch.setitem(sys.modules, "generator.questionnaire", fake_questionnaire_mod)
    return create_calls


def test_create_generator_protocol_requires_protocol_flag(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
):
    halo_main = _import_halo_main_module()
    _install_fake_generator_modules(monkeypatch, available_platforms=["linux"])

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "halo",
            "create-generator",
            "--no-interactive",
            "--generator-type",
            "protocol",
            "--name",
            "my_protocol",
            "--description",
            "desc",
            "--author",
            "dev",
            "--email",
            "dev@example.com",
            "--supported-platforms",
            "linux",
        ],
    )

    assert halo_main.main() == 1
    out = capsys.readouterr().out
    assert "--protocol" in out


def test_create_generator_protocol_uses_protocol_flag(monkeypatch: pytest.MonkeyPatch):
    halo_main = _import_halo_main_module()
    create_calls = _install_fake_generator_modules(
        monkeypatch,
        available_platforms=["linux", "freertos"],
    )

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "halo",
            "create-generator",
            "--no-interactive",
            "--generator-type",
            "protocol",
            "--name",
            "my_protocol",
            "--description",
            "desc",
            "--author",
            "dev",
            "--email",
            "dev@example.com",
            "--protocol",
            "uart",
            "--supported-platforms",
            "linux,freertos",
        ],
    )

    assert halo_main.main() == 0
    assert len(create_calls) == 1
    assert create_calls[0]["target_platform"] == "uart"
    assert create_calls[0]["generator_type"] == "protocol"
    assert create_calls[0]["supported_platforms"] == ["linux", "freertos"]


def test_create_generator_protocol_allows_platform_flag_as_fallback(monkeypatch: pytest.MonkeyPatch):
    halo_main = _import_halo_main_module()
    create_calls = _install_fake_generator_modules(monkeypatch, available_platforms=["linux"])

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "halo",
            "create-generator",
            "--no-interactive",
            "--generator-type",
            "protocol",
            "--name",
            "my_protocol",
            "--description",
            "desc",
            "--author",
            "dev",
            "--email",
            "dev@example.com",
            "--platform",
            "legacy_proto_name",
            "--supported-platforms",
            "linux",
        ],
    )

    assert halo_main.main() == 0
    assert len(create_calls) == 1
    assert create_calls[0]["target_platform"] == "legacy_proto_name"
