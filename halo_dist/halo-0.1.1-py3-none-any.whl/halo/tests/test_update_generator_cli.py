import sys
import types
from pathlib import Path

import pytest


def _import_halo_main_module():
    """Import the halo CLI entrypoint from the source tree."""
    sw_dir = Path(__file__).resolve().parents[2]
    if str(sw_dir) not in sys.path:
        sys.path.insert(0, str(sw_dir))

    for mod in ("halo.__main__", "halo"):
        if mod in sys.modules:
            del sys.modules[mod]

    import halo.__main__ as halo_main  # type: ignore

    return halo_main


def test_update_generator_remove_platforms_accepts_space_and_comma_separated_tokens(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
):
    halo_main = _import_halo_main_module()

    remove_calls: list[list[str]] = []

    fake_generator_pkg = types.ModuleType("generator")
    fake_generator_pkg.__path__ = []  # type: ignore[attr-defined]

    fake_updater_mod = types.ModuleType("generator.updater")

    class FakeGeneratorConfigUpdater:
        def __init__(self, config_path: Path):
            self.config_path = config_path

        def get_platforms(self):
            return ["stm32", "linux", "freertos", "baremetal"]

        def add_platforms(self, _platforms: list[str]):
            return True

        def remove_platforms(self, platforms: list[str]):
            remove_calls.append(platforms)
            return True

        def update_attribute(self, _attribute_name: str, _new_value: str):
            return True

    fake_updater_mod.GeneratorConfigUpdater = FakeGeneratorConfigUpdater  # type: ignore[attr-defined]

    monkeypatch.setitem(sys.modules, "generator", fake_generator_pkg)
    monkeypatch.setitem(sys.modules, "generator.updater", fake_updater_mod)

    pkg_dir = tmp_path / "halo_proto_blackboard"
    config_dir = pkg_dir / "src" / "halo_proto_blackboard"
    config_dir.mkdir(parents=True)
    (config_dir / "config.py").write_text(
        "def get_protocol_config():\n"
        "    return {\"supported_platforms\": [\"stm32\", \"linux\", \"freertos\", \"baremetal\"]}\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "halo",
            "update-generator",
            "--path",
            str(pkg_dir),
            "--remove-platforms",
            "stm32,",
            "linux,",
            "freertos,",
            "baremetal",
        ],
    )

    assert halo_main.main() == 0
    assert remove_calls == [["stm32", "linux", "freertos", "baremetal"]]
