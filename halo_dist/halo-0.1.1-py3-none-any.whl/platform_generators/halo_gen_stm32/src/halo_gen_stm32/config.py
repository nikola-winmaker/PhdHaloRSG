"""Configuration for the Stm32 platform generator."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict


def get_generator_config() -> Dict[str, Any]:
    module_path = Path(__file__).parent / "render.py"
    return {
        "name": "stm32",
        "description": "HALO platform generator for stm32",
        "outputDir": "output/stm32",
        "template": None,
        "module": str(module_path),
        "options": {
            "os": False,
            "platform": "stm32",
            "template_engine": "jinja2",
        },
        "entry_point": "render_stm32",
    }