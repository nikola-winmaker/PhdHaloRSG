"""HALO platform generator for Linux."""

__version__ = "0.1.0"

from .render import render_linux

__all__ = ["render_linux"]