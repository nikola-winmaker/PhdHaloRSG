"""Configuration for the Linux platform generator."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict


def get_generator_config() -> Dict[str, Any]:
    module_path = Path(__file__).parent / "render.py"
    return {
        "name": "linux",
        "description": "HALO platform generator for linux",
        "outputDir": "output/linux",
        "template": None,
        "module": str(module_path),
        "options": {
            "os": True,
            "platform": "linux",
            "template_engine": "jinja2",
        },
        "entry_point": "render_linux",
    }