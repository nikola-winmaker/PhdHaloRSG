"""Configuration for Baremetal generator plugin."""
from pathlib import Path


def get_generator_config():
    """Return generator configuration for HALO discovery."""
    module_path = Path(__file__).parent / "render.py"
    
    return {
        "name": "baremetal",
        "description": "Built-in generator for baremetal targets",
        "outputDir": "output/baremetal",
        "template": None,  # Templates are bundled in main HALO package
        "module": str(module_path.resolve()),
        "options": {
            "os": False,
            "platform": "none"
        }
    }
