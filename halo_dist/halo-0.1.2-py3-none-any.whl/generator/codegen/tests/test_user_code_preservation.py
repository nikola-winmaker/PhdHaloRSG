from pathlib import Path
import sys


SW_DIR = Path(__file__).resolve().parents[3]
REPO_ROOT = Path(__file__).resolve().parents[4]
if str(SW_DIR) not in sys.path:
    sys.path.insert(0, str(SW_DIR))

from generator.codegen.render.render_utils import preserve_user_code_blocks, write_generated_file


def test_preserve_user_code_blocks_reuses_existing_named_sections():
    rendered = """\
alpha
/* HALO USER CODE BEGIN: demo.block */
new body
/* HALO USER CODE END: demo.block */
omega
"""
    existing = """\
alpha
/* HALO USER CODE BEGIN: demo.block */
old body
with two lines
/* HALO USER CODE END: demo.block */
omega
"""

    merged = preserve_user_code_blocks(rendered, existing)

    assert "old body\nwith two lines\n" in merged
    assert "new body" not in merged


def test_preserve_user_code_blocks_reuses_existing_unnamed_sections():
    rendered = """\
alpha
/* HALO USER CODE BEGIN */
new body
/* HALO USER CODE END */
omega
"""
    existing = """\
alpha
/* HALO USER CODE BEGIN */
old body
/* HALO USER CODE END */
omega
"""

    merged = preserve_user_code_blocks(rendered, existing)

    assert "old body\n" in merged
    assert "new body" not in merged


def test_preserve_user_code_blocks_keeps_user_inserted_block_without_template_slot():
    rendered = """\
alpha
beta
omega
"""
    existing = """\
alpha
/* HALO USER CODE BEGIN */
user custom code
/* HALO USER CODE END */
beta
omega
"""

    merged = preserve_user_code_blocks(rendered, existing)

    assert "user custom code" in merged
    assert merged.index("alpha") < merged.index("user custom code") < merged.index("beta")


def test_preserve_user_code_blocks_keeps_sharedmemory_freshness_block():
    template_path = (
        REPO_ROOT
        / "sw/protocol_generators/halo-proto-sharedmemory/src/halo_proto_sharedmemory/templates/sharedmemory_impl.c.j2"
    )
    rendered = template_path.read_text(encoding="utf-8")
    anchor = """\
    /* Copy payload to destination */
    halo_size_t copy_len = (header->size < len) ? header->size : len;
"""
    freshness_block = """\
    /* HALO USER CODE BEGIN: freshness */
    /* Strict freshness policy:
     * Track the last accepted sequence internally per channel and reject stale
     * or duplicate messages. The slot is still consumed below so read_idx keeps
     * progressing even when a duplicate/stale sample is dropped.
     */
    {
        sharedmemory_recv_state_t *recv_state = sharedmemory_get_recv_state(chan);
        if (recv_state != NULL) {
            if (!recv_state->initialized) {
                recv_state->last_sequence = header->sequence;
                recv_state->initialized = 1;
            } else if (header->sequence <= recv_state->last_sequence) {
                header->valid = 0;
                ctrl->read_idx = (ctrl->read_idx + 1) % ctrl->slot_count;
                sharedmemory_unlock(chan);
                return -1; /* Duplicate or stale message */
            } else {
                recv_state->last_sequence = header->sequence;
            }
        }
    }
    /* HALO USER CODE END: freshness */
"""
    existing = rendered.replace(anchor, anchor + freshness_block)

    merged = preserve_user_code_blocks(rendered, existing)

    assert "HALO USER CODE BEGIN: freshness" in merged
    assert "sharedmemory_get_recv_state(chan)" in merged
    assert merged.index("HALO USER CODE BEGIN: freshness") < merged.index("memcpy(dst, (const void *)payload, copy_len);")


def test_preserve_user_code_blocks_does_not_move_sharedmemory_freshness_to_init():
    rendered = """\
void sharedmemory_init(const sharedmemory_channel_t *chan) {
    if (!chan || !chan->base) {
        return;
    }

    /* Set up ring buffer control block */
    sharedmemory_ringbuf_ctrl_t *ctrl = (sharedmemory_ringbuf_ctrl_t *)chan->base;
}

int sharedmemory_recv(const sharedmemory_channel_t *chan, void *dst, halo_size_t len) {
    if (SHAREDMEMORY_CRC_TYPE != SHAREDMEMORY_CRC_NONE) {
        halo_u8_t *payload = (halo_u8_t *)(header + 1);
        halo_u32_t computed_crc = sharedmemory_calculate_crc(payload, header->size);
        if (computed_crc != header->crc_value) {
            sharedmemory_unlock(chan);
            return -1; /* CRC mismatch */
        }
    }

    /* Copy payload to destination */
    halo_size_t copy_len = (header->size < len) ? header->size : len;
}
"""
    existing = """\
void sharedmemory_init(const sharedmemory_channel_t *chan) {
    if (!chan || !chan->base) {
        return;
    }

    /* Set up ring buffer control block */
    sharedmemory_ringbuf_ctrl_t *ctrl = (sharedmemory_ringbuf_ctrl_t *)chan->base;
}

int sharedmemory_recv(const sharedmemory_channel_t *chan, void *dst, halo_size_t len) {
    if (SHAREDMEMORY_CRC_TYPE != SHAREDMEMORY_CRC_NONE) {
        halo_u8_t *payload = (halo_u8_t *)(header + 1);
        halo_u32_t computed_crc = sharedmemory_calculate_crc(payload, header->size);
        if (computed_crc != header->crc_value) {
            sharedmemory_unlock(chan);
            return -1; /* CRC mismatch */
        }
    }

    /* HALO USER CODE BEGIN: freshness */
    freshness logic
    /* HALO USER CODE END: freshness */

    /* Copy payload to destination */
    halo_size_t copy_len = (header->size < len) ? header->size : len;
}
"""

    merged = preserve_user_code_blocks(rendered, existing)

    freshness_pos = merged.index("HALO USER CODE BEGIN: freshness")
    init_ctrl_pos = merged.index("sharedmemory_ringbuf_ctrl_t *ctrl = (sharedmemory_ringbuf_ctrl_t *)chan->base;")
    recv_copy_pos = merged.index("/* Copy payload to destination */")
    assert init_ctrl_pos < freshness_pos < recv_copy_pos


def test_write_generated_file_preserves_user_code_between_writes(tmp_path):
    out_file = tmp_path / "generated.c"
    initial = """\
/* HALO USER CODE BEGIN: keep.me */
generated placeholder
/* HALO USER CODE END: keep.me */
"""
    write_generated_file(out_file, initial)

    out_file.write_text(
        """\
/* HALO USER CODE BEGIN: keep.me */
user custom code
/* HALO USER CODE END: keep.me */
""",
        encoding="utf-8",
    )

    write_generated_file(out_file, initial.replace("generated placeholder", "fresh placeholder"))
    merged = out_file.read_text(encoding="utf-8")

    assert "user custom code" in merged
    assert "fresh placeholder" not in merged


def test_scaffold_templates_include_user_code_markers():
    platform_template = REPO_ROOT / "sw/generator/scaffold/templates/platform/code_templates/platform_init.c.j2"
    protocol_template = REPO_ROOT / "sw/generator/scaffold/templates/protocol/templates/protocol_impl.c.j2"

    assert "HALO USER CODE BEGIN" in platform_template.read_text(encoding="utf-8")
    assert "HALO USER CODE BEGIN" in protocol_template.read_text(encoding="utf-8")
