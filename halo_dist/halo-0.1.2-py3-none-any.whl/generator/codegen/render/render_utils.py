
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict

from jinja2 import Environment


USER_CODE_BLOCK_RE = re.compile(
    r"(?P<begin>/\*\s*HALO USER CODE BEGIN(?:\s*:\s*(?P<name>[^\r\n*]+?))?\s*\*/)"
    r"(?P<body>.*?)"
    r"(?P<end>/\*\s*HALO USER CODE END(?:\s*:\s*(?P<end_name>[^\r\n*]+?))?\s*\*/)",
    re.DOTALL,
)


def _extract_user_blocks(content: str | None) -> list[dict[str, Any]]:
    if not content:
        return []

    blocks: list[dict[str, Any]] = []
    for index, match in enumerate(USER_CODE_BLOCK_RE.finditer(content)):
        name = (match.group("name") or "").strip() or None
        end_name = (match.group("end_name") or "").strip() or None
        if name != end_name:
            continue
        blocks.append(
            {
                "index": index,
                "name": name,
                "body": match.group("body"),
                "begin": match.group("begin"),
                "end": match.group("end"),
                "full": match.group(0),
                "start": match.start(),
                "end_pos": match.end(),
            }
        )
    return blocks


def _nonempty_lines_before(content: str, start: int, limit: int = 3) -> list[str]:
    before = content[:start].splitlines()
    lines: list[str] = []
    for line in reversed(before):
        if line.strip():
            lines.append(line)
            if len(lines) >= limit:
                break
    return lines


def _nonempty_lines_after(content: str, end: int, limit: int = 3) -> list[str]:
    after = content[end:].splitlines()
    lines: list[str] = []
    for line in after:
        if line.strip():
            lines.append(line)
            if len(lines) >= limit:
                break
    return lines


def _line_occurrences(content: str, line: str) -> list[int]:
    positions: list[int] = []
    search_from = 0
    while True:
        pos = content.find(line, search_from)
        if pos == -1:
            break
        positions.append(pos)
        search_from = pos + len(line)
    return positions


def _line_end_position(content: str, pos: int, line: str) -> int:
    insert_at = pos + len(line)
    if insert_at < len(content) and content[insert_at] == "\r":
        insert_at += 1
    if insert_at < len(content) and content[insert_at] == "\n":
        insert_at += 1
    return insert_at


def _insert_block_using_context(
    rendered: str,
    block_text: str,
    before_lines: list[str],
    after_lines: list[str],
) -> str:
    best_insert_at: int | None = None
    best_gap: int | None = None

    for before in before_lines:
        before_positions = _line_occurrences(rendered, before)
        if not before_positions:
            continue
        for after in after_lines:
            after_positions = _line_occurrences(rendered, after)
            if not after_positions:
                continue
            for before_pos in before_positions:
                before_end = _line_end_position(rendered, before_pos, before)
                for after_pos in after_positions:
                    if after_pos < before_end:
                        continue
                    gap = after_pos - before_end
                    if best_gap is None or gap < best_gap:
                        best_gap = gap
                        best_insert_at = before_end
                    break

    if best_insert_at is None:
        for before in before_lines:
            before_pos = rendered.rfind(before)
            if before_pos != -1:
                best_insert_at = _line_end_position(rendered, before_pos, before)
                break

    if best_insert_at is None:
        for after in after_lines:
            after_pos = rendered.find(after)
            if after_pos != -1:
                best_insert_at = after_pos
                break

    if best_insert_at is None:
        if rendered and not rendered.endswith("\n"):
            rendered += "\n"
        return f"{rendered}{block_text}\n"

    return f"{rendered[:best_insert_at]}{block_text}\n{rendered[best_insert_at:]}"


def preserve_user_code_blocks(rendered: str, existing: str | None) -> str:
    """Merge HALO user-code blocks from an existing file into new output."""
    if not existing:
        return rendered

    existing_blocks = _extract_user_blocks(existing)
    if not existing_blocks:
        return rendered

    named_existing = {block["name"]: block["body"] for block in existing_blocks if block["name"]}
    unnamed_existing = [block["body"] for block in existing_blocks if not block["name"]]
    unnamed_index = 0
    matched_existing_ids: set[tuple[str, Any]] = set()

    def _replace(match: re.Match[str]) -> str:
        nonlocal unnamed_index

        name = (match.group("name") or "").strip() or None
        end_name = (match.group("end_name") or "").strip() or None
        if name != end_name:
            return match.group(0)

        if name:
            body = named_existing.get(name)
            if body is None:
                return match.group(0)
            matched_existing_ids.add(("named", name))
            return f"{match.group('begin')}{body}{match.group('end')}"

        if unnamed_index >= len(unnamed_existing):
            return match.group(0)

        body = unnamed_existing[unnamed_index]
        matched_existing_ids.add(("unnamed", unnamed_index))
        unnamed_index += 1
        return f"{match.group('begin')}{body}{match.group('end')}"

    merged = USER_CODE_BLOCK_RE.sub(_replace, rendered)

    for block in existing_blocks:
        block_id = ("named", block["name"]) if block["name"] else ("unnamed", block["index"])
        if block_id in matched_existing_ids:
            continue

        before_lines = _nonempty_lines_before(existing, block["start"])
        after_lines = _nonempty_lines_after(existing, block["end_pos"])
        merged = _insert_block_using_context(merged, block["full"], before_lines, after_lines)

    return merged


def write_generated_file(out_path: Path, rendered: str) -> None:
    existing = None
    if out_path.exists():
        existing = out_path.read_text(encoding="utf-8")
    out_path.write_text(preserve_user_code_blocks(rendered, existing), encoding="utf-8")


def _render_to_file(env: Environment, template_name: str, ctx: Dict[str, Any], out_path: Path) -> None:
    tpl = env.get_template(template_name)
    write_generated_file(out_path, tpl.render(**ctx))


def _default_type_map() -> Dict[str, str]:
    # Keep this tiny and predictable; user-types can be integrated later.
    return {
        "bool": "halo_u8_t",
        "byte": "halo_u8_t",
        "int": "halo_i32_t",
        "string": "halo_string_t",
        "integer": "halo_i32_t",
        "float": "halo_f32_t",
        "double": "halo_f64_t",
        "unsigned int": "halo_u32_t",
        "unsignedint": "halo_u32_t",
        "uint32": "halo_u32_t",
        "int32": "halo_i32_t",
        "uint64": "halo_u64_t",
    }


def _c_ident(value: Any) -> str:
    """Convert an arbitrary string into a safe C identifier."""

    s = str(value or "")
    out = []
    for ch in s:
        if ch.isalnum() or ch == "_":
            out.append(ch)
        else:
            out.append("_")
    ident = "".join(out) or "x"
    if ident[0].isdigit():
        ident = f"x_{ident}"
    return ident


def _crc_ret_type(crc_name: Any) -> str:
    t = str(crc_name or "").strip().lower()
    if t == "crc16":
        return "uint16_t"
    if t == "crc32":
        return "uint32_t"
    return "uint32_t"


def _size_bytes(value: Any) -> int:
    """Parse human-readable sizes like '64MB', '1kB', '128B', '0B' into bytes.

    Uses IEC-style multipliers (kB=1024, MB=1024^2, GB=1024^3). If parsing
    fails, returns 0 to keep generation robust.
    """

    if value is None:
        return 0
    if isinstance(value, (int, float)):
        return int(value)

    s = str(value).strip()
    if not s:
        return 0

    # allow plain integers
    try:
        return int(s, 10)
    except ValueError:
        pass

    s_norm = "".join(ch for ch in s if not ch.isspace()).lower()

    multipliers = {
        "b": 1,
        "kb": 1024,
        "k": 1024,
        "mb": 1024 * 1024,
        "m": 1024 * 1024,
        "gb": 1024 * 1024 * 1024,
        "g": 1024 * 1024 * 1024,
    }

    # split numeric prefix + unit suffix
    i = 0
    while i < len(s_norm) and (s_norm[i].isdigit() or s_norm[i] == "."):
        i += 1
    num_part = s_norm[:i]
    unit_part = s_norm[i:]
    if not num_part:
        return 0
    try:
        number = float(num_part)
    except ValueError:
        return 0
    multiplier = multipliers.get(unit_part)
    if multiplier is None:
        return 0
    return int(number * multiplier)


def _maybe_size_bytes(value: Any) -> int | None:
    """Parse a *size-like* string into bytes, else return None.

    This is used by cfg generation so we don't need hardcoded key lists.
    Only strings with an explicit unit are treated as sizes (e.g. '128B',
    '64MB', '1kB'). Plain numeric strings like '123' are NOT sizes.
    """

    if value is None:
        return None
    if isinstance(value, (int, float, bool)):
        return None

    s = str(value).strip()
    if not s:
        return None

    s_norm = "".join(ch for ch in s if not ch.isspace()).lower()

    multipliers = {
        "b": 1,
        "kb": 1024,
        "k": 1024,
        "mb": 1024 * 1024,
        "m": 1024 * 1024,
        "gb": 1024 * 1024 * 1024,
        "g": 1024 * 1024 * 1024,
    }

    i = 0
    while i < len(s_norm) and (s_norm[i].isdigit() or s_norm[i] == "."):
        i += 1

    num_part = s_norm[:i]
    unit_part = s_norm[i:]

    if not num_part or not unit_part:
        return None
    if unit_part not in multipliers:
        return None

    try:
        number = float(num_part)
    except ValueError:
        return None
    return int(number * multipliers[unit_part])


def _get_type_size(type_name: str) -> int:
    """Get the size in bytes for a HALO type name.
    
    Args:
        type_name: Type name (byte, integer, short, long, etc.)
        
    Returns:
        Size in bytes, defaults to 4 if unknown
    """
    type_sizes = {
        "bool": 1,
        "byte": 1,
        "string": 1,
        "short": 2,
        "int": 4,
        "integer": 4,
        "float": 4,
        "double": 8,
        "int32": 4,
        "unsigned int": 4,
        "unsignedint": 4,
        "uint32": 4,
        "long": 8,
        "uint64": 8,
        "int64": 8,
    }
    return type_sizes.get(type_name.lower(), 4)


def _calculate_struct_size(fields: list) -> int:
    """Calculate the size of a structure from its field definitions.
    
    Args:
        fields: List of field dicts with 'type' and optional 'array' keys
        
    Returns:
        Total size in bytes
    """
    if not fields:
        return 0
    
    total_size = 0
    for field in fields:
        ftype = field.get("type", "")
        arr = field.get("array")
        
        field_size = _get_type_size(ftype)
        
        # Handle arrays
        if arr and isinstance(arr, dict):
            array_size = arr.get("size", 1)
            field_size *= array_size
        
        total_size += field_size
    
    return total_size


def _is_protocol_generator_available(protocol_type: str) -> bool:
    """Check if a protocol generator is available (Jinja2 filter).
    
    Args:
        protocol_type: Protocol type to check (e.g., "sharedmemory", "eventchannel")
        
    Returns:
        True if generator is available, False otherwise
    """
    try:
        from ..utils.protocol_helpers import is_protocol_generator_available
    except ImportError:
        from generator.codegen.utils.protocol_helpers import is_protocol_generator_available
    
    return is_protocol_generator_available(protocol_type)


def _looks_like_hex(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    s = value.strip().lower()
    if not s.startswith("0x"):
        return False
    if len(s) <= 2:
        return False
    try:
        int(s, 16)
        return True
    except ValueError:
        return False


def _looks_like_uint(value: Any) -> bool:
    """True for strings representing an unsigned integer (decimal or 0x...)."""

    if not isinstance(value, str):
        return False
    s = value.strip().lower()
    if not s:
        return False
    if s.startswith("0x"):
        return _looks_like_hex(value)
    return s.isdigit()


def _infer_enum_domain(enums: Any, value: Any) -> str | None:
    """Infer enum domain name for a literal value.

    Returns the enum domain (key in enums dict) if and only if the literal
    matches exactly one domain. Returns None for no matches or ambiguous
    literals (e.g. 'None' appearing in multiple enums).
    """

    if not isinstance(value, str):
        return None
    lit = value.strip()
    if not lit:
        return None

    # Avoid accidental enum-typing of boolean-like strings.
    if lit.lower() in ("true", "false"):
        return None

    if not isinstance(enums, dict):
        return None

    matches: list[str] = []
    for domain_name, literals in enums.items():
        try:
            if lit in list(literals):
                matches.append(str(domain_name))
        except Exception:
            continue

    if len(matches) == 1:
        return matches[0]
    return None


def _c_uint(value: Any) -> str:
    """Format an integer or hex-string as a C unsigned integer literal."""

    if value is None:
        return "0U"
    if isinstance(value, bool):
        return "1U" if value else "0U"
    if isinstance(value, int):
        return f"{value}U"

    s = str(value).strip()
    if not s:
        return "0U"
    s_norm = s.lower()
    try:
        if s_norm.startswith("0x"):
            n = int(s_norm, 16)
            # use ULL for addresses / large constants
            return f"0x{n:X}ULL"
        n = int(s_norm, 10)
        return f"{n}U"
    except ValueError:
        return "0U"


def _c_str(value: Any) -> str:
    """Format a value as a C string literal (double-quoted), escaping as needed."""

    if value is None:
        return '""'
    s = str(value)
    s = s.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{s}"'

def _str_lower(value: Any) -> str:
    """Convert a value to a lowercase string."""
    if value is None:
        return ""
    return str(value).lower()
