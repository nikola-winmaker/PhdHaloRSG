"""Configuration for the Sharedmemory protocol generator."""
from pathlib import Path


def get_protocol_config():
    """Return protocol generator configuration for HALO discovery."""
    module_dir = Path(__file__).parent
    render_module = module_dir / "render.py"

    return {
        "name": "sharedmemory",
        "supported_platforms": ["baremetal", "freertos", "linux", "stm32", "zephyr"],
        "module": str(render_module),
        "description": "HALO protocol generator for SharedMemory",
    }