"""Configuration for FreeRTOS generator plugin."""
from pathlib import Path


def get_generator_config():
    """Return generator configuration for HALO discovery."""
    module_path = Path(__file__).parent / "render.py"
    
    return {
        "name": "freertos",
        "description": "Built-in generator for FreeRTOS targets",
        "outputDir": "output/freertos",
        "template": None,  # Templates are bundled in main HALO package
        "module": str(module_path.resolve()),
        "options": {
            "os": True,
            "platform": "freertos"
        }
    }
