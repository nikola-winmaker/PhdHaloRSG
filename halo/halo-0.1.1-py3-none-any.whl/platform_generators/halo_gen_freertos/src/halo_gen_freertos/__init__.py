"""HALO Built-in Generator for FreeRTOS targets."""

__version__ = "0.1.0"
