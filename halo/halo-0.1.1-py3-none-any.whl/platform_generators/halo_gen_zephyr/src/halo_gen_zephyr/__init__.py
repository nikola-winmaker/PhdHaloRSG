"""HALO Built-in Generator for Zephyr RTOS targets."""

__version__ = "0.1.0"
