"""Configuration for Zephyr generator plugin."""
from pathlib import Path


def get_generator_config():
    """Return generator configuration for HALO discovery."""
    module_path = Path(__file__).parent / "render.py"
    
    return {
        "name": "zephyr",
        "description": "Built-in generator for Zephyr RTOS targets",
        "outputDir": "output/zephyr",
        "template": None,  # Templates are bundled in main HALO package
        "module": str(module_path.resolve()),
        "options": {
            "os": True,
            "platform": "zephyr"
        }
    }
