"""HALO Built-in Generator for Baremetal targets."""

__version__ = "0.1.0"
