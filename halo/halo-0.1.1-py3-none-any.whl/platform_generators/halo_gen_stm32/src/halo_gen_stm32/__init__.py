"""HALO platform generator for Stm32."""

__version__ = "0.1.0"

from .render import render_stm32

__all__ = ["render_stm32"]