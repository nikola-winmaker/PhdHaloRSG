import json
import logging
import shutil
import sys
from pathlib import Path

import pytest


def _import_halo_composer_module():
	"""Import the halo_composer module.

	Works both when running from source tree and when installed as a package.
	"""
	# Prefer the in-repo implementation (HALO/sw) over any installed package.
	sw_dir = Path(__file__).resolve().parents[2]
	if str(sw_dir) not in sys.path:
		sys.path.insert(0, str(sw_dir))
	# If an installed package was imported earlier in the session, drop it so we
	# re-import from the source tree.
	for mod in ("composer.halo_composer", "composer"):
		if mod in sys.modules:
			del sys.modules[mod]
	try:
		import composer.halo_composer as halo_composer  # type: ignore
		return halo_composer
	except ImportError:
		composer_dir = Path(__file__).resolve().parents[1]
		if str(composer_dir) not in sys.path:
			sys.path.insert(0, str(composer_dir))
		import halo_composer  # type: ignore
		return halo_composer


def _copy_hadl_fixtures(src_root: Path, dst_root: Path) -> None:
	for p in src_root.iterdir():
		if p.is_file():
			shutil.copy2(p, dst_root / p.name)


def test_compose_from_hadl_accepts_user_types():
	halo_composer = _import_halo_composer_module()

	tests_dir = Path(__file__).resolve().parent
	composer_dir = tests_dir.parent
	fixtures_root = composer_dir / "dsl" / "hadls"
	assert fixtures_root.exists(), f"Missing HADL fixtures folder: {fixtures_root}"

	# Use a repo-local output folder for easy inspection.
	work_root = tests_dir / "out" / "user_types_integration"
	if work_root.exists():
		shutil.rmtree(work_root)
	work_root.mkdir(parents=True, exist_ok=True)

	hadls_root = work_root / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)
	_copy_hadl_fixtures(fixtures_root, hadls_root)
	assert (hadls_root / "halo_interface1.idl").exists()
	assert (hadls_root / "halo_interface2.idl").exists()
	assert any(hadls_root.glob("*.hml")), "Expected at least one .hml fixture"

	adl_path = hadls_root / "halo_test_system.adl"
	assert adl_path.exists(), f"Missing ADL fixture: {adl_path}"

	# Introduce new literals (invalid without custom enums).
	text = adl_path.read_text(encoding="utf-8")
	# Patch two occurrences so we exercise multiple custom values.
	text = text.replace("Type: Application", "Type: MyType", 1)
	text = text.replace("Type: Application", "Type: MyType2", 1)
	text = text.replace("Platform: FreeRTOS", "Platform: MyPlatform", 1)
	text = text.replace("Platform: Zephyr", "Platform: MyPlatform2", 1)
	text = text.replace("Function: RealTimeProcessing", "Function: MyFunction", 1)
	text = text.replace("Function: RealTimeProcessing", "Function: MyFunction2", 1)
	adl_path.write_text(text, encoding="utf-8")

	out_dir_fail = work_root / "out_fail"
	out_dir_ok = work_root / "out_ok"
	out_dir_ok.mkdir(parents=True, exist_ok=True)

	# Should fail semantic validation with defaults only.
	# Use CRITICAL to avoid noisy expected ERROR logs during -s runs.
	rc_fail = halo_composer._compose_from_hadl(str(hadls_root), str(out_dir_fail), logging.CRITICAL)
	assert rc_fail != 0

	user_types = {
		"componentType": ["MyType", "MyType2"],
		"componentPlatform": ["MyPlatform", "MyPlatform2"],
		"componentFunction": ["MyFunction", "MyFunction2"],
	}
	user_types_path = work_root / "user_types.json"
	user_types_path.write_text(json.dumps(user_types), encoding="utf-8")

	# Write a copy next to outputs for easy inspection.
	(out_dir_ok / "halo_user_types.json").write_text(
		json.dumps(user_types, indent=2, sort_keys=True),
		encoding="utf-8",
	)

	# Should pass when custom enums are provided.
	rc_ok = halo_composer._compose_from_hadl(
		str(hadls_root),
		str(out_dir_ok),
		logging.ERROR,
		user_types_path=str(user_types_path),
	)
	assert rc_ok == 0
	assert (out_dir_ok / "halo_user_types.json").exists()

	out_json = out_dir_ok / "halo_unified_model.json"
	assert out_json.exists(), f"Missing output: {out_json}"

	model = json.loads(out_json.read_text(encoding="utf-8"))
	components = model.get("components", [])
	assert any(c.get("type") == "MyType" for c in components)
	assert any(c.get("type") == "MyType2" for c in components)
	assert any(c.get("platform") == "MyPlatform" for c in components)
	assert any(c.get("platform") == "MyPlatform2" for c in components)
	assert any(c.get("function") == "MyFunction" for c in components)
	assert any(c.get("function") == "MyFunction2" for c in components)


def test_generate_xmi_with_user_types_then_import_xmi_with_user_types():
	halo_composer = _import_halo_composer_module()

	tests_dir = Path(__file__).resolve().parent
	composer_dir = tests_dir.parent
	fixtures_root = composer_dir / "dsl" / "hadls"
	assert fixtures_root.exists(), f"Missing HADL fixtures folder: {fixtures_root}"

	work_root = tests_dir / "out" / "user_types_roundtrip_xmi"
	if work_root.exists():
		shutil.rmtree(work_root)
	work_root.mkdir(parents=True, exist_ok=True)

	# Stage a private copy of HADL fixtures so we can patch values.
	hadls_root = work_root / "hadls"
	hadls_root.mkdir(parents=True, exist_ok=True)
	_copy_hadl_fixtures(fixtures_root, hadls_root)

	adl_path = hadls_root / "halo_test_system.adl"
	assert adl_path.exists(), f"Missing ADL fixture: {adl_path}"

	# Patch two occurrences so we exercise multiple custom values.
	text = adl_path.read_text(encoding="utf-8")
	text = text.replace("Type: Application", "Type: MyType", 1)
	text = text.replace("Type: Application", "Type: MyType2", 1)
	text = text.replace("Platform: FreeRTOS", "Platform: MyPlatform", 1)
	text = text.replace("Platform: Zephyr", "Platform: MyPlatform2", 1)
	text = text.replace("Function: RealTimeProcessing", "Function: MyFunction", 1)
	text = text.replace("Function: RealTimeProcessing", "Function: MyFunction2", 1)
	adl_path.write_text(text, encoding="utf-8")

	user_types = {
		"componentType": ["MyType", "MyType2"],
		"componentPlatform": ["MyPlatform", "MyPlatform2"],
		"componentFunction": ["MyFunction", "MyFunction2"],
	}
	user_types_path = work_root / "user_types.json"
	user_types_path.write_text(json.dumps(user_types), encoding="utf-8")

	# 1) Compose from HADL (this also generates uml/halo_model.uml).
	hadl_out = work_root / "hadl_out"
	hadl_out.mkdir(parents=True, exist_ok=True)
	rc_hadl = halo_composer._compose_from_hadl(
		str(hadls_root),
		str(hadl_out),
		logging.ERROR,
		user_types_path=str(user_types_path),
	)
	assert rc_hadl == 0

	generated_xmi = hadl_out / "uml" / "halo_model.uml"
	assert generated_xmi.exists(), f"Missing generated XMI: {generated_xmi}"

	# 2) Import that generated XMI back into a unified model, with the same user types.
	xmi_out = work_root / "xmi_out"
	xmi_out.mkdir(parents=True, exist_ok=True)
	rc_xmi = halo_composer._compose_from_xmi(
		str(generated_xmi),
		str(xmi_out),
		user_types_path=str(user_types_path),
	)
	assert rc_xmi == 0
	assert (xmi_out / "halo_unified_model.json").exists()
	assert (xmi_out / "halo_user_types.json").exists()

	model = json.loads((xmi_out / "halo_unified_model.json").read_text(encoding="utf-8"))
	components = model.get("components", [])
	assert any(c.get("type") == "MyType" for c in components)
	assert any(c.get("type") == "MyType2" for c in components)
	assert any(c.get("platform") == "MyPlatform" for c in components)
	assert any(c.get("platform") == "MyPlatform2" for c in components)
	assert any(c.get("function") == "MyFunction" for c in components)
	assert any(c.get("function") == "MyFunction2" for c in components)

	# 2b) Import the same XMI WITHOUT providing user_types_path.
	#     The importer should auto-detect custom component type/platform/function
	#     and emit a halo_user_types.json for reproducibility.
	xmi_out_auto = work_root / "xmi_out_auto"
	xmi_out_auto.mkdir(parents=True, exist_ok=True)
	rc_xmi_auto = halo_composer._compose_from_xmi(
		str(generated_xmi),
		str(xmi_out_auto),
	)
	assert rc_xmi_auto == 0
	assert (xmi_out_auto / "halo_unified_model.json").exists()
	assert (xmi_out_auto / "halo_user_types.json").exists()

	auto_user_types = json.loads((xmi_out_auto / "halo_user_types.json").read_text(encoding="utf-8"))
	assert "MyType" in auto_user_types.get("componentType", [])
	assert "MyType2" in auto_user_types.get("componentType", [])
	assert "MyPlatform" in auto_user_types.get("componentPlatform", [])
	assert "MyPlatform2" in auto_user_types.get("componentPlatform", [])
	assert "MyFunction" in auto_user_types.get("componentFunction", [])
	assert "MyFunction2" in auto_user_types.get("componentFunction", [])

	# 3) The XMI importer also exports HADL. Ensure it writes user_types.json into
	#    the HADL folder so the round-trip can be reproduced without passing
	#    --user-types explicitly.
	xmi_hadl_root = xmi_out / "hadl"
	assert xmi_hadl_root.exists(), f"Missing HADL export dir: {xmi_hadl_root}"
	assert (xmi_hadl_root / "user_types.json").exists(), "Expected user_types.json in HADL export"

	xmi_hadl_root_auto = xmi_out_auto / "hadl"
	assert xmi_hadl_root_auto.exists(), f"Missing HADL export dir: {xmi_hadl_root_auto}"
	assert (xmi_hadl_root_auto / "user_types.json").exists(), "Expected user_types.json in HADL export"

	# 4) Compose from the exported HADL WITHOUT passing user_types_path.
	#    This should succeed due to auto-discovery of user_types.json.
	auto_hadl_out = work_root / "auto_hadl_out"
	auto_hadl_out.mkdir(parents=True, exist_ok=True)
	rc_auto = halo_composer._compose_from_hadl(str(xmi_hadl_root), str(auto_hadl_out), logging.ERROR)
	assert rc_auto == 0
