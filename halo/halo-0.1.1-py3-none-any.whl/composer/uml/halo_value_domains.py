"""Shared HALO value-domain helpers.

Single source of truth for:
- default enumerations (HALO semantic domains)
- field->enum mapping
- scalar type mapping
- address parsing/typing rules

Used by:
- HALO Composer semantic validation
- HALO -> UML IR conversion

Keep changes here minimal and intentional: callers rely on stable names.
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


# NOTE: Keep in sync with historical values in uml/halo_to_uml.py.
DEFAULT_HALO_ENUMS: Dict[str, List[str]] = {
    # Component metadata
    "componentType": ["Application", "Acceleration"],
    "componentPlatform": ["Linux", "FreeRTOS", "Zephyr", "BareMetal", "FPGA"],
    "componentFunction": ["RealTimeProcessing", "GeneralProcessing", "OffloadProcessing"],

    # Memory-mapped/shared-memory profile domains
    "memPolicyEnumeration": ["WriteBack", "WriteThrough", "NonCacheable", "None"],
    "memCoherence": ["Software", "Hardware", "None"],
    "SynchronizationTypes": ["AcquireRelease", "FullFence", "None"],
    "memPermissions": ["R", "W", "RW"],
    "PriorityTypes": ["Low", "Medium", "High", "Critical"],

    # Other value domains
    "SynchronizationPrimitive": ["mutex", "semaphore", "None"],
    "SynchronizationBlocking": ["True", "False"],
    "StreamTypes": ["single", "burst", "continuous"],
    # Custom profile types are auto-detected from HML
    "profileType": ["SharedMemory", "MemoryMappedIO", "DMA", "ShmemFast"],
    "TransferEndpoint": ["deviceToMemory", "memoryToDevice", "memoryToMemory"],
    "errorType": ["Interrupt", "Callback", "None"],
}


# Field-name -> enum domain mapping (used across HADL validation and UML export)
COMPONENT_KEY_TO_ENUM: Dict[str, str] = {
    "type": "componentType",
    "platform": "componentPlatform",
    "function": "componentFunction",
}


PROFILE_KEY_TO_ENUM: Dict[str, str] = {
    "policy": "memPolicyEnumeration",
    "coherence": "memCoherence",
    "barriers": "SynchronizationTypes",
    "permissions": "memPermissions",
    "priority": "PriorityTypes",

    # Alternate key spellings
    "syncType": "SynchronizationTypes",
    "syncPrimitive": "SynchronizationPrimitive",
    "syncBlocking": "SynchronizationBlocking",

    # Other profiles
    "primitive": "SynchronizationPrimitive",
    "blocking": "SynchronizationBlocking",
    "stream": "StreamTypes",
    # 'type' can be profile kind (SharedMemory/DMA/MemoryMappedIO/...) or stream mode (DMA).
    # Validation handles this specially; keep mapping empty here to avoid false positives.
    "transfer": "TransferEndpoint",
    "endpoint": "TransferEndpoint",
    "errorHandling": "errorType",
    # Some profiles use 'error' directly (e.g., DMA profiles in unified_model.json)
    "error": "errorType",
}


def is_address_field(attr_name: str) -> bool:
    return bool(attr_name) and (
        attr_name in ("address", "baseAddress", "addr", "src", "dst")
        or attr_name.endswith("Address")
    )


def merge_enums(
    base: Dict[str, Sequence[str]],
    custom: Optional[Dict[str, Sequence[str]]] = None,
) -> Dict[str, List[str]]:
    """Merge custom enums into base, preserving order and de-duplicating."""
    merged: Dict[str, List[str]] = {k: list(v) for k, v in base.items()}
    if not custom:
        return merged

    for enum_name, literals in custom.items():
        if enum_name not in merged:
            merged[enum_name] = list(literals)
            continue
        seen = set(merged[enum_name])
        for lit in literals:
            if lit not in seen:
                merged[enum_name].append(lit)
                seen.add(lit)
    return merged


def normalize_user_types(user_types: Optional[Dict[str, Any]]) -> Dict[str, List[str]]:
    """Normalize user-provided value-domain definitions.

    Accepts a dict mapping domain_name -> iterable of literals (or a single literal).
    Returns a dict[str, list[str]] with whitespace-trimmed literals and empties removed.
    """
    if not user_types:
        return {}
    if not isinstance(user_types, dict):
        raise TypeError(f"user_types must be a dict, got {type(user_types).__name__}")

    out: Dict[str, List[str]] = {}
    for domain_name, raw in user_types.items():
        if domain_name is None:
            continue
        name = str(domain_name).strip()
        if not name:
            continue

        values: List[str] = []
        if isinstance(raw, (list, tuple, set)):
            it = raw
        elif raw is None:
            it = []
        else:
            it = [raw]

        for v in it:
            if v is None:
                continue
            s = str(v).strip()
            if s:
                values.append(s)
        if values:
            out[name] = values
    return out


def load_user_types_from_json(path: str) -> Dict[str, List[str]]:
    """Load user-defined value domains from a JSON file.

    Expected schema:
        {
          "componentType": ["Application", "Acceleration", "MyNewType"],
          "componentPlatform": ["Linux", "MyNewPlatform"],
          "componentFunction": ["RealTimeProcessing", "MyNewFunction"]
        }
    """
    if not path:
        return {}
    p = os.path.abspath(os.path.expanduser(path))
    # Use utf-8-sig to tolerate a UTF-8 BOM (common on Windows PowerShell output).
    with open(p, "r", encoding="utf-8-sig") as f:
        data = json.load(f)
    return normalize_user_types(data)


def enum_literals_by_name(enums: Dict[str, Sequence[str]]) -> Dict[str, set[str]]:
    return {name: {str(x) for x in literals} for name, literals in enums.items()}


def enum_names_by_literal(enums: Dict[str, Sequence[str]]) -> Dict[str, set[str]]:
    out: Dict[str, set[str]] = {}
    for enum_name, literals in enums.items():
        for lit in literals:
            out.setdefault(str(lit), set()).add(enum_name)
    return out


def map_scalar_type(value: Any) -> str:
    if isinstance(value, bool):
        return "Boolean"
    if isinstance(value, int) and not isinstance(value, bool):
        return "Integer"
    if isinstance(value, float):
        return "Real"
    if isinstance(value, str):
        return "String"
    return type(value).__name__


def enum_type_for_field(field_name: str, value: Any, literals_by_name: Dict[str, set[str]]) -> Optional[str]:
    """Return enum name if this (field,value) should be typed to an enum."""
    if not isinstance(value, str):
        return None
    v = value.strip()

    enum_name = COMPONENT_KEY_TO_ENUM.get(field_name)
    if enum_name and v in literals_by_name.get(enum_name, set()):
        return enum_name

    enum_name = PROFILE_KEY_TO_ENUM.get(field_name)
    if enum_name and v in literals_by_name.get(enum_name, set()):
        return enum_name
    return None


def enum_type_for_value(value: Any, names_by_literal: Dict[str, set[str]]) -> Optional[str]:
    """If a string value matches at least one literal across all enums, return a deterministic enum name."""
    if not isinstance(value, str):
        return None
    v = value.strip()
    if not v:
        return None
    matches = names_by_literal.get(v)
    if not matches:
        return None
    # Deterministic choice for ambiguous literals (e.g., 'None').
    return sorted(matches)[0]


def address_type_and_value(attr_name: str, val: Any):
    """Return (type_name, normalized_value) for address-like attributes, else None.

    Rules:
    - Any string like 0x... becomes type Hex, value kept as string.
    - Decimal strings become unsignedint + int(val)
    - Ints become unsignedint

    Address-like names: address/baseAddress/addr/src/dst/*Address
    """
    if isinstance(val, str):
        s = val.strip()
        if s.lower().startswith("0x"):
            return "Hex", s

    if not attr_name:
        return None

    if not is_address_field(attr_name):
        return None

    if isinstance(val, str):
        s = val.strip()
        if s.isdigit():
            return "unsignedint", int(s)
        return None
    if isinstance(val, int) and not isinstance(val, bool):
        return "unsignedint", val
    return None
