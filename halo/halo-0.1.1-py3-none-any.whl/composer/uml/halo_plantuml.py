import os
import re
from sys import prefix
from typing import Any, Dict, List, Optional


def _sanitize(name: str) -> str:
	return re.sub(r"[^0-9A-Za-z_]+", "_", str(name))


def _puml_header(title: str) -> str:
	return (
		"@startuml\n"
		"allowmixing\n"
		"!pragma layout smetana\n\n"
		"skinparam component {\n"
		"    BackgroundColor #EAEAEA\n"
		"    BorderColor black\n"
		"    ArrowColor black\n"
		"    FontColor black\n"
		"    ArrowThickness 1.5\n"
		"    FontSize 14\n"
		"}\n\n"
		f"title \"{title}\"\n\n"
	)


def _puml_footer() -> str:
	return "\n@enduml\n"


class HALOPlantUMLGenerator:
	"""Generate PlantUML diagrams from the HALO unified model and parsed IDL/HML."""

	def __init__(
		self,
		unified_model: Dict[str, Any],
		idl_models: Optional[List[Any]] = None,
		profile_models: Optional[List[Any]] = None,
	) -> None:
		self.unified_model = unified_model or {"components": [], "connections": []}
		self.idl_models = idl_models or []
		self.profile_models = profile_models or []

	def render_architecture(self) -> str:
		"""Class/component diagram of components and interfaces with connections."""
		lines: List[str] = [
			_puml_header("HALO Architecture - Components and Interfaces"),
			"skinparam componentStyle uml2\n",
		]

		# Components
		comp_names = set()
		for comp in self.unified_model.get("components", []):
			name = getattr(comp, "name", None) or comp.get("name")
			ctype = getattr(comp, "type", None) or comp.get("type")
			platformval = getattr(comp, "platform", None) or comp.get("platform")
			func = getattr(comp, "function", None) or comp.get("function")
			if not name:
				continue
			comp_names.add(name)
			stereotypes = "".join(
				f"<<{s}>>" for s in [ctype, platformval, func] if s
			)
			lines.append(f"component \"{name}\" {stereotypes}")

		# Interfaces
		iface_alias_by_name: Dict[str, str] = {}
		def get_iface_name(conn_iface: Any) -> Optional[str]:
			if conn_iface is None:
				return None
			if hasattr(conn_iface, "name"):
				return getattr(conn_iface, "name")
			return str(conn_iface)

		# Collect unique interface nodes
		for conn in self.unified_model.get("connections", []):
			iface_name = get_iface_name(getattr(conn, "interface", None) or conn.get("interface"))
			if iface_name and iface_name not in iface_alias_by_name:
				alias = _sanitize(f"iface_{iface_name}")
				iface_alias_by_name[iface_name] = alias
				lines.append(f"interface \"{iface_name}\" as {alias}")

		# Connections: src/dst to interface
		for conn in self.unified_model.get("connections", []):
			src = getattr(conn, "from_component", None) or conn.get("from_component")
			dst = getattr(conn, "to_component", None) or conn.get("to_component")
			conn_name = getattr(conn, "name", None) or conn.get("name")
			iface_name = get_iface_name(getattr(conn, "interface", None) or conn.get("interface"))
			if not (src and dst and iface_name):
				continue
			alias = iface_alias_by_name.get(iface_name)
			if not alias:
				continue
			lines.append(f"{src} --> {alias} : {conn_name}")
			lines.append(f"{dst} --> {alias}")

		lines.append(_puml_footer())
		return "\n".join(lines)

	def render_interface(self, interface_obj: Any) -> str:
		"""Render a single IDL interface: class + referenced structs + access/integrity."""
		iname = getattr(interface_obj, "name", "Interface")
		lines: List[str] = [
			_puml_header(f"Interface: {iname}"),
			f"class {iname} {{",
		]

		# Access: read/write
		access = getattr(interface_obj, "access", None)
		if access:
			# Prefer composer-enriched struct objects (keeps read vs write meaning clear)
			read_structs = getattr(access, "readStructs", None)
			write_structs = getattr(access, "writeStructs", None)
			if read_structs is not None:
				read_names = [str(getattr(s, "name", getattr(s, "reference", s))) for s in read_structs]
				if read_names:
					lines.append(f"    + read({', '.join(read_names)})")
			else:
				reads = []
				for rl in getattr(access, "readLines", []) or []:
					reads_obj = getattr(rl, "reads", None)
					if getattr(reads_obj, "all", None) == '*':
						reads.append('*')
					else:
						refs = getattr(reads_obj, "refs", []) or []
						reads.extend([str(r) for r in refs])
				if reads:
					lines.append(f"    + read({', '.join(reads)})")

			if write_structs is not None:
				write_names = [str(getattr(s, "name", getattr(s, "reference", s))) for s in write_structs]
				if write_names:
					lines.append(f"    + write({', '.join(write_names)})")
			else:
				writes = []
				for wl in getattr(access, "writeLines", []) or []:
					writes_obj = getattr(wl, "writes", None)
					if getattr(writes_obj, "all", None) == '*':
						writes.append('*')
					else:
						refs = getattr(writes_obj, "refs", []) or []
						writes.extend([str(r) for r in refs])
				if writes:
					lines.append(f"    + write({', '.join(writes)})")

		# Integrity
		integrity = getattr(interface_obj, "integrity", None)
		if integrity:
			refs_by_type = getattr(integrity, "byTypeRefs", None)
			by_type = getattr(integrity, "byType", None)
			if isinstance(refs_by_type, dict) and refs_by_type:
				for etype, names in refs_by_type.items():
					params = ", ".join([str(n) for n in (names or [])]) if names else ""
					lines.append(f"    + {etype}({params})")
			elif isinstance(by_type, dict) and by_type:
				for etype, structs in by_type.items():
					names = [str(getattr(s, "name", getattr(s, "reference", s))) for s in (structs or [])]
					params = ", ".join(names) if names else ""
					lines.append(f"    + {etype}({params})")
			else:
				for entry in getattr(integrity, "entries", []) or []:
					etype = getattr(entry, "type", "integrity")
					targets = getattr(entry, "targets", None)
					if getattr(targets, "all", None) == '*':
						params = '*'
					else:
						refs = getattr(targets, "refs", []) or []
						params = ", ".join([str(r) for r in refs]) if refs else ""
					lines.append(f"    + {etype}({params})")

		lines.append("}")

		# Data structures
		data = getattr(interface_obj, "data", None)
		if data:
			for struct in getattr(data, "structs", []) or []:
				# StructDef has name + fields, StructRef only reference
				sname = getattr(struct, "name", None)
				if sname:
					lines.append(f"class {sname} {{")
					for field in getattr(struct, "fields", []) or []:
						ftype = getattr(field, "type", "type")
						fname = getattr(field, "name", "field")
						arr = getattr(field, "array", None)
						init = getattr(field, "init", None)
						size = getattr(arr, "size", None) if arr else None
						initv = getattr(init, "value", None) if init else None
						suffix = f"[{size}]" if size is not None else ""
						init_s = f" = {initv}" if initv is not None else ""
						lines.append(f"    - {ftype} {fname}{suffix}{init_s}")
					lines.append("}")
					lines.append(f"{iname} --> {sname}")
				else:
					# StructRef: show dependency only
					ref = getattr(struct, "reference", None)
					if ref:
						sref = _sanitize(str(ref)).replace("_dataStructures", "")
						lines.append(f"class {sref}")
						lines.append(f"{iname} --> {sref}")

		lines.append(_puml_footer())
		return "\n".join(lines)

	def render_interfaces(self) -> Dict[str, str]:
		out: Dict[str, str] = {}
		for idl_model in self.idl_models:
			for interface in getattr(idl_model, "interfaces", []) or []:
				out[interface.name] = self.render_interface(interface)
		return out

	def render_profile(self, profile_obj: Any) -> str:
		"""Render a single HML profile as a class diagram with attributes."""
		pname = getattr(profile_obj, "name", "Profile")
		kind = getattr(profile_obj, "kind", profile_obj.__class__.__name__)
		lines: List[str] = [
			_puml_header(f"Hardware Profile: {pname}"),
			f"class {pname} <<{kind}>> {{",
		]

		# Flatten all attributes including nested blocks
		for attr, val in profile_obj.__dict__.items():
			if attr.startswith('_') or attr == 'parent':
				continue
			if hasattr(val, '__dict__'):
				# Nested block (memory, synchronization, performance, etc.)
				lines.append(f"    -- {attr} --")
				for sub_attr, sub_val in val.__dict__.items():
					if sub_attr.startswith('_') or sub_attr == 'parent':
						continue
					lines.append(f"    {sub_attr}: {sub_val}")
			else:
				lines.append(f"    {attr}: {val}")

		lines.append("}")
		lines.append(_puml_footer())
		return "\n".join(lines)

	def render_profiles(self) -> Dict[str, str]:
		out: Dict[str, str] = {}
		for profile_model in self.profile_models:
			for profile in getattr(profile_model, "profiles", []) or []:
				pname = getattr(profile, "name", None)
				if pname:
					out[pname] = self.render_profile(profile)
		return out

	def write_architecture(self, out_path: str) -> str:
		content = self.render_architecture()
		os.makedirs(os.path.dirname(out_path), exist_ok=True)
		with open(out_path, "w", encoding="utf-8") as f:
			f.write(content)
		return out_path

	def write_interfaces(self, out_dir: str) -> List[str]:
		contents = self.render_interfaces()
		os.makedirs(out_dir, exist_ok=True)
		written: List[str] = []
		for iname, txt in contents.items():
			path = os.path.join(out_dir, f"{_sanitize(iname)}.puml")
			with open(path, "w", encoding="utf-8") as f:
				f.write(txt)
			written.append(path)
		return written

	def write_profiles(self, out_dir: str) -> List[str]:
		contents = self.render_profiles()
		os.makedirs(out_dir, exist_ok=True)
		written: List[str] = []
		for pname, txt in contents.items():
			path = os.path.join(out_dir, f"{_sanitize(pname)}.puml")
			with open(path, "w", encoding="utf-8") as f:
				f.write(txt)
			written.append(path)
		return written
