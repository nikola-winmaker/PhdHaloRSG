from __future__ import annotations

import json
import logging
import os
import pickle

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


def _configure_logging(log_level: str) -> None:
    level = getattr(logging, str(log_level).upper(), logging.INFO)
    logging.basicConfig(level=level, format='[%(levelname)s] %(message)s', force=True)

# Robust import for render_codegen
try:
    from .codegen.renderer import render_codegen  # type: ignore
except ImportError:
    try:
        from codegen.renderer import render_codegen  # type: ignore
    except ImportError:
        from generator.codegen.renderer import render_codegen  # type: ignore

# Import generator discovery
try:
    from .discovery import get_registry  # type: ignore
except ImportError:
    try:
        from discovery import get_registry  # type: ignore
    except ImportError:
        from generator.discovery import get_registry  # type: ignore

@dataclass(frozen=True)
class GeneratorInputs:
    composer_output_dir: Path
    output_dir: Path
    pkl_path: Optional[Path]
    generators_config: dict


class HALOExecutor:
    def __init__(self) -> None:
        self.executor_name = "HALO Executor"

    def execute(
        self,
        *,
        composer_output_dir: str,
        output_dir: Optional[str],
        pkl_path: Optional[str] = None,
        user_gen_entry: Optional[str] = None,
        target_platforms: Optional[List[str]] = None,
    ) -> int:

        inputs = self._normalize_inputs(
            composer_output_dir=composer_output_dir,
            output_dir=output_dir,
            pkl_path=pkl_path,
            user_gen_entry=user_gen_entry,
        )

        unified_model = self._load_unified_model(inputs)
        analysis_report = self._run_analysis(unified_model, inputs)
        self._write_analysis(analysis_report, inputs)

        if not analysis_report.get("ok", False):
            return 1

        # --- Discover platforms from model ---
        platforms = set()
        for comp in unified_model.get("components", []):
            plat = str(comp.get("platform", "")).strip()
            if plat:
                platforms.add(plat)

        selected_platforms = self._select_platforms(
            available_platforms=platforms,
            requested_platforms=target_platforms,
        )

        # --- Load generators using discovery mechanism ---
        registry = get_registry()
        
        # Load user config if provided
        if user_gen_entry:
            user_gen_path = Path(user_gen_entry).expanduser().resolve()
            if not user_gen_path.exists() or not user_gen_path.is_file():
                raise FileNotFoundError(f"User generator configuration file not found: {user_gen_path}")
            registry.load_user_config(str(user_gen_path))
        
        # Get all available generators (builtin + discovered + user)
        gen_map = registry.get_all_generators()
        
        if len(gen_map) == 0:
            print("[ERROR] No generators discovered. Please ensure:")
            print("  Platform generators are installed (pip install halo[platform-generators])")
            return 1
        
        print(f"[INFO] Discovered {len(gen_map)} generator(s): {', '.join(gen_map.keys())}")


        # --- Generate portable code ---
        portable_out = Path(inputs.output_dir) / "codegen" / "portable"
        portable_out.mkdir(parents=True, exist_ok=True)
        
        # Get portable render module path
        try:
            from generator.codegen.render import ptbl_render
            portable_module = str(Path(ptbl_render.__file__).resolve())
        except ImportError:
            # Fallback to finding it relative to this file
            portable_module = str(Path(__file__).parent / "codegen" / "render" / "ptbl_render.py")
        
        try:
            render_codegen(
                unified_model=unified_model,
                analysis_report=analysis_report,
                environment="portable",
                output_dir=portable_out,
                gen_entry={"name": "portable", "module": portable_module},
            )
        except Exception as e:
            print(f"[ERROR] Failed to generate portable code: {e}")
            print("[ERROR] This usually indicates HALO is not properly installed or templates are missing.")
            return 1

        # --- Generate code per platform ---
        for plat in selected_platforms:
            # Return the component name for this platform (first match)
            comp = next((c for c in unified_model.get("components", []) if str(c.get("platform", "")).strip().lower() == plat.lower()), None)
            comp_name = comp.get("name") if comp else ""
            plat_key = plat.lower()
            gen = gen_map.get(plat_key)
            if not gen:
                #TODO: Logger warning
                print(f"[WARN] No generator found for platform '{plat}'. Make sure the generator is installed.")
                print(f"[WARN] Install with: pip install halo-generator-{plat_key}")
                continue
            plat_out = Path(inputs.output_dir) / "codegen" / f"{comp_name}_{plat_key}"
            plat_out.mkdir(parents=True, exist_ok=True)
            # Use template path if needed (future extension)
            try:
                render_codegen(
                    unified_model=unified_model,
                    analysis_report=analysis_report,
                    environment=plat,
                    output_dir=plat_out,
                    gen_entry=gen,
                )
            except Exception as e:
                print(f"[ERROR] Failed to generate code for platform '{plat}': {e}")
                print(f"[ERROR] Generator '{plat_key}' may not be properly installed or configured.")
                return 1
        self._write_deployment_manifest(analysis_report, inputs, selected_platforms)
        return 0

    @staticmethod
    def _select_platforms(
        *,
        available_platforms: set[str],
        requested_platforms: Optional[List[str]],
    ) -> List[str]:
        ordered_available = sorted(
            available_platforms,
            key=lambda platform: platform.lower(),
        )
        if not requested_platforms:
            return ordered_available

        available_by_key = {platform.lower(): platform for platform in ordered_available}
        selected: List[str] = []
        missing: List[str] = []

        for platform in requested_platforms:
            key = str(platform).strip().lower()
            if not key:
                continue
            match = available_by_key.get(key)
            if match is None:
                missing.append(platform)
                continue
            if match not in selected:
                selected.append(match)

        if missing:
            available_list = ", ".join(ordered_available) or "<none>"
            missing_list = ", ".join(missing)
            raise ValueError(
                f"Requested platform(s) not found in unified model: {missing_list}. "
                f"Available platforms: {available_list}"
            )

        if not selected:
            raise ValueError("No valid target platforms were selected")

        return selected

    def _normalize_inputs(
        self,
        *,
        composer_output_dir: str,
        output_dir: Optional[str],
        pkl_path: Optional[str],
        user_gen_entry: Optional[str] = None,
    ) -> GeneratorInputs:
        if not composer_output_dir:
            raise ValueError("composer_output_dir is required")

        in_dir = Path(composer_output_dir).expanduser().resolve()
        if not in_dir.exists() or not in_dir.is_dir():
            raise FileNotFoundError(f"Composer output directory does not exist: {in_dir}")

        out_dir = Path(output_dir).expanduser().resolve() if output_dir else in_dir

        explicit_pkl = Path(pkl_path).expanduser().resolve() if pkl_path else None

        return GeneratorInputs(
            composer_output_dir=in_dir,
            output_dir=out_dir,
            pkl_path=explicit_pkl,
            generators_config={}  # No longer needed, kept for compatibility
        )

    def _load_unified_model(self, inputs: GeneratorInputs) -> Dict[str, Any]:
        pkl = inputs.pkl_path or (inputs.composer_output_dir / "halo_unified_model.pkl")
        if not pkl.exists() or not pkl.is_file():
            raise FileNotFoundError(f"Unified model pickle not found: {pkl}")

        with pkl.open("rb") as f:
            model = pickle.load(f)

        if not isinstance(model, dict):
            raise TypeError(f"Expected unified model to be a dict, got: {type(model)}")

        return model

    def _run_analysis(self, unified_model: Dict[str, Any], inputs: GeneratorInputs) -> Dict[str, Any]:
        # Support both invocation styles:
        # - as package: `python -m generator.executor ...` / `halo generate ...`
        # - as script:  `python .\\executor.py ...` from sw/generator
        try:
            from .analyzer.analyzer import analyze_unified_model  # type: ignore
        except Exception:
            try:
                from analyzer.analyzer import analyze_unified_model  # type: ignore
            except Exception:
                from generator.analyzer.analyzer import analyze_unified_model  # type: ignore

        return analyze_unified_model(unified_model)

    def _write_analysis(self, analysis_report: Dict[str, Any], inputs: GeneratorInputs) -> None:
        analysis_dir = inputs.output_dir / "analysis"
        analysis_dir.mkdir(parents=True, exist_ok=True)

        report_path = analysis_dir / "analysis_report.json"
        report_path.write_text(json.dumps(analysis_report, indent=2), encoding="utf-8")

    def _generate_code(
        self,
        unified_model: Dict[str, Any],
        analysis_report: Dict[str, Any],
        inputs: GeneratorInputs,
    ) -> None:

        codegen_root = inputs.output_dir / "codegen"
        codegen_root.mkdir(parents=True, exist_ok=True)

        for env in analysis_report.get("environments", {}):
            env_out = codegen_root / env
            render_codegen(
                unified_model=unified_model,
                analysis_report=analysis_report,
                environment=env,
                output_dir=env_out,
            )

    def _write_deployment_manifest(self, analysis_report: Dict[str, Any], inputs: GeneratorInputs, platforms=None) -> None:
        deploy_dir = inputs.output_dir / "deployment"
        deploy_dir.mkdir(parents=True, exist_ok=True)
        if platforms is None:
            platforms = []
        for plat in platforms:
            env_dir = deploy_dir / plat.lower()
            env_dir.mkdir(parents=True, exist_ok=True)
            manifest = {
                "environment": plat,
                "generated_at": analysis_report.get("generated_at"),
                "notes": "Deployment packaging is not implemented yet; this manifest is a placeholder.",
            }
            (env_dir / "deployment_manifest.json").write_text(
                json.dumps(manifest, indent=2),
                encoding="utf-8",
            )

def main(argv: List[str] | None = None) -> int:
    """CLI entry point for HALO Generator.

    Mirrors the composer pattern: accepts an argv list for embedding/delegation.
    """

    import argparse

    p = argparse.ArgumentParser(
        prog="halo_generator",
        description="HALO Generator (unified model PKL -> analysis report -> codegen)",
    )

    p.add_argument(
        "--input",
        "-i",
        dest="composer_output_dir",
        metavar="DIR",
        required=True,
        help="Composer output directory containing halo_unified_model.pkl",
    )

    p.add_argument(
        "--gen_cfg",
        "-gcfg",
        dest="user_gen_entry",
        metavar="FILE",
        required=False,
        default=None,
        help=(
            "Optional user generator configuration file (JSON) for custom generator settings."
        ),
    )

    p.add_argument(
        "--output",
        "-o",
        dest="output_dir",
        metavar="DIR",
        default=None,
        help="Output directory for generator artifacts (default: same as --composer-output-dir)",
    )
    p.add_argument(
        "--platform",
        "-p",
        dest="platforms",
        action="append",
        default=[],
        metavar="NAME",
        help=(
            "Generate only the specified platform. "
            "Default: generate all platforms found in the unified model."
        ),
    )

    p.add_argument(
        "--pkl",
        dest="pkl_path",
        default=None,
        metavar="FILE",
        help="Optional explicit path to halo_unified_model.pkl (default: <composer-output-dir>/halo_unified_model.pkl)",
    )
    p.add_argument(
        "--log-level",
        "-l",
        dest="log_level",
        metavar="LEVEL",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging level for generator and protocol plugins",
    )

    args = p.parse_args(argv)
    _configure_logging(args.log_level)
    executor = HALOExecutor()
    return int(
        executor.execute(
            composer_output_dir=args.composer_output_dir,
            output_dir=args.output_dir,
            pkl_path=args.pkl_path,
            user_gen_entry=args.user_gen_entry,
            target_platforms=args.platforms,
        )
    )

# Set-Location "D:\PhdWork\PhdThesis\HALO\sw\generator"; python .\executor.py -i ..\..\output\ -o ..\..\output\gen\
if __name__ == "__main__":
    raise SystemExit(main())
