from __future__ import annotations

from .base import BaseScaffoldGenerator, TemplateMapping


class ProtocolGeneratorScaffold(BaseScaffoldGenerator):
    def type_specific_templates(self) -> tuple[TemplateMapping, ...]:
        templates: list[TemplateMapping] = [
            ("protocol/__init__.py.j2", "src/{module_name}/__init__.py"),
            ("protocol/render.py.j2", "src/{module_name}/render.py"),
            ("protocol/config.py.j2", "src/{module_name}/config.py"),
            # Common protocol templates (platform-independent)
            (
                "protocol/templates/protocol_common.h.j2",
                "src/{module_name}/templates/{entry_point_name}_common.h.j2",
            ),
            (
                "protocol/templates/protocol_common.c.j2",
                "src/{module_name}/templates/{entry_point_name}_common.c.j2",
            ),
        ]
        
        # Generate platform-specific templates for each supported platform
        entry_point_name = self.scaffold_context.entry_point_name
        supported_platforms = self.scaffold_context.supported_platforms
        
        if supported_platforms:
            # Create templates for each supported platform
            for platform in supported_platforms:
                templates.append((
                    "protocol/templates/protocol.h.j2",
                    f"src/{{module_name}}/templates/{entry_point_name}_{platform}.h.j2",
                ))
                templates.append((
                    "protocol/templates/protocol_impl.c.j2",
                    f"src/{{module_name}}/templates/{entry_point_name}_{platform}.c.j2",
                ))
        else:
            # Fallback to generic templates if no platforms specified
            templates.extend([
                (
                    "protocol/templates/protocol.h.j2",
                    "src/{module_name}/templates/protocol.h.j2",
                ),
                (
                    "protocol/templates/protocol_impl.c.j2",
                    "src/{module_name}/templates/protocol_impl.c.j2",
                ),
            ])
        
        return tuple(templates)