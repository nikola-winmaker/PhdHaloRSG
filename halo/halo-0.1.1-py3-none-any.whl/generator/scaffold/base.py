from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Any, Iterable, Tuple

from jinja2 import Environment, FileSystemLoader

from .context import ScaffoldContext


TemplateMapping = Tuple[str, str]


class BaseScaffoldGenerator(ABC):
    COMMON_TEMPLATES: Tuple[TemplateMapping, ...] = (
        ("common/pyproject.toml.j2", "pyproject.toml"),
        ("common/README.md.j2", "README.md"),
        ("common/LICENSE.j2", "LICENSE"),
        ("common/.gitignore.j2", ".gitignore"),
    )

    def __init__(self, scaffold_context: ScaffoldContext, template_root: Path):
        self.scaffold_context = scaffold_context
        self.template_root = template_root
        self.render_context = scaffold_context.to_template_context()
        self.jinja_environment = Environment(
            loader=FileSystemLoader(str(template_root)),
            autoescape=False,
            keep_trailing_newline=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )

    def scaffold(self, output_dir: Path) -> Path:
        package_dir = output_dir / self.scaffold_context.package_name
        self._ensure_target_is_writable(package_dir)

        for template_name, destination_template in self.template_mappings():
            destination = package_dir / destination_template.format_map(self.render_context)
            self._render_template(template_name, destination)

        return package_dir

    def template_mappings(self) -> Iterable[TemplateMapping]:
        return (*self.COMMON_TEMPLATES, *self.type_specific_templates())

    @abstractmethod
    def type_specific_templates(self) -> Tuple[TemplateMapping, ...]:
        raise NotImplementedError

    def _render_template(self, template_name: str, destination: Path) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        rendered = self.jinja_environment.get_template(template_name).render(self.render_context)
        destination.write_text(rendered, encoding="utf-8")

    @staticmethod
    def _ensure_target_is_writable(package_dir: Path) -> None:
        if not package_dir.exists():
            return
        if any(package_dir.iterdir()):
            raise FileExistsError(f"Target scaffold directory already exists and is not empty: {package_dir}")