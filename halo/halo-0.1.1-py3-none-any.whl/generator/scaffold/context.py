from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, Any, Iterable


_SUPPORTED_GENERATOR_TYPES = {"platform", "protocol"}


def _normalize_identifier(value: str) -> str:
    normalized = re.sub(r"[^0-9a-zA-Z]+", "_", value.strip().lower())
    normalized = re.sub(r"_+", "_", normalized).strip("_")
    if not normalized:
        raise ValueError("Generator name must contain at least one alphanumeric character")
    return normalized


def _titleize(value: str) -> str:
    words = re.split(r"[_\-\s]+", value.strip())
    return " ".join(word.capitalize() for word in words if word)


@dataclass(frozen=True)
class ScaffoldContext:
    name: str
    description: str
    author: str
    email: str
    target_platform: str
    supported_platforms: tuple[str, ...] = ()
    has_os: bool = False
    template_engine: str = "jinja2"
    generator_type: str = "platform"

    def __post_init__(self) -> None:
        generator_type = self.generator_type.strip().lower()
        if generator_type not in _SUPPORTED_GENERATOR_TYPES:
            supported = ", ".join(sorted(_SUPPORTED_GENERATOR_TYPES))
            raise ValueError(f"Unsupported generator type '{self.generator_type}'. Expected one of: {supported}")
        object.__setattr__(self, "generator_type", generator_type)
        object.__setattr__(self, "name", self.name.strip())
        object.__setattr__(self, "description", self.description.strip())
        object.__setattr__(self, "author", self.author.strip())
        object.__setattr__(self, "email", self.email.strip())
        object.__setattr__(self, "target_platform", self.target_platform.strip().lower())
        normalized_platforms = self._normalize_supported_platforms(self.supported_platforms)
        if generator_type == "protocol" and not normalized_platforms:
            raise ValueError("Protocol generators require at least one supported platform")
        object.__setattr__(self, "supported_platforms", normalized_platforms)

    @staticmethod
    def _normalize_supported_platforms(platforms: Iterable[str]) -> tuple[str, ...]:
        normalized: list[str] = []
        seen: set[str] = set()
        for platform in platforms:
            value = str(platform).strip().lower()
            if not value:
                continue
            if value not in seen:
                normalized.append(value)
                seen.add(value)
        return tuple(normalized)

    @property
    def identifier(self) -> str:
        return _normalize_identifier(self.name)

    @property
    def distribution_slug(self) -> str:
        return self.identifier.replace("_", "-")

    @property
    def package_name(self) -> str:
        prefix = "halo_gen" if self.is_platform else "halo_proto"
        return f"{prefix}_{self.distribution_slug}"

    @property
    def module_name(self) -> str:
        prefix = "halo_gen" if self.is_platform else "halo_proto"
        return f"{prefix}_{self.identifier}"

    @property
    def entry_point_name(self) -> str:
        return self.identifier

    @property
    def entry_function_name(self) -> str:
        return f"render_{self.identifier}"

    @property
    def entry_module_name(self) -> str:
        return "render"

    @property
    def generator_display_name(self) -> str:
        return _titleize(self.name)

    @property
    def is_platform(self) -> bool:
        return self.generator_type == "platform"

    @property
    def kind_label(self) -> str:
        return "platform" if self.is_platform else "protocol"

    @property
    def kind_title(self) -> str:
        return self.kind_label.capitalize()

    @property
    def output_dir_hint(self) -> str:
        if self.is_platform:
            return f"output/{self.target_platform}"
        return f"output/protocol/{self.entry_point_name}"

    @property
    def copyright_year(self) -> int:
        return 2026

    def to_template_context(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "author": self.author,
            "email": self.email,
            "target_platform": self.target_platform,
            "has_os": self.has_os,
            "template_engine": self.template_engine,
            "generator_type": self.generator_type,
            "generator_display_name": self.generator_display_name,
            "package_name": self.package_name,
            "module_name": self.module_name,
            "entry_point_name": self.entry_point_name,
            "entry_function_name": self.entry_function_name,
            "entry_module_name": self.entry_module_name,
            "kind_label": self.kind_label,
            "kind_title": self.kind_title,
            "output_dir_hint": self.output_dir_hint,
            "copyright_year": self.copyright_year,
            "supported_platforms": list(self.supported_platforms),
        }