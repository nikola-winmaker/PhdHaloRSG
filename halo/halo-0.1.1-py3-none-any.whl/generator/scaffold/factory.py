from __future__ import annotations

from pathlib import Path

from .base import BaseScaffoldGenerator
from .context import ScaffoldContext
from .platform_generator import PlatformGeneratorScaffold
from .protocol_generator import ProtocolGeneratorScaffold


class ScaffoldFactory:
    def __init__(self, template_root: Path):
        self.template_root = template_root

    def create(self, scaffold_context: ScaffoldContext) -> BaseScaffoldGenerator:
        if scaffold_context.generator_type == "platform":
            return PlatformGeneratorScaffold(scaffold_context, self.template_root)
        if scaffold_context.generator_type == "protocol":
            return ProtocolGeneratorScaffold(scaffold_context, self.template_root)
        raise ValueError(f"Unsupported generator type: {scaffold_context.generator_type}")


class GeneratorScaffold:
    """Create scaffolding for a new HALO generator package."""

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.template_dir = Path(__file__).parent / "templates"
        self.factory = ScaffoldFactory(self.template_dir)

    def create_generator(
        self,
        *,
        name: str,
        description: str,
        author: str,
        email: str,
        target_platform: str,
        supported_platforms: list[str] | tuple[str, ...] | None = None,
        has_os: bool = False,
        template_engine: str = "jinja2",
        generator_type: str = "platform",
    ) -> Path:
        scaffold_context = ScaffoldContext(
            name=name,
            description=description,
            author=author,
            email=email,
            target_platform=target_platform,
            supported_platforms=tuple(supported_platforms or ()),
            has_os=has_os,
            template_engine=template_engine,
            generator_type=generator_type,
        )
        generator = self.factory.create(scaffold_context)
        package_dir = generator.scaffold(self.output_dir)
        self._print_summary(scaffold_context, package_dir)
        return package_dir

    @staticmethod
    def _print_summary(scaffold_context: ScaffoldContext, package_dir: Path) -> None:
        print(f"\nGenerator scaffolding created at: {package_dir}")
        print("\nNext steps:")
        print(f"  1. cd {package_dir}")
        print(
            "  2. Edit "
            f"src/{scaffold_context.module_name}/{scaffold_context.entry_module_name}.py "
            f"to implement your {scaffold_context.kind_label} logic"
        )
        print(f"  3. Customize templates in src/{scaffold_context.module_name}/templates/")
        print("  4. Install in development mode: pip install -e .")
        print(
            "  5. Test with: halo generate "
            f"--composer-output-dir ./output"
        )