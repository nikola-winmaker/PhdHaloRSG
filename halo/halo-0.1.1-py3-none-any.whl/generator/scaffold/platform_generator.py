from __future__ import annotations

from pathlib import Path

from .base import BaseScaffoldGenerator, TemplateMapping


class PlatformGeneratorScaffold(BaseScaffoldGenerator):
    def type_specific_templates(self) -> tuple[TemplateMapping, ...]:
        fixed: tuple[TemplateMapping, ...] = (
            ("platform/__init__.py.j2", "src/{module_name}/__init__.py"),
            ("platform/render.py.j2", "src/{module_name}/render.py"),
            ("platform/config.py.j2", "src/{module_name}/config.py"),
        )
        code_templates = self._discover_code_templates()
        return (*fixed, *code_templates)

    def _discover_code_templates(self) -> tuple[TemplateMapping, ...]:
        """Discover all .j2 files under platform/code_templates/ automatically."""
        code_templates_dir = self.template_root / "platform" / "code_templates"
        if not code_templates_dir.is_dir():
            return ()
        mappings: list[TemplateMapping] = []
        for template_file in sorted(code_templates_dir.rglob("*.j2")):
            rel = template_file.relative_to(self.template_root)
            source = str(rel).replace("\\", "/")
            dest_rel = template_file.relative_to(code_templates_dir)
            dest = "src/{module_name}/templates/" + str(dest_rel).replace("\\", "/")
            mappings.append((source, dest))
        return tuple(mappings)