import json
import sys
from pathlib import Path


def _import_halo_executor():
    """Import HALOExecutor from the source tree."""
    sw_dir = Path(__file__).resolve().parents[3] / "sw"
    if str(sw_dir) not in sys.path:
        sys.path.insert(0, str(sw_dir))

    for mod in ("generator.executor", "generator"):
        sys.modules.pop(mod, None)

    from generator.executor import HALOExecutor

    return HALOExecutor


def test_user_generators_config(tmp_path):
    test_dir = Path(__file__).parent
    user_gen_path = test_dir / "user_gen.py"
    assert user_gen_path.exists()

    user_cfg_path = tmp_path / "user_gencfg.json"
    user_cfg_path.write_text(
        json.dumps(
            {
                "generators": [
                    {
                        "name": "FPGA",
                        "description": "Default generator for FPGA targets",
                        "module": str(user_gen_path.resolve()),
                    }
                ]
            }
        ),
        encoding="utf-8",
    )

    HALOExecutor = _import_halo_executor()
    orig_load = HALOExecutor._load_unified_model

    def fake_load(self, inputs):
        return {"components": [{"name": "fpga_node", "platform": "FPGA"}]}

    HALOExecutor._load_unified_model = fake_load

    composer_output_dir = tmp_path / "composer_out"
    composer_output_dir.mkdir()
    (composer_output_dir / "halo_unified_model.pkl").write_bytes(b"\x80\x04}\x94.")

    try:
        executor = HALOExecutor()
        output_dir = tmp_path / "gen_out"
        ret = executor.execute(
            composer_output_dir=str(composer_output_dir),
            output_dir=str(output_dir),
            user_gen_entry=str(user_cfg_path),
        )
    finally:
        HALOExecutor._load_unified_model = orig_load

    assert ret == 0
    assert (output_dir / "codegen" / "portable").exists()
    assert (output_dir / "codegen" / "fpga_node_fpga").exists()
