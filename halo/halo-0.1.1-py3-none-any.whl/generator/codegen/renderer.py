from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

try:
    from .render.proto_render import render_protocols
except ImportError:
    from generator.codegen.render.proto_render import render_protocols

def render_codegen(
    *,
    unified_model: Dict[str, Any],
    analysis_report: Dict[str, Any],
    environment: str,
    output_dir: Path,
    gen_entry: Dict[str, Any],
) -> None:

    # --- Per-platform scope filtering ---
    plat_key = str(environment).lower()
    components = unified_model.get("components", [])
    platform_components = [c for c in components if str(c.get("platform", "")).lower() == plat_key]
    platform_component_names = {c["name"] for c in platform_components}
    connections = unified_model.get("connections", [])
    relevant_conns = [
        conn
        for conn in connections
        if conn.get("from_component") in platform_component_names
        or conn.get("to_component") in platform_component_names
    ]
    send_conns = [conn for conn in connections if conn.get("from_component") in platform_component_names]
    recv_conns = [conn for conn in connections if conn.get("to_component") in platform_component_names]
    used_ifaces = set(conn["interface"] for conn in relevant_conns if "interface" in conn)
    interfaces = unified_model.get("interfaces", {})
    used_structs = set()
    for iname in used_ifaces:
        iface = interfaces.get(iname, {})
        struct_refs = (iface.get("data", {}) or {}).get("structRefs", [])
        used_structs.update(struct_refs)
    all_structs = (unified_model.get("dataTypes", {}) or {}).get("structs", {})
    platform_structs = {k: v for k, v in all_structs.items() if k in used_structs}
    # Compose reduced model
    platform_model = dict(unified_model)
    platform_model["components"] = platform_components
    if "dataTypes" not in platform_model:
        platform_model["dataTypes"] = {}
    platform_model["dataTypes"] = dict(platform_model["dataTypes"])
    platform_model["dataTypes"]["structs"] = platform_structs
    platform_model["connections"] = relevant_conns
    platform_model["interfaces"] = {k: v for k, v in interfaces.items() if k in used_ifaces}
    platform_model["send_connections"] = send_conns
    platform_model["recv_connections"] = recv_conns

    # --- Filter profiles for the platform ---
    # Only include profiles referenced by relevant connections (like interfaces)
    profiles = unified_model.get("profiles", {}) or {}
    # Find all profile names referenced in relevant connections
    used_profiles = set()
    for conn in relevant_conns:
        if "profile" in conn:
            used_profiles.add(conn["profile"])
    # Only keep profiles that are referenced
    platform_model["profiles"] = {k: v for k, v in profiles.items() if k in used_profiles}

    plat_key = environment.lower()
    module = gen_entry["module"]

    # --- Portable rendering dispatch ---
    if plat_key == "portable":
        # Portable render
        try:
            from .render.ptbl_render import render_portable
        except ImportError:
            from generator.codegen.render.ptbl_render import render_portable
        render_portable(
            model=unified_model,
            analysis=analysis_report,
            environment=environment,
            output_dir=output_dir,
        )
        return

    # --- HALO Core: Render common templates first ---
    try:
        from .render.common_render import render_common
    except ImportError:
        from generator.codegen.render.common_render import render_common
    
    render_common(
        model=platform_model,
        analysis=analysis_report,
        environment=environment,
        output_dir=output_dir,
    )

    # --- Platform-specific generator: Add platform-specific files ---
    # Load and call the platform-specific generator
    import importlib.util
    
    module_path = Path(module)
    if not module_path.exists():
        raise RuntimeError(f"Render module not found: {module}")
    
    spec = importlib.util.spec_from_file_location("render_module", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Failed to load render module spec: {module}")
    
    render_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(render_mod)
    
    # Look for the render function (e.g., render_linux, render_freertos, etc.)
    func_name = f"render_{plat_key}"
    if not hasattr(render_mod, func_name):
        raise RuntimeError(
            f"Render module {module} does not define '{func_name}' function. "
            f"Expected function: {func_name}(model, analysis, environment, output_dir)"
        )
    
    plat_mod = getattr(render_mod, func_name)

    # Call platform generator - it only adds platform-specific files
    plat_mod(
        model=platform_model,
        analysis=analysis_report,
        environment=environment,
        output_dir=output_dir,
    )

    # --- Protocol-specific generators: Generate protocol implementation files ---
    # Platform and protocol generators are independent; HALO Core orchestrates both
    render_protocols(
        model=platform_model,
        analysis=analysis_report,
        environment=environment,
        output_dir=output_dir,
    )
