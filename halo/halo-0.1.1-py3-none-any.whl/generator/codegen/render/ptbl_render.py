from __future__ import annotations

from pathlib import Path
from jinja2 import Environment, FileSystemLoader, StrictUndefined
try:
    from . import render_utils as _utils
except ImportError:
    import generator.codegen.render.render_utils as _utils


# --- Generate common portable code before platform-specific render ---
def render_portable(model, analysis, environment, output_dir):
    templates_dir = Path(__file__).parent.parent / "templates" / "portable"
    j2env = Environment(
        loader=FileSystemLoader(str(templates_dir)),
        autoescape=False,
        undefined=StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
    )

    j2env.filters["c_ident"] = _utils._c_ident
    j2env.filters["crc_ret_type"] = _utils._crc_ret_type
    j2env.filters["size_bytes"] = _utils._size_bytes
    j2env.filters["c_uint"] = _utils._c_uint
    j2env.filters["c_str"] = _utils._c_str
    # Template helpers (globals) for value-based classification.
    j2env.globals["maybe_size_bytes"] = _utils._maybe_size_bytes
    j2env.globals["looks_like_hex"] = _utils._looks_like_hex
    j2env.globals["looks_like_uint"] = _utils._looks_like_uint
    j2env.globals["infer_enum_domain"] = _utils._infer_enum_domain
    j2env.globals["_is_protocol_generator_available"] = _utils._is_protocol_generator_available

    ctx = {
        "model": model,
        "analysis": analysis,
        "environment": environment,
        "type_map": _utils._default_type_map(),
    }

    halo_include_dir = output_dir / "include"
    halo_src_dir = output_dir / "src"
    halo_include_dir.mkdir(parents=True, exist_ok=True)
    halo_src_dir.mkdir(parents=True, exist_ok=True)

    _utils._render_to_file(j2env, "halo_types.h.j2", ctx, halo_include_dir / "halo_types.h")
    _utils._render_to_file(j2env, "halo_lib.h.j2", ctx, halo_include_dir / "halo_lib.h")