"""Protocol generator registry and discovery system.

Protocol generators are plugins that generate protocol-specific code (shmem, DMA, MMIO)
for multiple platforms. This module provides discovery and registration of protocol generators.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional, Any

logger = logging.getLogger(__name__)

# Global protocol registry
_protocol_registry: Optional['ProtocolRegistry'] = None


class ProtocolGeneratorEntry:
    """Represents a discovered protocol generator."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        self.name = name
        self.supported_platforms = config.get("supported_platforms", [])
        self.module_path = config.get("module")
        self._render_module = None
    
    def get_render_function(self, platform: str):
        """Get the render function for a specific platform.
        
        Args:
            platform: Platform name (e.g., "linux", "baremetal")
            
        Returns:
            Callable render function or None if platform not supported
        """
        if platform not in self.supported_platforms:
            return None
        
        if self._render_module is None:
            self._load_render_module()
        
        func_name = f"render_{self.name}_{platform}"
        return getattr(self._render_module, func_name, None)
    
    def _load_render_module(self):
        """Load the render module dynamically."""
        import importlib.util
        
        module_path = Path(self.module_path)
        if not module_path.exists():
            raise RuntimeError(f"Protocol render module not found: {self.module_path}")
        
        spec = importlib.util.spec_from_file_location(f"{self.name}_render", module_path)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Failed to load protocol render module: {self.module_path}")
        
        self._render_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self._render_module)


class ProtocolRegistry:
    """Registry of available protocol generators."""
    
    def __init__(self):
        self._protocols: Dict[str, ProtocolGeneratorEntry] = {}
    
    def register(self, name: str, config: Dict[str, Any]) -> None:
        """Register a protocol generator.
        
        Args:
            name: Protocol name (e.g., "shmem", "dma")
            config: Protocol configuration with supported_platforms and module
        """
        logger.info(f"Registering protocol generator: {name}")
        self._protocols[name] = ProtocolGeneratorEntry(name, config)
    
    def get_protocol(self, name: str) -> Optional[ProtocolGeneratorEntry]:
        """Get a protocol generator by name.
        
        Args:
            name: Protocol name
            
        Returns:
            ProtocolGeneratorEntry or None if not found
        """
        return self._protocols.get(name)
    
    def list_protocols(self) -> List[str]:
        """List all registered protocol names."""
        return list(self._protocols.keys())
    
    def get_protocols_for_platform(self, platform: str) -> List[str]:
        """Get protocols that support a specific platform.
        
        Args:
            platform: Platform name
            
        Returns:
            List of protocol names that support this platform
        """
        return [
            name for name, proto in self._protocols.items()
            if platform in proto.supported_platforms
        ]


def _discover_protocol_generators() -> None:
    """Discover protocol generators via entry points."""
    global _protocol_registry
    
    if _protocol_registry is not None:
        return
    
    _protocol_registry = ProtocolRegistry()
    
    # Try Python 3.10+ importlib.metadata first
    try:
        from importlib.metadata import entry_points
        eps = entry_points()
        # Python 3.10+ returns EntryPoints object with select method
        if hasattr(eps, 'select'):
            protocol_eps = eps.select(group='halo.protocol_generators')
        else:
            # Python 3.9 fallback
            protocol_eps = eps.get('halo.protocol_generators', [])
    except ImportError:
        # Python <3.8 fallback
        from importlib_metadata import entry_points
        eps = entry_points()
        if hasattr(eps, 'select'):
            protocol_eps = eps.select(group='halo.protocol_generators')
        else:
            protocol_eps = eps.get('halo.protocol_generators', [])
    
    for ep in protocol_eps:
        try:
            get_config_func = ep.load()
            config = get_config_func()
            protocol_name = config.get("name", ep.name)
            _protocol_registry.register(protocol_name, config)
        except Exception as e:
            logger.warning(f"Failed to load protocol generator {ep.name}: {e}")


def get_protocol_registry() -> ProtocolRegistry:
    """Get the global protocol registry.
    
    Returns:
        ProtocolRegistry instance with discovered protocol generators
    """
    if _protocol_registry is None:
        _discover_protocol_generators()
    return _protocol_registry


def reset_protocol_registry() -> None:
    """Reset the protocol registry (mainly for testing)."""
    global _protocol_registry
    _protocol_registry = None
