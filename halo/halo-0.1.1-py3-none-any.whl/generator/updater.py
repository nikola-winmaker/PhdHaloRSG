"""Generator configuration updater.

Provides functionality to update existing generator config.py files
with new attributes (supported_platforms, description, etc.)
"""
from __future__ import annotations

import ast
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class GeneratorConfigUpdater:
    """Update attributes in generator config.py files."""

    def __init__(self, config_path: Path):
        """Initialize updater with path to config.py.
        
        Args:
            config_path: Path to config.py file
        """
        self.config_path = Path(config_path)
        if not self.config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")
        if not self.config_path.name == "config.py":
            raise ValueError(f"Expected config.py, got: {self.config_path.name}")

    def update_attribute(self, attribute_name: str, new_value: Any) -> bool:
        """Update a single attribute in the config dict.
        
        Args:
            attribute_name: Name of attribute in config dict (e.g., 'supported_platforms')
            new_value: New value for the attribute
            
        Returns:
            True if successful, False otherwise
        """
        try:
            content = self.config_path.read_text(encoding="utf-8")
            tree = ast.parse(content)
            
            # Find the get_protocol_config or get_generator_config function
            func_node = self._find_config_function(tree)
            if not func_node:
                logger.error("Could not find config function in config.py")
                return False
            
            # Find the return statement and its dict
            dict_node = self._find_return_dict(func_node)
            if not dict_node:
                logger.error("Could not find return dict in config function")
                return False
            
            # Update the dict in source
            updated_content = self._update_dict_in_source(
                content, attribute_name, new_value
            )
            
            if updated_content == content:
                logger.warning(
                    f"No changes made. Attribute '{attribute_name}' may not exist."
                )
                return False
            
            self.config_path.write_text(updated_content, encoding="utf-8")
            logger.info(f"Updated '{attribute_name}' in {self.config_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error updating config: {e}")
            return False

    def update_attributes(self, updates: Dict[str, Any]) -> bool:
        """Update multiple attributes in the config dict.
        
        Args:
            updates: Dict mapping attribute names to new values
            
        Returns:
            True if all updates successful, False otherwise
        """
        all_successful = True
        for attr_name, value in updates.items():
            success = self.update_attribute(attr_name, value)
            all_successful = all_successful and success
        return all_successful

    def add_platforms(self, new_platforms: List[str]) -> bool:
        """Add platforms to supported_platforms list.
        
        Args:
            new_platforms: List of platform names to add
            
        Returns:
            True if successful, False otherwise
        """
        try:
            content = self.config_path.read_text(encoding="utf-8")
            tree = ast.parse(content)
            
            # Find current platforms
            func_node = self._find_config_function(tree)
            if not func_node:
                return False
            
            dict_node = self._find_return_dict(func_node)
            if not dict_node:
                return False
            
            current_platforms = self._extract_list_value(dict_node, "supported_platforms")
            if current_platforms is None:
                logger.warning("supported_platforms not found in config")
                return False
            
            # Merge without duplicates
            merged = list(dict.fromkeys(current_platforms + new_platforms))
            
            if merged == current_platforms:
                logger.info("No new platforms to add (all already present)")
                return True
            
            updated_content = self._update_dict_in_source(
                content, "supported_platforms", merged
            )
            
            self.config_path.write_text(updated_content, encoding="utf-8")
            logger.info(f"Added platforms {new_platforms}")
            return True
            
        except Exception as e:
            logger.error(f"Error adding platforms: {e}")
            return False

    def remove_platforms(self, platforms_to_remove: List[str]) -> bool:
        """Remove platforms from supported_platforms list.
        
        Args:
            platforms_to_remove: List of platform names to remove
            
        Returns:
            True if successful, False otherwise
        """
        try:
            content = self.config_path.read_text(encoding="utf-8")
            tree = ast.parse(content)
            
            func_node = self._find_config_function(tree)
            if not func_node:
                return False
            
            dict_node = self._find_return_dict(func_node)
            if not dict_node:
                return False
            
            current_platforms = self._extract_list_value(dict_node, "supported_platforms")
            if current_platforms is None:
                return False
            
            # Remove specified platforms
            filtered = [p for p in current_platforms if p not in platforms_to_remove]
            
            if filtered == current_platforms:
                logger.info("No platforms to remove")
                return True
            
            updated_content = self._update_dict_in_source(
                content, "supported_platforms", filtered
            )
            
            self.config_path.write_text(updated_content, encoding="utf-8")
            logger.info(f"Removed platforms {platforms_to_remove}")
            return True
            
        except Exception as e:
            logger.error(f"Error removing platforms: {e}")
            return False

    def get_platforms(self) -> Optional[List[str]]:
        """Get current supported_platforms list.
        
        Returns:
            List of platform names or None if not found
        """
        try:
            content = self.config_path.read_text(encoding="utf-8")
            tree = ast.parse(content)
            
            func_node = self._find_config_function(tree)
            if not func_node:
                return None
            
            dict_node = self._find_return_dict(func_node)
            if not dict_node:
                return None
            
            return self._extract_list_value(dict_node, "supported_platforms")
            
        except Exception as e:
            logger.error(f"Error reading platforms: {e}")
            return None

    # Private helper methods
    
    @staticmethod
    def _find_config_function(tree: ast.AST) -> Optional[ast.FunctionDef]:
        """Find get_protocol_config or get_generator_config function."""
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                if node.name in ("get_protocol_config", "get_generator_config"):
                    return node
        return None

    @staticmethod
    def _find_return_dict(func_node: ast.FunctionDef) -> Optional[ast.Dict]:
        """Find the return dict in function body."""
        for node in func_node.body:
            if isinstance(node, ast.Return) and isinstance(node.value, ast.Dict):
                return node.value
        return None

    @staticmethod
    def _extract_list_value(dict_node: ast.Dict, key: str) -> Optional[List[str]]:
        """Extract list value from dict node."""
        for k, v in zip(dict_node.keys, dict_node.values):
            if isinstance(k, ast.Constant) and k.value == key:
                if isinstance(v, ast.List):
                    return [
                        elem.value
                        for elem in v.elts
                        if isinstance(elem, ast.Constant)
                    ]
        return None

    @staticmethod
    def _update_dict_in_source(
        content: str, key: str, value: Any
    ) -> str:
        """Update dictionary value in source code (string-based approach)."""
        # Format the value appropriately
        if isinstance(value, list):
            if value and isinstance(value[0], str):
                value_str = "[" + ", ".join(f'"{v}"' for v in value) + "]"
            else:
                value_str = str(value)
        elif isinstance(value, str):
            value_str = f'"{value}"'
        else:
            value_str = str(value)
        
        # Find and replace the line containing the key
        import re
        pattern = rf'(\s*["\']?{re.escape(key)}["\']?\s*:\s*)(\[.*?\]|"[^"]*"|[^,}}]+)'
        replacement = rf'\1{value_str}'
        
        updated = re.sub(pattern, replacement, content, flags=re.MULTILINE | re.DOTALL)
        return updated
